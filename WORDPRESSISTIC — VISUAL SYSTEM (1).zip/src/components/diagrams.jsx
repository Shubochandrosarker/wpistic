// diagrams.jsx — infrastructure-style operational diagrams.
// Replaces circle-and-line flowcharts with system blocks, IO ports, signal rails.
// Globally registers: SystemDiagram, FlowRail, LayerStack, NodeDiagram (legacy alias)

/* ─── A rectangular system block with IO ports and status ─── */
const SystemBlock = ({ x, y, w = 130, h = 64, accent, label, sublabel, ports = ['in', 'out'], active = true }) => (
  <g>
    {/* glow halo */}
    <rect x={x - 6} y={y - 6} width={w + 12} height={h + 12} rx="3"
          fill={tint(accent, 0.10)} opacity="0.7" />
    {/* main */}
    <rect x={x} y={y} width={w} height={h} rx="2"
          fill="rgba(11,16,32,0.92)" stroke={accent} strokeWidth="1" />
    {/* header bar */}
    <rect x={x} y={y} width={w} height="14" fill={tint(accent, 0.18)} />
    <line x1={x} y1={y + 14} x2={x + w} y2={y + 14} stroke={accent} strokeWidth="0.5" opacity="0.5" />
    {/* status dot */}
    {active && (
      <circle cx={x + w - 8} cy={y + 7} r="2.2" fill={accent}>
        <animate attributeName="opacity" values="1;0.4;1" dur="2s" repeatCount="indefinite" />
      </circle>
    )}
    {/* ports */}
    {ports.includes('in') && (
      <>
        <line x1={x - 6} y1={y + h / 2} x2={x} y2={y + h / 2} stroke={accent} strokeWidth="1" />
        <circle cx={x - 6} cy={y + h / 2} r="2" fill="rgba(11,16,32,1)" stroke={accent} strokeWidth="1" />
      </>
    )}
    {ports.includes('out') && (
      <>
        <line x1={x + w} y1={y + h / 2} x2={x + w + 6} y2={y + h / 2} stroke={accent} strokeWidth="1" />
        <circle cx={x + w + 6} cy={y + h / 2} r="2" fill="rgba(11,16,32,1)" stroke={accent} strokeWidth="1" />
      </>
    )}
    {/* labels */}
    <text x={x + 8} y={y + 10} fontFamily={TOKENS.font.mono} fontSize="7"
          fill={accent} letterSpacing="0.18em" fontWeight="700">{(sublabel || 'NODE').toUpperCase()}</text>
    <text x={x + w / 2} y={y + h / 2 + 8} textAnchor="middle"
          fontFamily={TOKENS.font.body} fontSize="13" fontWeight="700"
          fill="#F5F7FF" letterSpacing="-0.01em">{label}</text>
  </g>
);

/* ─── A directional signal flow line with arrowhead + pulse ── */
const FlowLine = ({ d, color = '#5EA1FF', label, animate = true }) => {
  const id = `flow-${Math.random().toString(36).slice(2, 8)}`;
  return (
    <g>
      <defs>
        <marker id={`${id}-arrow`} viewBox="0 0 10 10" refX="8" refY="5"
                markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M0,0 L10,5 L0,10 Z" fill={color} />
        </marker>
      </defs>
      <path d={d} stroke={tint(color, 0.45)} strokeWidth="1" fill="none"
            strokeDasharray="3 4" markerEnd={`url(#${id}-arrow)`} />
      {animate && (
        <circle r="2.4" fill={color}>
          <animateMotion dur="3.5s" repeatCount="indefinite" path={d} />
        </circle>
      )}
      {label && (
        <text fontFamily={TOKENS.font.mono} fontSize="8" fill={tint(color, 0.85)}
              letterSpacing="0.18em" fontWeight="700">
          <textPath href={`#${id}-path`} startOffset="50%" textAnchor="middle">{label.toUpperCase()}</textPath>
        </text>
      )}
    </g>
  );
};

/* ─── SystemDiagram: configurable infrastructure layout ───── */
const DIAGRAM_PRESETS = {
  workflow: {
    width: 720, height: 200,
    blocks: [
      { id: 'a', x: 20,  y: 70, label: 'Visitor',    sub: 'CAPTURE', accent: '#5EA1FF', ports: ['out'] },
      { id: 'b', x: 180, y: 70, label: 'Identified', sub: 'ENRICH',  accent: '#22D3EE' },
      { id: 'c', x: 340, y: 70, label: 'Qualified',  sub: 'SCORE',   accent: '#A78BFA' },
      { id: 'd', x: 500, y: 70, label: 'Booked',     sub: 'COMMIT',  accent: '#34D399' },
      { id: 'e', x: 660, y: 70, label: 'Customer',   sub: 'LIFECYCLE', accent: '#F59E0B', ports: ['in'] },
    ],
    flows: [
      ['a','b','#5EA1FF'], ['b','c','#22D3EE'],
      ['c','d','#A78BFA'], ['d','e','#34D399'],
    ],
  },
  automation: {
    width: 720, height: 280,
    blocks: [
      { id: 't',  x: 20,  y: 108, label: 'Trigger',   sub: 'EVENT',    accent: '#22D3EE', ports: ['out'] },
      { id: 'c',  x: 220, y: 108, label: 'Condition', sub: 'EVALUATE', accent: '#5EA1FF', w: 140 },
      { id: 'a1', x: 440, y: 40,  label: 'Action',    sub: 'BRANCH·A', accent: '#A78BFA' },
      { id: 'a2', x: 440, y: 176, label: 'Action',    sub: 'BRANCH·B', accent: '#A78BFA' },
      { id: 'o',  x: 640, y: 108, label: 'Outcome',   sub: 'COMMIT',   accent: '#34D399', ports: ['in'] },
    ],
    flows: [
      ['t', 'c', '#22D3EE'],
      ['c', 'a1', '#A78BFA', 'MET'],
      ['c', 'a2', '#A78BFA', 'ELSE'],
      ['a1','o','#34D399'],
      ['a2','o','#34D399'],
    ],
  },
  ecosystem: {
    width: 720, height: 380,
    blocks: [
      { id: 'core',  x: 290, y: 158, w: 160, h: 80, label: 'Operating Layer', sub: 'CORE', accent: '#5EA1FF', ports: [] },
      { id: 'site',  x: 30,  y: 50,  label: 'WordPress',  sub: 'SURFACE',  accent: '#22D3EE', ports: ['out'] },
      { id: 'crm',   x: 30,  y: 270, label: 'CRMistic',   sub: 'DECISION', accent: '#A78BFA', ports: ['out'] },
      { id: 'chat',  x: 290, y: 30,  w: 160, h: 56, label: 'Chatbotistic', sub: 'SIGNAL', accent: '#22D3EE', ports: [] },
      { id: 'book',  x: 560, y: 50,  label: 'Bookingistic', sub: 'ORCHESTRATION', accent: '#34D399', ports: ['in'] },
      { id: 'pay',   x: 560, y: 270, label: 'Payments',   sub: 'COMMIT',   accent: '#F472B6', ports: ['in'] },
      { id: 'ai',    x: 290, y: 310, w: 160, h: 56, label: 'WPAgentistic', sub: 'AUTONOMY', accent: '#A78BFA', ports: [] },
    ],
    flows: [
      ['site','core','#22D3EE'], ['crm','core','#A78BFA'],
      ['chat','core','#22D3EE','vertical'], ['core','book','#34D399'],
      ['core','pay','#F472B6'], ['ai','core','#A78BFA','vertical'],
    ],
  },
  pipeline: {
    width: 720, height: 200,
    blocks: [
      { id: 'new',  x: 20,  y: 70, label: 'New',       sub: '01·STAGE', accent: '#5EA1FF', ports: ['out'] },
      { id: 'wrk',  x: 180, y: 70, label: 'Working',   sub: '02·STAGE', accent: '#22D3EE' },
      { id: 'qua',  x: 340, y: 70, label: 'Qualified', sub: '03·STAGE', accent: '#A78BFA' },
      { id: 'won',  x: 500, y: 70, label: 'Won',       sub: '04·CLOSE', accent: '#34D399' },
      { id: 'lc',   x: 660, y: 70, label: 'Lifecycle', sub: '05·KEEP',  accent: '#F59E0B', ports: ['in'] },
    ],
    flows: [
      ['new','wrk','#22D3EE'], ['wrk','qua','#A78BFA'],
      ['qua','won','#34D399'], ['won','lc','#F59E0B'],
    ],
  },
};

const SystemDiagram = ({ preset = 'workflow' }) => {
  const cfg = DIAGRAM_PRESETS[preset];
  if (!cfg) return null;
  const blockMap = Object.fromEntries(cfg.blocks.map(b => [b.id, b]));

  const flowPath = (f, t, vertical) => {
    const fw = f.w || 130, fh = f.h || 64;
    const tw = t.w || 130, th = t.h || 64;
    if (vertical === 'vertical') {
      const fx = f.x + fw / 2, fy = f.y < t.y ? f.y + fh : f.y;
      const tx = t.x + tw / 2, ty = f.y < t.y ? t.y : t.y + th;
      return `M${fx},${fy} L${tx},${ty}`;
    }
    const fx = f.x + fw, fy = f.y + fh / 2;
    const tx = t.x,      ty = t.y + th / 2;
    if (Math.abs(fy - ty) < 4) return `M${fx + 6},${fy} L${tx - 6},${ty}`;
    // gentle S-curve
    const mx = (fx + tx) / 2;
    return `M${fx + 6},${fy} C${mx},${fy} ${mx},${ty} ${tx - 6},${ty}`;
  };

  return (
    <svg viewBox={`0 0 ${cfg.width} ${cfg.height}`}
         style={{ width: '100%', height: '100%', display: 'block', overflow: 'visible' }}>
      {/* substrate grid */}
      <defs>
        <pattern id={`sg-${preset}`} width="16" height="16" patternUnits="userSpaceOnUse">
          <path d="M 16 0 L 0 0 0 16" fill="none" stroke="rgba(120,150,255,0.06)" strokeWidth="0.5" />
        </pattern>
      </defs>
      <rect width={cfg.width} height={cfg.height} fill={`url(#sg-${preset})`} />

      {/* flows behind blocks */}
      {cfg.flows.map(([fId, tId, color, mark], i) => {
        const f = blockMap[fId], t = blockMap[tId];
        return <FlowLine key={i} d={flowPath(f, t, mark)} color={color} label={mark !== 'vertical' ? mark : null} />;
      })}

      {/* blocks */}
      {cfg.blocks.map(b => (
        <SystemBlock key={b.id} x={b.x} y={b.y} w={b.w} h={b.h}
                     accent={b.accent} label={b.label} sublabel={b.sub} ports={b.ports} />
      ))}
    </svg>
  );
};

/* ─── LayerStack: explicit 4-layer infrastructure rendering ─ */
const LayerStack = ({ accent = '#5EA1FF', dense = false }) => {
  const layers = [
    { n: 1, name: 'Infrastructure',     sub: 'Blueprint grid · routing topology',     accent: '#5EA1FF' },
    { n: 2, name: 'System Flow',        sub: 'Orchestration pathways · triggers',     accent: '#22D3EE' },
    { n: 3, name: 'Operational UI',     sub: 'Dashboards · panels · workflows',       accent: '#A78BFA' },
    { n: 4, name: 'Human Intelligence', sub: 'Insights · decisions · operator action',accent: '#34D399' },
  ];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: dense ? 6 : 10 }}>
      {layers.map(L => (
        <div key={L.n} style={{
          display: 'grid', gridTemplateColumns: '60px 1fr auto',
          alignItems: 'center', gap: 14,
          padding: dense ? '10px 14px' : '14px 18px',
          background: 'linear-gradient(90deg, rgba(20,27,45,0.85), rgba(11,16,32,0.5))',
          border: `1px solid ${tint(L.accent, 0.22)}`,
          borderLeft: `2px solid ${L.accent}`,
          borderRadius: 4,
        }}>
          <LayerTag n={L.n} accent={L.accent} />
          <div>
            <div style={{ fontSize: dense ? 13 : 15, fontWeight: 700, color: TOKENS.fg.primary, letterSpacing: '-0.01em' }}>{L.name}</div>
            <div style={{ fontFamily: TOKENS.font.mono, fontSize: 10, color: TOKENS.fg.tertiary,
                          letterSpacing: '0.16em', textTransform: 'uppercase', marginTop: 2 }}>{L.sub}</div>
          </div>
          <StatusDot color={L.accent} size={6} label="ONLINE" />
        </div>
      ))}
    </div>
  );
};

/* legacy alias for code that still says NodeDiagram */
const NodeDiagram = ({ preset }) => <SystemDiagram preset={preset} />;

Object.assign(window, { SystemBlock, FlowLine, SystemDiagram, LayerStack, NodeDiagram, DIAGRAM_PRESETS });
