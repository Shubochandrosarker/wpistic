// atoms.jsx — the Blueprint Operational Flow System primitives.
// Globally registered:
//   Frame · BlueprintGrid · AmbientGlow · CornerMarks · Crosshair
//   Eyebrow · SystemLabel · StatusDot · LayerTag · Pill · Logo
//   InfraPanel · Button · Kicker · MeasureLine

const { useEffect, useRef, useState } = React;

/* ─── Frame: the canvas for every artboard ────────────────── */
const Frame = ({ width, height, padding = 0, bg, grid = true, glows = true,
                 measurements = true, rails = true, children, style }) => (
  <div style={{
    position: 'relative', width, height, overflow: 'hidden',
    background: bg || 'radial-gradient(ellipse at 50% 10%, #0B1530 0%, #050912 70%)',
    color: TOKENS.fg.primary, padding,
    fontFamily: TOKENS.font.body,
    isolation: 'isolate',
    ...style,
  }}>
    {grid && <BlueprintGrid measurements={measurements} />}
    {rails && <RoutingRails />}
    {glows && <AmbientGlow />}
    {children}
  </div>
);

/* ─── RoutingRails: THE signature geometry.
   Directional infrastructure rails with junctions + travelling signals.
   This is the WordPressistic visual fingerprint — present on every frame. ── */
const RoutingRails = ({ color = 'rgba(120,150,255,0.16)' }) => (
  <svg aria-hidden viewBox="0 0 1000 1000" preserveAspectRatio="none"
       style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 0 }}>
    {/* orthogonal rail runs with rounded right-angle turns */}
    {[
      'M0,140 H180 Q210,140 210,170 V360',
      'M1000,80 H760 Q730,80 730,110 V300 Q730,330 700,330 H520',
      'M0,860 H300 Q330,860 330,830 V640',
      'M1000,920 H680 Q650,920 650,890 V700',
    ].map((d, i) => (
      <g key={i}>
        <path d={d} fill="none" stroke={color} strokeWidth="1" />
        <path d={d} fill="none" stroke="rgba(94,161,255,0.5)" strokeWidth="1"
              strokeDasharray="3 7" className="op-flow" style={{ animationDelay: `${i * 1.4}s` }} />
      </g>
    ))}
    {/* junction dots */}
    {[[210, 170], [730, 110], [330, 830], [650, 890], [520, 330]].map(([x, y], i) => (
      <g key={`j${i}`}>
        <circle cx={x} cy={y} r="3" fill="rgba(94,161,255,0.7)" />
        <circle cx={x} cy={y} r="3" fill="none" stroke="rgba(94,161,255,0.5)" strokeWidth="1" className="op-pulse" style={{ animationDelay: `${i * 0.5}s` }} />
      </g>
    ))}
  </svg>
);

/* ─── BlueprintGrid: 8/64px nested + ruler ticks ──────────── */
const BlueprintGrid = ({ minor = 'rgba(120,150,255,0.04)',
                         major = 'rgba(120,150,255,0.10)',
                         measurements = true }) => (
  <div aria-hidden style={{
    position: 'absolute', inset: 0, pointerEvents: 'none',
    backgroundImage: [
      `linear-gradient(${minor} 1px, transparent 1px)`,
      `linear-gradient(90deg, ${minor} 1px, transparent 1px)`,
      `linear-gradient(${major} 1px, transparent 1px)`,
      `linear-gradient(90deg, ${major} 1px, transparent 1px)`,
    ].join(','),
    backgroundSize: '8px 8px, 8px 8px, 64px 64px, 64px 64px',
    maskImage: 'radial-gradient(ellipse at 50% 40%, #000 35%, transparent 80%)',
  }}>
    {measurements && (
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {/* top ruler */}
        {Array.from({ length: 40 }).map((_, i) => (
          <line key={`t${i}`} x1={i * 64} y1={0} x2={i * 64} y2={i % 4 === 0 ? 8 : 4}
                stroke="rgba(120,150,255,0.35)" strokeWidth="0.6" />
        ))}
        {/* left ruler */}
        {Array.from({ length: 30 }).map((_, i) => (
          <line key={`l${i}`} x1={0} y1={i * 64} x2={i % 4 === 0 ? 8 : 4} y2={i * 64}
                stroke="rgba(120,150,255,0.35)" strokeWidth="0.6" />
        ))}
      </svg>
    )}
  </div>
);

/* ─── AmbientGlow: controlled, not decorative ─────────────── */
const AmbientGlow = ({ colors = ['#5EA1FF', '#22D3EE'] }) => (
  <>
    <div aria-hidden style={{
      position: 'absolute', top: '-30%', left: '-15%', width: '70%', height: '90%',
      background: `radial-gradient(circle at 50% 50%, ${tint(colors[0], 0.28)}, transparent 60%)`,
      filter: 'blur(80px)', pointerEvents: 'none',
    }} />
    <div aria-hidden style={{
      position: 'absolute', bottom: '-30%', right: '-15%', width: '60%', height: '80%',
      background: `radial-gradient(circle at 50% 50%, ${tint(colors[1], 0.20)}, transparent 60%)`,
      filter: 'blur(90px)', pointerEvents: 'none',
    }} />
  </>
);

/* ─── Crosshair marker (single) ───────────────────────────── */
const Crosshair = ({ x, y, size = 16, color = 'rgba(120,150,255,0.5)' }) => (
  <svg style={{ position: 'absolute', left: x - size / 2, top: y - size / 2, pointerEvents: 'none' }}
       width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
    <path d={`M${size/2} 0v${size} M0 ${size/2}h${size}`} stroke={color} strokeWidth="0.7" />
    <circle cx={size/2} cy={size/2} r={3} fill="none" stroke={color} strokeWidth="0.7" />
  </svg>
);

/* ─── Corner brackets (all 4) ─────────────────────────────── */
const CornerMarks = ({ inset = 20, color = 'rgba(120,150,255,0.45)', size = 14 }) => {
  const positions = [
    [inset, inset, 'tl'],
    [`calc(100% - ${inset + size}px)`, inset, 'tr'],
    [inset, `calc(100% - ${inset + size}px)`, 'bl'],
    [`calc(100% - ${inset + size}px)`, `calc(100% - ${inset + size}px)`, 'br'],
  ];
  return positions.map(([l, t, k]) => {
    const paths = {
      tl: `M0 ${size} V0 H${size}`, tr: `M0 0 H${size} V${size}`,
      bl: `M0 0 V${size} H${size}`, br: `M${size} 0 V${size} H0`,
    }[k];
    return (
      <svg key={k} width={size} height={size} viewBox={`0 0 ${size} ${size}`}
           style={{ position: 'absolute', left: l, top: t, pointerEvents: 'none' }}>
        <path d={paths} stroke={color} strokeWidth="1" fill="none" />
      </svg>
    );
  });
};

/* ─── MeasureLine: dimensional notation for blueprint feel ── */
const MeasureLine = ({ orientation = 'h', length = 100, label, color = 'rgba(120,150,255,0.45)' }) => {
  const w = orientation === 'h' ? length : 14;
  const h = orientation === 'h' ? 14 : length;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: 'inline-block', overflow: 'visible' }}>
      {orientation === 'h' ? (
        <>
          <line x1="1" y1="7" x2={w - 1} y2="7" stroke={color} strokeWidth="0.6" />
          <line x1="1" y1="2" x2="1" y2="12" stroke={color} strokeWidth="0.6" />
          <line x1={w - 1} y1="2" x2={w - 1} y2="12" stroke={color} strokeWidth="0.6" />
        </>
      ) : (
        <>
          <line x1="7" y1="1" x2="7" y2={h - 1} stroke={color} strokeWidth="0.6" />
          <line x1="2" y1="1" x2="12" y2="1" stroke={color} strokeWidth="0.6" />
          <line x1="2" y1={h - 1} x2="12" y2={h - 1} stroke={color} strokeWidth="0.6" />
        </>
      )}
      {label && (
        <text x={orientation === 'h' ? w / 2 : 18} y={orientation === 'h' ? -3 : h / 2 + 3}
              textAnchor={orientation === 'h' ? 'middle' : 'start'}
              fontFamily={TOKENS.font.mono} fontSize="9" fill={color}
              letterSpacing="0.18em">{label}</text>
      )}
    </svg>
  );
};

/* ─── Editorial typography atoms ──────────────────────────── */
const Eyebrow = ({ color = TOKENS.accent.cyan, children }) => (
  <span style={{
    fontFamily: TOKENS.font.mono, fontSize: 11, color,
    letterSpacing: '0.24em', textTransform: 'uppercase', fontWeight: 600,
  }}>{children}</span>
);

/* ─── SystemLabel: the operational status microcopy unit ──── */
const SystemLabel = ({ children, color = TOKENS.accent.blue, prefix = '◈' }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 8,
    fontFamily: TOKENS.font.mono, fontSize: 10,
    color: TOKENS.fg.tertiary, letterSpacing: '0.22em',
    textTransform: 'uppercase', fontWeight: 600,
  }}>
    <span style={{ color, fontSize: 11 }}>{prefix}</span>
    {children}
  </span>
);

/* ─── StatusDot: live-system indicator ────────────────────── */
const StatusDot = ({ color = TOKENS.accent.success, label, pulse = true, size = 8 }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
    <span style={{
      position: 'relative', display: 'inline-block', width: size, height: size,
    }}>
      <span style={{
        position: 'absolute', inset: 0, borderRadius: '50%',
        background: color, boxShadow: `0 0 ${size}px ${color}`,
      }} />
      {pulse && (
        <span style={{
          position: 'absolute', inset: -3, borderRadius: '50%',
          border: `1px solid ${color}`, opacity: 0.5,
        }} />
      )}
    </span>
    {label && (
      <span style={{
        fontFamily: TOKENS.font.mono, fontSize: 10, color: TOKENS.fg.tertiary,
        letterSpacing: '0.20em', textTransform: 'uppercase', fontWeight: 600,
      }}>{label}</span>
    )}
  </span>
);

/* ─── LayerTag: depth-layer indicator (LAYER 01..04) ──────── */
const LayerTag = ({ n, label, accent = TOKENS.accent.blue }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10,
                 fontFamily: TOKENS.font.mono, fontSize: 10, letterSpacing: '0.22em',
                 textTransform: 'uppercase', fontWeight: 700 }}>
    <span style={{
      padding: '4px 9px', borderRadius: 4,
      background: tint(accent, 0.12), border: `1px solid ${tint(accent, 0.38)}`,
      color: accent,
    }}>{`L${String(n).padStart(2, '0')}`}</span>
    {label && <span style={{ color: TOKENS.fg.tertiary }}>{label}</span>}
  </span>
);

const Pill = ({ color, text, border, children }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 8,
    padding: '5px 11px', borderRadius: 4,
    background: color || tint(TOKENS.accent.cyan, 0.08),
    color: text || TOKENS.accent.cyan,
    border: `1px solid ${border || tint(TOKENS.accent.cyan, 0.32)}`,
    fontFamily: TOKENS.font.mono, fontSize: 10, letterSpacing: '0.18em',
    fontWeight: 700, textTransform: 'uppercase',
  }}>{children}</span>
);

const Logo = ({ size = 22, label = true, color = TOKENS.fg.primary }) => {
  const id = `lg-${size}`;
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 11 }}>
      <svg width={size} height={size} viewBox="0 0 32 32" style={{ display: 'block' }}>
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#5EA1FF" /><stop offset="100%" stopColor="#22D3EE" />
          </linearGradient>
        </defs>
        {/* infrastructure mark: routing node — a W formed from signal rails with IO ports */}
        <rect x="1.5" y="1.5" width="29" height="29" rx="2" fill="none" stroke={`url(#${id})`} strokeWidth="1" opacity="0.5" />
        {/* IO ports on the routing node */}
        <circle cx="1.5" cy="16" r="1.6" fill="#5EA1FF" />
        <circle cx="30.5" cy="16" r="1.6" fill="#22D3EE" />
        {/* the W as a directional rail path */}
        <path d="M6 8 L10.5 23 L16 12 L21.5 23 L26 8" fill="none"
              stroke={`url(#${id})`} strokeWidth="2" strokeLinejoin="miter" strokeLinecap="square" />
        {/* junction node at center vertex */}
        <circle cx="16" cy="12" r="1.8" fill="#070A11" stroke={`url(#${id})`} strokeWidth="1.2" />
      </svg>
      {label && (
        <span style={{ display: 'inline-flex', flexDirection: 'column', lineHeight: 1 }}>
          <span style={{ fontSize: size * 0.66, fontWeight: 800, letterSpacing: '-0.02em', color }}>
            WordPressistic
          </span>
          {size >= 24 && (
            <span style={{ fontFamily: TOKENS.font.mono, fontSize: size * 0.26,
              color: TOKENS.fg.tertiary, letterSpacing: '0.24em', textTransform: 'uppercase', marginTop: 3 }}>
              Operating Layer
            </span>
          )}
        </span>
      )}
    </div>
  );
};

/* ─── QueueIndicator: operational pressure — a processing bar ── */
const QueueIndicator = ({ accent = TOKENS.signal.primary, label = 'PROCESSING', width = 120 }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
    <span style={{ position: 'relative', width, height: 4, borderRadius: 2,
      background: 'rgba(140,160,200,0.10)', overflow: 'hidden', display: 'inline-block' }}>
      <span className="op-queue" style={{ position: 'absolute', inset: 0 }} />
    </span>
    <span style={{ fontFamily: TOKENS.font.mono, fontSize: 9, color: TOKENS.fg.tertiary,
      letterSpacing: '0.20em', textTransform: 'uppercase', fontWeight: 700 }}>{label}</span>
  </span>
);

/* ─── Meter: a small operational read-out (queue depth, load) ── */
const Meter = ({ value = 0.6, accent = TOKENS.signal.primary, label, reading }) => (
  <div>
    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
      <span style={{ fontFamily: TOKENS.font.mono, fontSize: 9, color: TOKENS.fg.tertiary,
        letterSpacing: '0.18em', textTransform: 'uppercase', fontWeight: 700 }}>{label}</span>
      <span style={{ fontFamily: TOKENS.font.mono, fontSize: 10, color: accent, fontWeight: 700 }}>{reading}</span>
    </div>
    <div style={{ height: 4, borderRadius: 2, background: 'rgba(140,160,200,0.10)', overflow: 'hidden' }}>
      <div style={{ height: '100%', width: `${value * 100}%`,
        background: `linear-gradient(90deg, ${tint(accent, 0.5)}, ${accent})`, borderRadius: 2 }} />
    </div>
  </div>
);

/* ─── InfraPanel: an operational panel with status bar.
   Replaces glassmorphism for serious infrastructure surfaces. ─── */
const InfraPanel = ({ children, padding = 22, accent = TOKENS.accent.blue,
                      label, status = 'ACTIVE', flush = false, style }) => (
  <div style={{
    position: 'relative',
    background: 'linear-gradient(180deg, rgba(20,27,45,0.85), rgba(11,16,32,0.92))',
    border: `1px solid ${tint(accent, 0.22)}`,
    borderRadius: flush ? 0 : 6,
    overflow: 'hidden',
    ...style,
  }}>
    {label && (
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '10px 16px',
        background: tint(accent, 0.08),
        borderBottom: `1px solid ${tint(accent, 0.22)}`,
      }}>
        <SystemLabel color={accent}>{label}</SystemLabel>
        <StatusDot color={accent} label={status} size={6} />
      </div>
    )}
    <div style={{ padding }}>{children}</div>
  </div>
);

/* ─── Button: pill-shaped, with operational arrow ────────── */
const Button = ({ children, variant = 'primary', size = 'md', accent = TOKENS.accent.blue }) => {
  const sizes = {
    sm: { p: '9px 16px', fs: 12, r: 4 },
    md: { p: '13px 22px', fs: 14, r: 5 },
    lg: { p: '17px 28px', fs: 15, r: 6 },
  }[size];
  const styles = variant === 'primary' ? {
    background: `linear-gradient(135deg, ${accent}, ${tint(accent, 0.9)})`,
    color: '#fff', border: `1px solid ${tint(accent, 0.6)}`,
    boxShadow: `0 6px 24px ${tint(accent, 0.4)}, inset 0 1px 0 rgba(255,255,255,0.18)`,
  } : variant === 'ghost' ? {
    background: 'transparent', color: TOKENS.fg.primary,
    border: `1px solid ${TOKENS.line.default}`,
  } : {
    background: tint(accent, 0.10), color: accent,
    border: `1px solid ${tint(accent, 0.32)}`,
  };
  return (
    <button style={{
      padding: sizes.p, borderRadius: sizes.r, fontSize: sizes.fs,
      fontWeight: 700, cursor: 'pointer',
      fontFamily: TOKENS.font.body, letterSpacing: '-0.005em',
      display: 'inline-flex', alignItems: 'center', gap: 10,
      ...styles,
    }}>{children}</button>
  );
};

/* ─── Kicker: chapter/section title pattern ───────────────── */
const Kicker = ({ no, label, accent = TOKENS.accent.blue }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
    <span style={{
      fontFamily: TOKENS.font.mono, fontSize: 11, fontWeight: 700,
      color: accent, letterSpacing: '0.24em',
    }}>{no}</span>
    <span style={{ flex: 1, maxWidth: 100, height: 1,
                   background: `linear-gradient(90deg, ${tint(accent, 0.5)}, transparent)` }} />
    <span style={{
      fontFamily: TOKENS.font.mono, fontSize: 10, color: TOKENS.fg.tertiary,
      letterSpacing: '0.20em', textTransform: 'uppercase',
    }}>{label}</span>
  </div>
);

Object.assign(window, {
  Frame, BlueprintGrid, RoutingRails, AmbientGlow, Crosshair, CornerMarks, MeasureLine,
  Eyebrow, SystemLabel, StatusDot, LayerTag, Pill, Logo,
  InfraPanel, Button, Kicker, QueueIndicator, Meter,
});
