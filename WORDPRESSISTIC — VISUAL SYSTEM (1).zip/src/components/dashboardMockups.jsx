// dashboardMockups.jsx — operational UI mockups slotted into InfraPanel.
// Each is a Layer-3 visualization for its tool's behavior.
// Registered: ChatMockup, CalendarMockup, PipelineMockup, MembersMockup,
// LicenseMockup, AnalyticsMockup, AgentMockup, DashboardMockup (dispatch)

const Bar = ({ w = '60%', h = 6, c = 'rgba(255,255,255,0.08)' }) => (
  <span style={{ display: 'block', width: w, height: h, borderRadius: 2, background: c }} />
);

const RowLabel = ({ children, color = TOKENS.fg.tertiary }) => (
  <span style={{
    fontFamily: TOKENS.font.mono, fontSize: 9, color,
    letterSpacing: '0.18em', textTransform: 'uppercase', fontWeight: 700,
  }}>{children}</span>
);

const Row = ({ children, style }) => (
  <div style={{
    display: 'flex', alignItems: 'center', gap: 10,
    padding: '8px 12px',
    background: 'linear-gradient(90deg, rgba(20,27,45,0.6), rgba(11,16,32,0.3))',
    borderLeft: '1px solid rgba(120,150,255,0.18)',
    ...style,
  }}>{children}</div>
);

const ChatMockup = ({ accent = '#22D3EE' }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
      <RowLabel color={accent}>UNIFIED INBOX · ROUTING</RowLabel>
      <StatusDot color="#34D399" size={5} label="LIVE" />
    </div>
    {[
      ['IN',  'How much for 5 seats?',                       '#5EA1FF'],
      ['AI',  'Starter $39 · I can hold a slot Thu 3pm.',    accent],
      ['IN',  'Yes — Thursday works.',                       '#5EA1FF'],
      ['SYS', 'BOOKED · CRM · INVOICE · CONFIRMED',          '#34D399'],
    ].map(([who, msg, c], i) => (
      <Row key={i} style={{ borderLeftColor: c }}>
        <span style={{
          fontFamily: TOKENS.font.mono, fontSize: 9, color: c,
          letterSpacing: '0.16em', fontWeight: 700, minWidth: 24,
        }}>{who}</span>
        <span style={{
          fontSize: 12, color: TOKENS.fg.primary,
          fontFamily: who === 'SYS' ? TOKENS.font.mono : TOKENS.font.body,
          letterSpacing: who === 'SYS' ? '0.10em' : 0,
        }}>{msg}</span>
      </Row>
    ))}
  </div>
);

const CalendarMockup = ({ accent = '#5EA1FF' }) => (
  <div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
      <RowLabel color={accent}>SCHEDULE · ORCHESTRATION</RowLabel>
      <RowLabel>3 BOOKED · 2 HELD</RowLabel>
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8 }}>
      {['MON 04', 'TUE 05', 'WED 06'].map((d, i) => (
        <div key={d} style={{
          padding: 8, background: 'rgba(20,27,45,0.7)',
          border: '1px solid rgba(120,150,255,0.18)', borderRadius: 4,
        }}>
          <RowLabel color={accent}>{d}</RowLabel>
          {['09:00', '11:30', '14:00'].map((t, k) => (
            <div key={t} style={{
              marginTop: 6, padding: '5px 7px', borderRadius: 3,
              background: tint(accent, k === 1 ? 0.20 : 0.06),
              borderLeft: `2px solid ${tint(accent, k === 1 ? 0.6 : 0.25)}`,
              fontSize: 10, color: TOKENS.fg.primary, fontWeight: 600,
            }}>
              <span style={{ fontFamily: TOKENS.font.mono, letterSpacing: '0.10em' }}>{t}</span>
              <div style={{ fontSize: 9, color: TOKENS.fg.tertiary, marginTop: 1 }}>{k === 1 ? 'Discovery · paid' : 'Hold'}</div>
            </div>
          ))}
        </div>
      ))}
    </div>
  </div>
);

const PipelineMockup = ({ accent = '#34D399' }) => (
  <div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
      <RowLabel color={accent}>PIPELINE · PROGRESSION</RowLabel>
      <RowLabel>5 STAGES · SLA ACTIVE</RowLabel>
    </div>
    {['New', 'Working', 'Qualified', 'Booked', 'Won'].map((s, i) => (
      <div key={s} style={{ display: 'grid', gridTemplateColumns: '26px 90px 1fr 32px',
        alignItems: 'center', gap: 10, marginTop: 6,
        padding: '6px 10px', background: 'rgba(20,27,45,0.5)',
        borderLeft: `1px solid ${tint(accent, 0.3)}`,
      }}>
        <span style={{
          width: 22, height: 18, fontFamily: TOKENS.font.mono, fontSize: 9,
          color: accent, fontWeight: 700, letterSpacing: '0.12em',
          background: tint(accent, 0.12), border: `1px solid ${tint(accent, 0.4)}`,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center', borderRadius: 2,
        }}>0{i + 1}</span>
        <span style={{ fontSize: 12, color: TOKENS.fg.primary, fontWeight: 600 }}>{s}</span>
        <span style={{ height: 4, background: tint(accent, 0.4), display: 'block',
          width: `${[88, 64, 46, 32, 20][i]}%`, borderRadius: 1 }} />
        <span style={{ fontFamily: TOKENS.font.mono, fontSize: 10, color: TOKENS.fg.secondary, textAlign: 'right' }}>{[42, 28, 19, 11, 7][i]}</span>
      </div>
    ))}
  </div>
);

const MembersMockup = ({ accent = '#A78BFA' }) => (
  <div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
      <RowLabel color={accent}>ACCESS LEDGER · ENTITLEMENT</RowLabel>
      <StatusDot color={accent} size={5} label="SYNCED" />
    </div>
    {[
      ['L01 · Pro · Annual',    'ACTIVE',   '#34D399'],
      ['L01 · Pro · Monthly',   'ACTIVE',   '#34D399'],
      ['L02 · Studio · Annual', 'PAST DUE', '#F87171'],
      ['L00 · Trial',           'TRIALING', accent],
    ].map(([tier, st, c], i) => (
      <Row key={i} style={{ borderLeftColor: c, justifyContent: 'space-between', marginTop: 5 }}>
        <span style={{ fontFamily: TOKENS.font.mono, fontSize: 11, color: TOKENS.fg.primary,
          letterSpacing: '0.10em' }}>{tier}</span>
        <span style={{ fontFamily: TOKENS.font.mono, fontSize: 9, color: c,
          letterSpacing: '0.16em', fontWeight: 700 }}>{st}</span>
      </Row>
    ))}
  </div>
);

const LicenseMockup = ({ accent = '#F59E0B' }) => (
  <div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
      <RowLabel color={accent}>VALIDATION GATES · AUTH PATH</RowLabel>
      <StatusDot color={accent} size={5} label="LEDGER OK" />
    </div>
    {[
      ['LK-A912-77F1', 'VALID',   '12 seats',  '#34D399'],
      ['LK-B431-22A0', 'VALID',   '3 seats',   '#34D399'],
      ['LK-C108-99B2', 'EXPIRED', '\u2014',          '#F87171'],
      ['LK-D207-44C8', 'PENDING', 'awaiting',  accent],
    ].map(([k, st, q, c], i) => (
      <Row key={i} style={{ borderLeftColor: c, marginTop: 5,
        display: 'grid', gridTemplateColumns: '110px 70px 1fr 14px', alignItems: 'center' }}>
        <span style={{ fontFamily: TOKENS.font.mono, fontSize: 11, color: TOKENS.fg.primary, letterSpacing: '0.08em' }}>{k}</span>
        <span style={{ fontFamily: TOKENS.font.mono, fontSize: 9, color: c, letterSpacing: '0.16em', fontWeight: 700 }}>{st}</span>
        <span style={{ fontSize: 11, color: TOKENS.fg.tertiary }}>{q}</span>
        <span style={{ width: 8, height: 8, background: c, borderRadius: '50%', boxShadow: `0 0 6px ${c}` }} />
      </Row>
    ))}
  </div>
);

const AnalyticsMockup = ({ accent = '#5EA1FF' }) => {
  const data = [22, 28, 24, 36, 32, 44, 48, 52, 46, 58, 64, 70];
  const max = 80;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <RowLabel color={accent}>INTELLIGENCE · SIGNAL MAP</RowLabel>
        <RowLabel>12W \u00b7 CONVERSION</RowLabel>
      </div>
      <div style={{ background: 'rgba(20,27,45,0.6)', border: '1px solid rgba(120,150,255,0.18)',
                    padding: 12, borderRadius: 4 }}>
        <svg viewBox="0 0 360 130" style={{ width: '100%', height: 130 }}>
          <defs>
            <linearGradient id="ang" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor={accent} stopOpacity="0.40" />
              <stop offset="100%" stopColor={accent} stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0, 30, 60, 90].map(y => (
            <line key={y} x1="0" y1={y + 10} x2="360" y2={y + 10} stroke="rgba(120,150,255,0.10)" strokeWidth="0.5" />
          ))}
          <polyline fill="url(#ang)" stroke="none"
            points={`0,120 ${data.map((v, i) => `${i * 30 + 15},${120 - (v / max) * 100}`).join(' ')} 360,120`} />
          <polyline fill="none" stroke={accent} strokeWidth="1.5"
            points={data.map((v, i) => `${i * 30 + 15},${120 - (v / max) * 100}`).join(' ')} />
          {data.map((v, i) => (
            <circle key={i} cx={i * 30 + 15} cy={120 - (v / max) * 100} r="1.8" fill={accent} />
          ))}
        </svg>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6, marginTop: 8 }}>
        {[['SESSIONS', '12.4K', accent], ['CONV', '4.2%', '#34D399'], ['REV', '$38K', '#A78BFA']].map(([l, v, c]) => (
          <div key={l} style={{ padding: '6px 10px', background: 'rgba(20,27,45,0.6)',
            borderLeft: `1px solid ${tint(c, 0.4)}` }}>
            <RowLabel>{l}</RowLabel>
            <div style={{ fontSize: 16, fontWeight: 800, color: c, letterSpacing: '-0.02em', marginTop: 2 }}>{v}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

const AgentMockup = ({ accent = '#F472B6' }) => (
  <div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
      <RowLabel color={accent}>AGENT \u00b7 QUOTE-AND-BOOK</RowLabel>
      <StatusDot color={accent} size={5} label="RUNNING" />
    </div>
    {[
      ['GOAL',  'Turn pricing chat into held slot',  TOKENS.fg.primary],
      ['TOOL',  'pricing.lookup()',                  accent],
      ['TOOL',  'slot.find(date_range)',             accent],
      ['TOOL',  'slot.hold(ttl=10m)',                accent],
      ['TOOL',  'crm.upsert(stage=Booked)',          accent],
      ['GUARD', 'discount > 10% \u2192 escalate',           '#F59E0B'],
    ].map(([k, v, c], i) => (
      <Row key={i} style={{ borderLeftColor: c, marginTop: 5,
        display: 'grid', gridTemplateColumns: '54px 1fr', alignItems: 'center' }}>
        <span style={{ fontFamily: TOKENS.font.mono, fontSize: 9, color: c,
          letterSpacing: '0.16em', fontWeight: 700 }}>{k}</span>
        <span style={{ fontSize: 11, color: TOKENS.fg.primary,
          fontFamily: k === 'GOAL' ? TOKENS.font.body : TOKENS.font.mono,
          letterSpacing: k === 'GOAL' ? 0 : '0.04em' }}>{v}</span>
      </Row>
    ))}
  </div>
);

const MOCKUPS = {
  chat: ChatMockup, calendar: CalendarMockup, pipeline: PipelineMockup,
  members: MembersMockup, license: LicenseMockup, analytics: AnalyticsMockup,
  agent: AgentMockup,
};

const DashboardMockup = ({ type, accent }) => {
  const C = MOCKUPS[type] || ChatMockup;
  return <C accent={accent} />;
};

Object.assign(window, {
  DashboardMockup,
  ChatMockup, CalendarMockup, PipelineMockup, MembersMockup,
  LicenseMockup, AnalyticsMockup, AgentMockup,
});
