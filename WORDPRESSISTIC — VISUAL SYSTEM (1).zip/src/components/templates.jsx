// templates.jsx — operational layout templates.
// HeroTemplate, EbookCoverTemplate, EbookPageTemplate, AdTemplate, ToolFeaturedImageTemplate.
// All asymmetric, directional, infrastructure-led (no centered SaaS heroes).

// ─── Shared chrome bars ────────────────────────────────────
const TopChrome = ({ accent, status, edition, inset = 60 }) => (
  <div style={{
    position: 'absolute', top: 28, left: inset, right: inset, zIndex: 4,
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
  }}>
    <Logo size={26} />
    <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
      <SystemLabel color={accent}>{status || COPY.status.connected}</SystemLabel>
      {edition && <Pill text={accent} color={tint(accent, 0.10)} border={tint(accent, 0.32)}>{edition}</Pill>}
    </div>
  </div>
);

const BottomChrome = ({ inset = 60, extra }) => (
  <div style={{
    position: 'absolute', bottom: 28, left: inset, right: inset, zIndex: 4,
    display: 'flex', justifyContent: 'space-between',
    fontFamily: TOKENS.font.mono, fontSize: 10, color: TOKENS.fg.quaternary,
    letterSpacing: '0.20em', textTransform: 'uppercase',
  }}>
    <span>{COPY.brand.tagline}</span>
    {extra && <span>{extra}</span>}
    <span>{COPY.brand.domain}</span>
  </div>
);

// ─── HeroTemplate ──────────────────────────────────────────
// Asymmetric infrastructure composition; never centered SaaS hero.
const HeroTemplate = ({ angle, layout = 'directional', children }) => {
  const { eyebrow, title, sub, accent, status } = angle;

  const Title = () => (
    <h1 style={{
      fontSize: 92, fontWeight: 800, letterSpacing: '-0.045em',
      lineHeight: 0.96, margin: '20px 0 24px', textWrap: 'pretty',
    }}>
      {title.map((line, i) => (
        <span key={i} style={{
          display: 'block',
          color: i === title.length - 1 ? accent : TOKENS.fg.primary,
        }}>{line}</span>
      ))}
    </h1>
  );

  const Sub = () => (
    <p style={{
      fontSize: 19, color: TOKENS.fg.secondary, lineHeight: 1.55,
      maxWidth: 640, margin: 0, textWrap: 'pretty',
    }}>{sub}</p>
  );

  const Ctas = () => (
    <div style={{ display: 'flex', gap: 12, marginTop: 32 }}>
      <Button variant="primary" size="lg" accent={accent}>{COPY.cta.primary} {COPY.cta.arrow}</Button>
      <Button variant="ghost" size="lg">{COPY.cta.secondary}</Button>
    </div>
  );

  // Asymmetric: text occupies left 55%, visual occupies right 45% with offset
  return (
    <Frame width={1920} height={1080}>
      <TopChrome accent={accent} status={status} edition={COPY.ebook.edition} />
      <CornerMarks inset={28} color={tint(accent, 0.45)} />
      <Crosshair x={60} y={1020} size={14} color={tint(accent, 0.5)} />
      <Crosshair x={1860} y={60} size={14} color={tint(accent, 0.5)} />

      {/* the textual half */}
      <div style={{
        position: 'absolute', top: 130, left: 60, width: 980,
      }}>
        <Eyebrow color={accent}>{eyebrow}</Eyebrow>
        <Title />
        <Sub />
        <Ctas />

        {/* the system layer index strip */}
        <div style={{ display: 'flex', gap: 28, marginTop: 64, alignItems: 'center' }}>
          {[
            ['L01', 'Infrastructure',  '#5EA1FF'],
            ['L02', 'Flow',            '#22D3EE'],
            ['L03', 'Operational UI',  '#A78BFA'],
            ['L04', 'Intelligence',    '#34D399'],
          ].map(([n, label, c]) => (
            <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{
                fontFamily: TOKENS.font.mono, fontSize: 11, fontWeight: 700,
                padding: '4px 8px', background: tint(c, 0.12),
                border: `1px solid ${tint(c, 0.38)}`,
                color: c, letterSpacing: '0.18em', borderRadius: 3,
              }}>{n}</span>
              <span style={{ fontFamily: TOKENS.font.mono, fontSize: 11, color: TOKENS.fg.tertiary,
                letterSpacing: '0.18em', textTransform: 'uppercase' }}>{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* the visual half */}
      <div style={{
        position: 'absolute', top: 200, right: 60, bottom: 140, width: 820,
      }}>{children}</div>

      <BottomChrome extra={status} />
    </Frame>
  );
};

// ─── EbookCoverTemplate ────────────────────────────────────
const EbookCoverTemplate = ({ accent = '#5EA1FF', layout = 'cinematic', children }) => {
  const { title, eyebrow, promise, edition, offer } = COPY.ebook;

  return (
    <Frame width={800} height={1130} padding={0}
      bg={layout === 'cinematic'
        ? `radial-gradient(ellipse at 30% 25%, ${tint(accent, 0.22)} 0%, #050912 70%)`
        : 'linear-gradient(180deg, #050811 0%, #0A1024 100%)'}
      grid={true} measurements={layout !== 'minimal'}>
      <CornerMarks inset={20} color={tint(accent, 0.55)} />

      {/* Sheet header */}
      <div style={{ position: 'absolute', top: 36, left: 48, right: 48,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Logo size={24} />
        <SystemLabel color={accent}>{`SHEET · 01 · REV 2026.A`}</SystemLabel>
      </div>

      <div style={{ position: 'absolute', top: 140, left: 48, right: 48 }}>
        <Eyebrow color={accent}>{eyebrow}</Eyebrow>
        <h1 style={{
          fontSize: layout === 'minimal' ? 64 : 56, fontWeight: 800,
          letterSpacing: '-0.04em', lineHeight: 0.96, margin: '20px 0 18px',
          textWrap: 'balance',
        }}>{title}</h1>
        <p style={{
          fontSize: 15, color: TOKENS.fg.secondary, lineHeight: 1.6,
          maxWidth: 560, margin: 0,
        }}>{promise}</p>
      </div>

      {/* visual slot */}
      <div style={{
        position: 'absolute', top: layout === 'minimal' ? 700 : 540,
        left: 48, right: 48, bottom: 220,
      }}>{children}</div>

      {/* offer bar */}
      <div style={{ position: 'absolute', bottom: 76, left: 48, right: 48 }}>
        <InfraPanel accent={accent} label="FREE DOWNLOAD · BLUEPRINT 01" status="READY">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: TOKENS.fg.primary, lineHeight: 1.3 }}>{offer}</div>
              <div style={{ fontFamily: TOKENS.font.mono, fontSize: 10, color: TOKENS.fg.tertiary,
                marginTop: 6, letterSpacing: '0.16em' }}>{COPY.brand.leadMagnetUrl}</div>
            </div>
            <Button variant="primary" size="sm" accent={accent}>GET PDF →</Button>
          </div>
        </InfraPanel>
      </div>

      <div style={{ position: 'absolute', bottom: 30, left: 48, right: 48,
        display: 'flex', justifyContent: 'space-between',
        fontFamily: TOKENS.font.mono, fontSize: 9, color: TOKENS.fg.quaternary,
        letterSpacing: '0.20em', textTransform: 'uppercase' }}>
        <span>{edition}</span>
        <span>·</span>
        <span>{COPY.brand.name}</span>
      </div>
    </Frame>
  );
};

// ─── EbookPageTemplate (interior spread) ───────────────────
const EbookPageTemplate = ({ chapter, no, accent, eyebrow, title, lede, children }) => (
  <Frame width={800} height={1130} padding={0}
    bg="radial-gradient(ellipse at 10% 0%, #0E1A38 0%, #060B1A 60%)"
    glows={false} measurements={false}>
    {/* top chrome */}
    <div style={{ position: 'absolute', top: 30, left: 48, right: 48,
      display: 'flex', justifyContent: 'space-between',
      fontFamily: TOKENS.font.mono, fontSize: 9, color: TOKENS.fg.quaternary,
      letterSpacing: '0.20em', textTransform: 'uppercase' }}>
      <span>{COPY.brand.name} · Blueprint</span>
      <span style={{ color: accent }}>{chapter}</span>
      <span>P · {no}</span>
    </div>

    {/* bottom chrome */}
    <div style={{ position: 'absolute', bottom: 30, left: 48, right: 48,
      display: 'flex', justifyContent: 'space-between',
      fontFamily: TOKENS.font.mono, fontSize: 9, color: TOKENS.fg.quaternary,
      letterSpacing: '0.20em', textTransform: 'uppercase' }}>
      <span>Operational · Intelligence</span>
      <span>2026 · v1.0</span>
    </div>

    <CornerMarks inset={20} color="rgba(120,150,255,0.25)" />

    <div style={{ position: 'absolute', inset: '70px 48px 70px 48px' }}>
      <Kicker no={`CHAPTER · ${no}`} label={eyebrow} accent={accent} />
      <h2 style={{
        fontSize: 38, fontWeight: 800, letterSpacing: '-0.03em',
        lineHeight: 1.06, margin: '22px 0 14px', maxWidth: 620, textWrap: 'pretty',
      }}>{title}</h2>
      {lede && (
        <p style={{ fontSize: 14, color: TOKENS.fg.secondary, lineHeight: 1.65,
          margin: '0 0 24px', maxWidth: 600 }}>{lede}</p>
      )}
      {children}
    </div>
  </Frame>
);

// ─── AdTemplate ────────────────────────────────────────────
const AdTemplate = ({ size = 'square', angle, children }) => {
  const dims = {
    square:   { w: 1080, h: 1080, t: 78,  ph: 580 },
    portrait: { w: 1080, h: 1350, t: 80,  ph: 780 },
    story:    { w: 1080, h: 1920, t: 96,  ph: 1020 },
    banner:   { w: 1200, h: 628,  t: 50,  ph: 0 },
  }[size];

  const { hook, body, accent, status } = angle;
  const tall = size === 'portrait' || size === 'story';

  if (size === 'banner') {
    return (
      <Frame width={dims.w} height={dims.h} padding={0}
        bg={`radial-gradient(ellipse at 30% 0%, ${tint(accent, 0.26)} 0%, #060A14 65%)`}>
        <CornerMarks inset={16} color={tint(accent, 0.55)} />
        <div style={{ position: 'absolute', top: 22, left: 24, right: 24,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Logo size={20} />
          <SystemLabel color={accent}>{status}</SystemLabel>
        </div>
        <div style={{ position: 'absolute', top: 70, left: 24, right: 540, bottom: 24,
          display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <Eyebrow color={accent}>{COPY.brand.name} · 2026</Eyebrow>
            <h2 style={{ fontSize: dims.t, fontWeight: 800, letterSpacing: '-0.035em',
              lineHeight: 1.0, margin: '12px 0 10px', textWrap: 'balance' }}>{hook}</h2>
            <p style={{ fontSize: 15, color: TOKENS.fg.secondary, lineHeight: 1.5,
              margin: 0, maxWidth: 540 }}>{body}</p>
          </div>
          <Button variant="primary" size="md" accent={accent}>{COPY.cta.primaryShort} {COPY.cta.arrow}</Button>
        </div>
        {children && (
          <div style={{ position: 'absolute', top: 24, right: 24, width: 500, bottom: 24 }}>
            <InfraPanel accent={accent} label="PREVIEW" status="LIVE" padding={14}
              style={{ height: '100%', boxSizing: 'border-box' }}>
              <div style={{ height: 'calc(100% - 24px)' }}>{children}</div>
            </InfraPanel>
          </div>
        )}
      </Frame>
    );
  }

  return (
    <Frame width={dims.w} height={dims.h} padding={0}
      bg={`radial-gradient(ellipse at 25% 0%, ${tint(accent, 0.28)} 0%, #060A14 65%)`}>
      <CornerMarks inset={20} color={tint(accent, 0.55)} />

      <div style={{ position: 'absolute', top: 48, left: 56, right: 56,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Logo size={26} />
        <SystemLabel color={accent}>{status}</SystemLabel>
      </div>

      <div style={{ position: 'absolute',
        top: size === 'story' ? 200 : (size === 'portrait' ? 160 : 140),
        left: 56, right: 56 }}>
        <Eyebrow color={accent}>{COPY.brand.name} · 2026</Eyebrow>
        <h2 style={{
          fontSize: dims.t, fontWeight: 800, letterSpacing: '-0.045em',
          lineHeight: 0.96, margin: '24px 0 20px', textWrap: 'balance',
        }}>{hook}</h2>
        <p style={{
          fontSize: tall ? 22 : 19, color: TOKENS.fg.secondary, lineHeight: 1.55,
          maxWidth: 800, margin: 0,
        }}>{body}</p>
      </div>

      {children && (
        <div style={{
          position: 'absolute',
          top: dims.ph, left: 56, right: 56, bottom: 180,
        }}>
          <InfraPanel accent={accent} label="PREVIEW · OPERATING LAYER" status="LIVE"
            style={{ height: '100%', boxSizing: 'border-box' }}>
            <div style={{ height: 'calc(100% - 24px)' }}>{children}</div>
          </InfraPanel>
        </div>
      )}

      {/* CTA strip */}
      <div style={{
        position: 'absolute', bottom: 50, left: 56, right: 56,
        padding: '18px 22px',
        background: `linear-gradient(135deg, ${tint(accent, 0.16)}, rgba(11,16,32,0.6))`,
        border: `1px solid ${tint(accent, 0.40)}`,
        borderRadius: 4,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div>
          <div style={{ fontFamily: TOKENS.font.mono, fontSize: 11, color: accent, letterSpacing: '0.20em' }}>{COPY.brand.leadMagnetUrl}</div>
          <div style={{ fontSize: tall ? 19 : 16, fontWeight: 800, color: TOKENS.fg.primary, marginTop: 4, letterSpacing: '-0.01em' }}>{COPY.ebook.titleShort}</div>
        </div>
        <Button variant="primary" size={tall ? 'lg' : 'md'} accent={accent}>{COPY.cta.primaryShort} {COPY.cta.arrow}</Button>
      </div>
    </Frame>
  );
};

// ─── ToolFeaturedImageTemplate (1200×630) ─────────────────
const ToolFeaturedImageTemplate = ({ tool, children }) => (
  <Frame width={1200} height={630} padding={0}
    bg={`radial-gradient(ellipse at 80% 100%, ${tint(tool.accent, 0.28)} 0%, #060A14 60%)`}>
    <CornerMarks inset={18} color={tint(tool.accent, 0.50)} />
    <div style={{ position: 'absolute', top: 30, left: 56, right: 56,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <Logo size={20} />
      <Pill text={tool.accent} color={tint(tool.accent, 0.10)} border={tint(tool.accent, 0.32)}>{tool.category}</Pill>
    </div>

    <div style={{ position: 'absolute', top: 100, left: 56, right: 56, bottom: 56,
      display: 'grid', gridTemplateColumns: '1fr 1.1fr', gap: 40, alignItems: 'stretch' }}>
      <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <span style={{
              width: 44, height: 44, borderRadius: 4,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              background: tint(tool.accent, 0.15),
              border: `1px solid ${tint(tool.accent, 0.45)}`,
              fontFamily: TOKENS.font.mono, fontWeight: 800, fontSize: 14, color: tool.accent,
              letterSpacing: '0.04em',
            }}>{tool.icon}</span>
            <SystemLabel color={tool.accent}>{tool.behavior}</SystemLabel>
          </div>
          <h2 style={{ fontSize: 52, fontWeight: 800, letterSpacing: '-0.035em',
            lineHeight: 1.0, margin: '0 0 14px' }}>{tool.toolName}</h2>
          <p style={{ fontSize: 16, color: TOKENS.fg.secondary, lineHeight: 1.55, margin: 0 }}>
            {tool.systemRole}
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ width: 7, height: 7, background: TOKENS.accent.danger,
            borderRadius: '50%', boxShadow: `0 0 6px ${TOKENS.accent.danger}` }} />
          <span style={{ fontSize: 13, color: TOKENS.fg.tertiary }}>{tool.coreProblem}</span>
        </div>
      </div>
      <InfraPanel accent={tool.accent} label="LAYER · 03 OPERATIONAL UI" status="LIVE"
        style={{ minHeight: 0 }}>
        {children}
      </InfraPanel>
    </div>
  </Frame>
);

Object.assign(window, { HeroTemplate, EbookCoverTemplate, EbookPageTemplate, AdTemplate, ToolFeaturedImageTemplate, TopChrome, BottomChrome });
