// pages.jsx — composes data + templates into final artboards.
// Every visible component goes through a template; no raw markup leaks here.

// ─── Heroes ────────────────────────────────────────────────
const HeroSystemProblem = () => (
  <HeroTemplate angle={COPY.heroes.systemProblem}>
    <InfraPanel accent={COPY.heroes.systemProblem.accent}
      label="ECOSYSTEM · LIVE OPERATING LAYER" status="ROUTING"
      style={{ height: '100%' }} padding={20}>
      <div style={{ height: 'calc(100% - 28px)' }}>
        <SystemDiagram preset="ecosystem" />
      </div>
    </InfraPanel>
  </HeroTemplate>
);

const HeroConnectedOps = () => (
  <HeroTemplate angle={COPY.heroes.connectedOps}>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, height: '100%' }}>
      <InfraPanel accent={COPY.heroes.connectedOps.accent}
        label="WORKFLOW · LEAD-TO-CUSTOMER" status="ACTIVE"
        style={{ flex: 1 }} padding={20}>
        <div style={{ height: 'calc(100% - 28px)' }}>
          <SystemDiagram preset="workflow" />
        </div>
      </InfraPanel>
      <InfraPanel accent={COPY.heroes.connectedOps.accent}
        label="DEPTH · 4 LAYERS · STACK" status="ONLINE"
        padding={14}>
        <LayerStack dense />
      </InfraPanel>
    </div>
  </HeroTemplate>
);

const HeroFreeBlueprint = () => (
  <HeroTemplate angle={COPY.heroes.freeBlueprint}>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14, height: '100%' }}>
      <InfraPanel accent={COPY.heroes.freeBlueprint.accent}
        label="BLUEPRINT · CONTENTS" status="READY" padding={18}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {COPY.ebook.chapters.slice(0, 5).map(([n, t]) => (
            <div key={n} style={{ display: 'grid', gridTemplateColumns: '38px 1fr',
              gap: 12, alignItems: 'center',
              padding: '6px 10px',
              borderLeft: `1px solid ${tint(COPY.heroes.freeBlueprint.accent, 0.4)}`,
            }}>
              <span style={{ fontFamily: TOKENS.font.mono, fontSize: 11,
                color: COPY.heroes.freeBlueprint.accent, fontWeight: 700, letterSpacing: '0.10em' }}>{n}</span>
              <span style={{ fontSize: 13, color: TOKENS.fg.primary, fontWeight: 600 }}>{t}</span>
            </div>
          ))}
        </div>
      </InfraPanel>
      <InfraPanel accent="#22D3EE" label="BONUS · PLUGIN INCLUDED" status="PACKAGED" padding={18}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <span style={{
            width: 48, height: 48, borderRadius: 4,
            background: tint('#22D3EE', 0.15), border: '1px solid rgba(34,211,238,0.45)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: TOKENS.font.mono, fontSize: 16, fontWeight: 800, color: '#22D3EE',
          }}>WP</span>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: TOKENS.fg.primary }}>Advanced WordPress plugin</div>
            <div style={{ fontSize: 12, color: TOKENS.fg.tertiary, marginTop: 2 }}>For operators who want the map and a real tool.</div>
          </div>
        </div>
      </InfraPanel>
    </div>
  </HeroTemplate>
);

const HeroOperatingLayer = () => (
  <HeroTemplate angle={COPY.heroes.operatingLayer}>
    <InfraPanel accent={COPY.heroes.operatingLayer.accent}
      label="CRMISTIC · PIPELINE · LIVE" status="PROGRESSION"
      style={{ height: '100%' }} padding={18}>
      <DashboardMockup type="pipeline" accent={COPY.heroes.operatingLayer.accent} />
    </InfraPanel>
  </HeroTemplate>
);

const HeroLocalBusiness = () => (
  <HeroTemplate angle={COPY.heroes.localBusiness}>
    <InfraPanel accent={COPY.heroes.localBusiness.accent}
      label="AUTOMATION MAP · BRANCH ROUTING" status="ACTIVE"
      style={{ height: '100%' }} padding={20}>
      <div style={{ height: 'calc(100% - 28px)' }}>
        <SystemDiagram preset="automation" />
      </div>
    </InfraPanel>
  </HeroTemplate>
);

// ─── Ebook covers ──────────────────────────────────────────
const CoverCinematic = () => (
  <EbookCoverTemplate accent="#5EA1FF" layout="cinematic">
    <SystemDiagram preset="ecosystem" />
  </EbookCoverTemplate>
);

const CoverMinimal = () => (
  <EbookCoverTemplate accent="#22D3EE" layout="minimal">
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', gap: 10 }}>
      <LayerStack dense />
    </div>
  </EbookCoverTemplate>
);

const CoverSchematic = () => (
  <EbookCoverTemplate accent="#A78BFA" layout="schematic">
    <SystemDiagram preset="workflow" />
  </EbookCoverTemplate>
);

// ─── Ebook interior spreads ────────────────────────────────
const SpreadContents = () => (
  <EbookPageTemplate chapter="CONTENTS" no="00" accent="#5EA1FF"
    eyebrow="What's inside" title="Nine systems. One operating layer."
    lede="Each chapter walks one system — what it owns, what advances it, what listens. Read it front-to-back, or jump to whichever one needs the most attention.">
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {COPY.ebook.chapters.map(([n, t, d]) => (
        <div key={n} style={{
          display: 'grid', gridTemplateColumns: '48px 1fr',
          gap: 14, alignItems: 'center',
          padding: '12px 14px',
          background: 'linear-gradient(90deg, rgba(20,27,45,0.5), rgba(11,16,32,0.2))',
          borderLeft: '2px solid rgba(94,161,255,0.4)',
          borderRadius: 2,
        }}>
          <span style={{ fontFamily: TOKENS.font.mono, fontSize: 12, fontWeight: 700,
            color: TOKENS.accent.blue, letterSpacing: '0.16em' }}>{n}</span>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: TOKENS.fg.primary }}>{t}</div>
            <div style={{ fontSize: 11, color: TOKENS.fg.tertiary, marginTop: 2 }}>{d}</div>
          </div>
        </div>
      ))}
    </div>
  </EbookPageTemplate>
);

const SpreadWorkflow = () => (
  <EbookPageTemplate chapter="01 · WORKFLOWS" no="01" accent="#5EA1FF"
    eyebrow="The rail" title="Every business runs on one workflow."
    lede="Before automation, before AI — the first job is to make the lead-to-customer rail explicit. Five stages, named, with each transition owned by exactly one system.">
    <InfraPanel accent="#5EA1FF" label="WORKFLOW · FIVE STAGES" status="LIVE"
      style={{ marginBottom: 20 }} padding={16}>
      <div style={{ height: 200 }}><SystemDiagram preset="workflow" /></div>
    </InfraPanel>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
      {[
        ['01', 'Name the stages', 'A vague \u201Clead\u201D is invisible. Five named labels are the rail.', '#5EA1FF'],
        ['02', 'Own each transition', 'One system advances the lead. Booking owns \u201CBooked\u201D. The chatbot does not get a vote.', '#22D3EE'],
        ['03', 'Make drop-off visible', 'The number between two stages matters more than the number inside them.', '#A78BFA'],
        ['04', 'Automate the boring half', 'Identified \u2192 Qualified is keystrokes. Let the system handle it.', '#34D399'],
      ].map(([n, t, b, c]) => (
        <div key={n} style={{
          display: 'grid', gridTemplateColumns: '34px 1fr', gap: 12,
          padding: '12px 14px',
          background: 'rgba(20,27,45,0.5)', borderLeft: `2px solid ${c}`,
        }}>
          <span style={{
            width: 26, height: 22, borderRadius: 3,
            background: tint(c, 0.12), border: `1px solid ${tint(c, 0.4)}`,
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: TOKENS.font.mono, fontSize: 10, fontWeight: 700, color: c,
            letterSpacing: '0.10em',
          }}>{n}</span>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: TOKENS.fg.primary }}>{t}</div>
            <div style={{ fontSize: 11, color: TOKENS.fg.tertiary, lineHeight: 1.55, marginTop: 3 }}>{b}</div>
          </div>
        </div>
      ))}
    </div>
  </EbookPageTemplate>
);

const SpreadAutomation = () => (
  <EbookPageTemplate chapter="02 · AUTOMATION MAPS" no="02" accent="#22D3EE"
    eyebrow="Connective tissue" title="Automation has a shape: trigger \u2192 condition \u2192 action."
    lede="Once you draw the map, the gaps become obvious. The best automations have one trigger, one decision, and a clear outcome on each branch.">
    <InfraPanel accent="#22D3EE" label="AUTOMATION PATTERN · BRANCH ROUTING" status="ACTIVE"
      style={{ marginBottom: 20 }} padding={16}>
      <div style={{ height: 280 }}><SystemDiagram preset="automation" /></div>
    </InfraPanel>
    <p style={{ fontSize: 13, color: TOKENS.fg.secondary, lineHeight: 1.65, margin: 0, maxWidth: 600 }}>
      A useful map names every branch and every fallback. If the condition fails, the system does not stop — it routes somewhere intentional.
    </p>
  </EbookPageTemplate>
);

const SpreadEcosystem = () => (
  <EbookPageTemplate chapter="03 · OPERATIONAL STRUCTURE" no="03" accent="#A78BFA"
    eyebrow="One operating layer" title="An org chart of systems, not people."
    lede="Inbound brings them in. Conversion turns them into customers. Lifecycle keeps them. Every tool belongs to exactly one layer, all reporting to one customer record.">
    <InfraPanel accent="#A78BFA" label="ECOSYSTEM · INFRASTRUCTURE MAP" status="ROUTING"
      padding={16}>
      <div style={{ height: 360 }}><SystemDiagram preset="ecosystem" /></div>
    </InfraPanel>
  </EbookPageTemplate>
);

const SpreadCrm = () => (
  <EbookPageTemplate chapter="04 · CRM LOGIC" no="04" accent="#34D399"
    eyebrow="The decision engine" title="A CRM that tells you what to do next."
    lede="A useful CRM is not a database of past events. It is a decision engine. Each stage transition is an event, each lead has a score, each stage has an SLA.">
    <InfraPanel accent="#34D399" label="PIPELINE · STAGE PROGRESSION" status="LIVE"
      padding={16}>
      <PipelineMockup accent="#34D399" />
    </InfraPanel>
  </EbookPageTemplate>
);

const SpreadAi = () => (
  <EbookPageTemplate chapter="08 · AI WORKFLOW EXAMPLES" no="08" accent="#F472B6"
    eyebrow="Agents that earn their keep"
    title="A useful AI workflow is a prompt, a toolbox, and a guardrail."
    lede="The good ones are not chat with a bot. They are an agent given a goal, a small set of real tools, and clear rules for when to hand back to a human.">
    <InfraPanel accent="#F472B6" label="AGENT · QUOTE-AND-BOOK" status="RUNNING"
      padding={16}>
      <AgentMockup accent="#F472B6" />
    </InfraPanel>
  </EbookPageTemplate>
);

// ─── Ads ───────────────────────────────────────────────────
const buildAd = (size, angleId) => {
  const angle = COPY.ads.find(a => a.id === angleId);
  return (
    <AdTemplate size={size} angle={angle}>
      <SystemDiagram preset="ecosystem" />
    </AdTemplate>
  );
};

const AdToolsVsSystems = () => buildAd('square',   'tools-vs-systems');
const AdInvisibleLoss  = () => buildAd('square',   'invisible-loss');
const AdManualOps      = () => buildAd('portrait', 'manual-ops');
const AdOperatingLayer = () => buildAd('story',    'operating-layer');
const AdWebsiteAlone   = () => buildAd('banner',   'website-alone');
const AdFreeBlueprint  = () => buildAd('portrait', 'free-blueprint');
const AdAutomationNeedsStructure = () => buildAd('square', 'automation-needs-structure');
const AdPluginGift     = () => buildAd('banner',   'plugin-gift');

// ─── Tool featured images ──────────────────────────────────
const ToolCard = ({ tool }) => (
  <ToolFeaturedImageTemplate tool={tool}>
    <DashboardMockup type={tool.mockup} accent={tool.accent} />
  </ToolFeaturedImageTemplate>
);

Object.assign(window, {
  HeroSystemProblem, HeroConnectedOps, HeroFreeBlueprint, HeroOperatingLayer, HeroLocalBusiness,
  CoverCinematic, CoverMinimal, CoverSchematic,
  SpreadContents, SpreadWorkflow, SpreadAutomation, SpreadEcosystem, SpreadCrm, SpreadAi,
  AdToolsVsSystems, AdInvisibleLoss, AdManualOps, AdOperatingLayer, AdWebsiteAlone,
  AdFreeBlueprint, AdAutomationNeedsStructure, AdPluginGift,
  ToolCard,
});
