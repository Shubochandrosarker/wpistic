// campaignCopy.js — single source of truth for all editorial copy.
// Every headline, eyebrow, CTA and ad angle lives here. No fake stats.

window.COPY = {
  brand: {
    name:    'WordPressistic',
    tagline: 'Operational Intelligence for WordPress businesses',
    domain:  'wordpressistic.com',
    leadMagnetUrl: 'wordpressistic.com/blueprint',
  },

  /* CTAs — used everywhere. Two-tier. */
  cta: {
    primary:   'Download the Free Blueprint',
    primaryShort: 'Download · Free',
    secondary: 'Explore the System Map',
    arrow:     '→',
  },

  /* Core positioning — sits under every campaign */
  positioning: {
    thesis:    'Most businesses do not have a website problem. They have a system problem.',
    answer:    'WordPressistic is the operating layer that connects your website, CRM, chat, booking and payments into one system.',
  },

  /* Trust language — replaces fabricated numbers. Operational, not marketing. */
  trust: [
    'Built from real operational work',
    'Designed for businesses that run on connected systems',
    'A practical field guide for orchestrated workflows',
    'For operators who think in infrastructure, not features',
  ],

  /* Operational status microcopy — used everywhere as system labels */
  status: {
    connected:    'Operations Layer · Connected',
    routing:      'Automation Routing · Active',
    sync:         'Workflow Synchronization · Established',
    signal:       'Signal Layer · Connected',
    orchestration:'Orchestration · Online',
  },

  /* The ebook — central lead magnet */
  ebook: {
    title:       'The Modern WordPress Business Systems Blueprint',
    titleShort:  'The Systems Blueprint',
    eyebrow:     'A practical field guide',
    promise:     'Workflows, automation maps, CRM logic and AI patterns for WordPress-powered businesses.',
    offer:       'Free Blueprint + Bonus Plugin Inside',
    edition:     '2026 Edition · Volume 01',
    chapters: [
      ['01', 'Workflows',                'The lead-to-customer rail every business runs on'],
      ['02', 'Automation maps',          'Trigger \u2192 condition \u2192 action \u2014 the connective tissue'],
      ['03', 'Operational structure',    'Inbound \u00b7 conversion \u00b7 lifecycle \u2014 the three layers'],
      ['04', 'CRM logic',                'Pipeline, scoring, and the four states of a lead'],
      ['05', 'Customer journey systems', 'Discover \u00b7 Evaluate \u00b7 Commit \u00b7 Onboard \u00b7 Expand'],
      ['06', 'Communication flow',       'One unified inbox \u00b7 every channel \u00b7 one record'],
      ['07', 'Booking + payment',        'From click to confirmed, in one connected pass'],
      ['08', 'AI workflow examples',     'Practical agent patterns with real tools and guardrails'],
      ['09', 'Putting it together',      'A practical 30-day rollout plan'],
    ],
  },

  /* HERO TEMPLATES — five operational angles */
  heroes: {
    systemProblem: {
      eyebrow:  'The system problem',
      title:    ['Most businesses don\u2019t need', 'more tools. They need', 'connected systems.'],
      sub:      'Disconnected workflows create invisible operational loss. WordPressistic is the operating layer that connects website, CRM, chat, booking and payments into one system.',
      accent:   '#5EA1FF',
      status:   'Operations Layer \u00b7 Connected',
    },
    connectedOps: {
      eyebrow:  'Connected operations',
      title:    ['Business systems', 'that work together.'],
      sub:      'An operating layer for businesses that need their site, CRM, chat, booking and payments to behave like one product, not seven.',
      accent:   '#22D3EE',
      status:   'Workflow Synchronization \u00b7 Established',
    },
    freeBlueprint: {
      eyebrow:  'Free field guide',
      title:    ['The Modern WordPress', 'Business Systems Blueprint.'],
      sub:      'A practical operating manual for connected workflows, automation maps, CRM logic and AI patterns. Free guide and bonus plugin inside.',
      accent:   '#A78BFA',
      status:   'Signal Layer \u00b7 Active',
    },
    operatingLayer: {
      eyebrow:  'The operating layer',
      title:    ['Your website should', 'not work alone.'],
      sub:      'It should be the front door to one operating layer. WordPressistic wires WordPress into the rest of your business as one connected system.',
      accent:   '#34D399',
      status:   'Orchestration \u00b7 Online',
    },
    localBusiness: {
      eyebrow:  'Local business operations',
      title:    ['Local business,', 'connected by design.'],
      sub:      'A practical operating layer for service businesses that live and die by bookings, follow-ups, and reliable systems. Built from real operational work.',
      accent:   '#F59E0B',
      status:   'Automation Routing \u00b7 Active',
    },
  },

  /* SOCIAL AD ANGLES — operational language, calm, educational */
  ads: [
    { id: 'tools-vs-systems',  hook: 'Most businesses don\u2019t need more tools.',           body: 'They need connected systems.',                              accent: '#5EA1FF', status: 'Operations Layer · Connected' },
    { id: 'website-alone',     hook: 'Your website should not work alone.',                   body: 'It should be the front door to one operating layer.',      accent: '#22D3EE', status: 'Signal Layer · Active' },
    { id: 'invisible-loss',    hook: 'Disconnected workflows create invisible loss.',         body: 'Connected systems make it visible — and recoverable.',     accent: '#A78BFA', status: 'Routing · Diagnostic' },
    { id: 'manual-ops',        hook: 'Manual operations quietly slow growth.',                body: 'A connected operating layer handles the boring 80%.',      accent: '#34D399', status: 'Automation Routing · Active' },
    { id: 'operating-layer',   hook: 'Modern operations require intelligent infrastructure.', body: 'WordPress, CRM, chat, booking and payments — wired together.', accent: '#F472B6', status: 'Orchestration · Online' },
    { id: 'automation-needs-structure', hook: 'Automation only works when systems communicate.', body: 'Map the workflow. Then automate.',                       accent: '#F59E0B', status: 'Workflow Synchronization · Established' },
    { id: 'free-blueprint',    hook: 'Operational clarity changes business performance.',     body: 'Download the free systems blueprint.',                     accent: '#5EA1FF', status: 'Blueprint · Ready' },
    { id: 'plugin-gift',       hook: 'Free guide + advanced WordPress plugin inside.',        body: 'For operators who want both the map and a real tool.',     accent: '#A78BFA', status: 'Package · Available' },
  ],
};
