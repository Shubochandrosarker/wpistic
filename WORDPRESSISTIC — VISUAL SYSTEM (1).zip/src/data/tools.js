// tools.js — the WordPressistic ecosystem.
// Each tool is described as an operational behavior, not a feature list.
window.TOOLS = [
  { id: 'chatbotistic',  toolName: 'Chatbotistic',  category: 'Communication Layer',
    coreProblem: 'Conversations are scattered across channels.',
    systemRole:  'Routes website chat, WhatsApp and lead capture into one signal layer that writes back to the CRM.',
    behavior:    'Communication pulse \u00b7 signal transfer \u00b7 message routing',
    accent: '#22D3EE', icon: 'CB', mockup: 'chat' },

  { id: 'bookingistic',  toolName: 'Bookingistic',  category: 'Orchestration Layer',
    coreProblem: 'Booking pages live in their own silo.',
    systemRole:  'Synchronizes calendar, payment, CRM and reminders into a single confirmed booking event.',
    behavior:    'Timeline orchestration \u00b7 scheduling architecture',
    accent: '#5EA1FF', icon: 'BK', mockup: 'calendar' },

  { id: 'crmistic',      toolName: 'CRMistic',      category: 'Decision Layer',
    coreProblem: 'The CRM records the past. It rarely directs the next move.',
    systemRole:  'A decision-oriented pipeline with stage SLAs, lead scoring and a single owner per transition.',
    behavior:    'Pipeline movement \u00b7 operational progression',
    accent: '#34D399', icon: 'CR', mockup: 'pipeline' },

  { id: 'memberistic',   toolName: 'Memberistic',   category: 'Access Layer',
    coreProblem: 'Membership content, payment and access live in three places.',
    systemRole:  'A single source of truth for who can access what, synced to billing and lifecycle automations.',
    behavior:    'Layered access systems \u00b7 entitlement architecture',
    accent: '#A78BFA', icon: 'MB', mockup: 'members' },

  { id: 'licenseistic',  toolName: 'Licenseistic',  category: 'Authorization Layer',
    coreProblem: 'License keys and entitlements drift out of sync with billing.',
    systemRole:  'Issues, validates and revokes licenses from one ledger tied to payments and customer state.',
    behavior:    'Validation gates \u00b7 authorization pathways',
    accent: '#F59E0B', icon: 'LC', mockup: 'license' },

  { id: 'insightistic',  toolName: 'Insightistic',  category: 'Intelligence Layer',
    coreProblem: 'Analytics show what happened, not what to do about it.',
    systemRole:  'A cross-platform intelligence layer that maps signals back to operational actions.',
    behavior:    'Intelligence signals \u00b7 analytics mapping',
    accent: '#5EA1FF', icon: 'IS', mockup: 'analytics' },

  { id: 'wpagentistic',  toolName: 'WPAgentistic',  category: 'Autonomy Layer',
    coreProblem: 'AI demos are easy. Agents that hold real load are not.',
    systemRole:  'Agent patterns with real tools, clear guardrails and a clean handoff to humans.',
    behavior:    'Orchestration network \u00b7 autonomous workflow structure',
    accent: '#F472B6', icon: 'AG', mockup: 'agent' },
];
