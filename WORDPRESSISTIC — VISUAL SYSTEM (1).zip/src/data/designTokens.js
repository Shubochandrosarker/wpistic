// designTokens.js — Operational Intelligence Infrastructure tokens.
// Semantics are operational, not decorative: signal / routing / sync / steel.
// Neon is dialled back; steel + graphite carry the command-center weight.

window.TOKENS = {
  /* Substrate — graphite command-center, not pure black */
  bg: {
    base:    '#080B12',
    raised:  '#0C111C',
    elevated:'#121927',
    page:    '#070A11',
  },
  /* Steel surfaces — the operational metal */
  steel: {
    900: '#0D131F',
    800: '#141C2B',
    700: '#1B2538',
    600: '#243043',
    500: '#33425A',
    400: '#516079',
  },
  surface: {
    panel:   'linear-gradient(180deg, rgba(20,28,43,0.92), rgba(12,17,28,0.96))',
    inset:   'rgba(8,11,18,0.6)',
    flat:    '#0D131F',
  },
  line: {
    subtle:  'rgba(140,160,200,0.06)',
    default: 'rgba(140,160,200,0.12)',
    accent:  'rgba(94,161,255,0.22)',
    strong:  'rgba(94,161,255,0.40)',
    rail:    'rgba(120,150,255,0.16)',
  },
  /* Signal palette — used as STATUS, sparingly, not as fill.
     Blue is the master signal; steel does the heavy lifting around it. */
  signal: {
    primary: '#5EA1FF',   // routing / primary signal
    active:  '#22D3EE',   // live / syncing
    layer:   '#A78BFA',   // intelligence layer
    ok:      '#34D399',   // committed / online
    hold:    '#F59E0B',   // queued / pending
    route:   '#F472B6',   // autonomy / branch
    alert:   '#F87171',   // fault / past-due
  },
  /* legacy alias so existing accent.* references keep working */
  get accent() {
    return {
      blue: this.signal.primary, cyan: this.signal.active, violet: this.signal.layer,
      success: this.signal.ok, warn: this.signal.hold, rose: this.signal.route, danger: this.signal.alert,
    };
  },
  fg: {
    primary:   '#EEF2FB',
    secondary: '#AEB7CC',
    tertiary:  '#79839C',
    quaternary:'#525C73',
  },
  glow: {
    signal: '0 0 50px rgba(94,161,255,0.35)',
    active: '0 0 44px rgba(34,211,238,0.30)',
  },
  radius: { xs: 3, sm: 5, md: 7, lg: 12, xl: 18 },
  font: {
    body:    '"Plus Jakarta Sans", "Inter", system-ui, sans-serif',
    mono:    '"JetBrains Mono", ui-monospace, monospace',
    display: '"Plus Jakarta Sans", system-ui, sans-serif',
  },
};

window.tint = (hex, alpha = 0.10) => {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
};
