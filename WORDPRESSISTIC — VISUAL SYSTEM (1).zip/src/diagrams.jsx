// diagrams.jsx — full SVG diagrams for each operational system inside the ebook
// Globally registers: WorkflowDiagram, AutomationMap, OperationalStructure,
//   CrmLogic, CustomerJourney, CommsFlow, BookingPaymentFlow, AiWorkflow, HeroEcosystem.

const COLORS = {
  blue: '#5EA1FF',
  cyan: '#22D3EE',
  violet: '#A78BFA',
  green: '#34D399',
  amber: '#F59E0B',
  pink: '#F472B6',
  ink: '#F5F7FF',
  ink2: '#C7CEE0',
  ink3: '#8B92A9',
  line: 'rgba(255,255,255,0.10)',
  lineHi: 'rgba(120,150,255,0.30)',
  panel: 'rgba(20,27,45,0.85)',
};

// Shared SVG defs (gradients, glow filter, markers)
const SvgDefs = ({ id = 'd' }) => (
  <defs>
    <linearGradient id={`${id}-edge`} x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stopColor={COLORS.blue} stopOpacity="0.2" />
      <stop offset="50%" stopColor={COLORS.cyan} stopOpacity="0.9" />
      <stop offset="100%" stopColor={COLORS.violet} stopOpacity="0.2" />
    </linearGradient>
    <linearGradient id={`${id}-fill`} x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stopColor={COLORS.blue} stopOpacity="0.35" />
      <stop offset="100%" stopColor={COLORS.blue} stopOpacity="0.02" />
    </linearGradient>
    <radialGradient id={`${id}-bg`}>
      <stop offset="0%" stopColor={COLORS.blue} stopOpacity="0.18" />
      <stop offset="100%" stopColor="transparent" />
    </radialGradient>
    <filter id={`${id}-glow`} x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="3" />
    </filter>
    <marker id={`${id}-arrow`} viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M0,0 L10,5 L0,10 z" fill={COLORS.cyan} />
    </marker>
  </defs>
);

// ----- HERO ECOSYSTEM (large, used in main hero) -----
const HeroEcosystem = ({ accent = COLORS.blue }) => {
  const center = { x: 600, y: 300 };
  const nodes = [
    { id: 'site',    label: 'Website',     icon: '◧', c: COLORS.blue,   x: 220, y: 130 },
    { id: 'chat',    label: 'AI Chat',     icon: '◉', c: COLORS.cyan,   x: 130, y: 300 },
    { id: 'wa',      label: 'WhatsApp',    icon: '◎', c: COLORS.green,  x: 220, y: 470 },
    { id: 'book',    label: 'Booking',     icon: '◫', c: COLORS.amber,  x: 480, y: 520 },
    { id: 'pay',     label: 'Payments',    icon: '◊', c: COLORS.pink,   x: 720, y: 520 },
    { id: 'crm',     label: 'CRM',         icon: '⬡', c: COLORS.violet, x: 980, y: 470 },
    { id: 'data',    label: 'Customer Data', icon: '▤', c: COLORS.blue, x: 1070, y: 300 },
    { id: 'an',      label: 'Analytics',   icon: '⬢', c: COLORS.cyan,   x: 980, y: 130 },
    { id: 'auto',    label: 'Automation',  icon: '✦', c: COLORS.violet, x: 720, y: 80 },
    { id: 'mem',     label: 'Memberships', icon: '◐', c: COLORS.green,  x: 480, y: 80 },
  ];
  return (
    <svg viewBox="0 0 1200 600" style={{ width: '100%', height: '100%', overflow: 'visible' }}>
      <SvgDefs id="hero" />
      {/* rings */}
      <circle cx={center.x} cy={center.y} r="220" fill="none" stroke="rgba(255,255,255,0.05)" strokeDasharray="2 4" />
      <circle cx={center.x} cy={center.y} r="320" fill="none" stroke="rgba(255,255,255,0.04)" strokeDasharray="2 6" />
      <circle cx={center.x} cy={center.y} r="80" fill="url(#hero-bg)" />
      {/* edges to center */}
      {nodes.map((n, i) => (
        <g key={n.id}>
          <line x1={center.x} y1={center.y} x2={n.x} y2={n.y} stroke={`${n.c}33`} strokeWidth="1" />
          <line x1={center.x} y1={center.y} x2={n.x} y2={n.y} stroke="url(#hero-edge)" strokeWidth="1.5" strokeDasharray="3 6" opacity="0.5" />
          <circle r="3" fill={n.c} filter="url(#hero-glow)">
            <animateMotion dur={`${4 + (i % 3)}s`} repeatCount="indefinite" path={`M${center.x},${center.y} L${n.x},${n.y}`} />
          </circle>
        </g>
      ))}
      {/* center hub */}
      <circle cx={center.x} cy={center.y} r="56" fill="rgba(20,27,45,0.92)" stroke={accent} strokeWidth="1.5" />
      <circle cx={center.x} cy={center.y} r="56" fill="none" stroke={accent} strokeWidth="6" opacity="0.18" />
      <text x={center.x} y={center.y - 4} fontSize="11" fontWeight="700" letterSpacing="0.16em" textAnchor="middle" fill={COLORS.ink3}>BUSINESS</text>
      <text x={center.x} y={center.y + 12} fontSize="14" fontWeight="800" letterSpacing="-0.01em" textAnchor="middle" fill={COLORS.ink}>OS</text>

      {/* nodes */}
      {nodes.map((n) => (
        <g key={n.id} transform={`translate(${n.x},${n.y})`}>
          <rect x="-58" y="-22" width="116" height="44" rx="10" fill="rgba(15,22,42,0.92)" stroke={`${n.c}66`} strokeWidth="1.2" />
          <rect x="-50" y="-12" width="22" height="22" rx="5" fill={`${n.c}22`} stroke={`${n.c}55`} />
          <text x="-39" y="4" textAnchor="middle" fontSize="13" fill={n.c} fontFamily="JetBrains Mono">{n.icon}</text>
          <text x="-22" y="4" fontSize="13" fontWeight="700" fill={COLORS.ink}>{n.label}</text>
        </g>
      ))}
    </svg>
  );
};

// ----- WORKFLOW DIAGRAM (lead → close) -----
const WorkflowDiagram = ({ compact = false }) => {
  const stages = [
    { label: 'Visitor',    sub: 'Anonymous',     c: COLORS.blue,   icon: '◧' },
    { label: 'Identified', sub: 'Email captured',c: COLORS.cyan,   icon: '✉' },
    { label: 'Qualified',  sub: 'AI scored',     c: COLORS.violet, icon: '◉' },
    { label: 'Booked',     sub: 'Calendar held', c: COLORS.green,  icon: '◫' },
    { label: 'Customer',   sub: 'Paid · onboarded', c: COLORS.amber, icon: '★' },
  ];
  const stepW = 200, gap = 32, totalW = stages.length * stepW + (stages.length - 1) * gap;
  return (
    <svg viewBox={`0 0 ${totalW} 220`} style={{ width: '100%', height: 'auto' }}>
      <SvgDefs id="wf" />
      {/* connecting rail */}
      <line x1="0" y1="100" x2={totalW} y2="100" stroke={COLORS.line} strokeWidth="1" />
      <line x1="0" y1="100" x2={totalW} y2="100" stroke="url(#wf-edge)" strokeWidth="1.5" strokeDasharray="2 8" />
      {stages.map((s, i) => {
        const x = i * (stepW + gap);
        return (
          <g key={i} transform={`translate(${x},0)`}>
            <rect x="0" y="60" width={stepW} height="80" rx="14" fill="rgba(20,27,45,0.85)" stroke={`${s.c}44`} strokeWidth="1.2" />
            <circle cx="36" cy="100" r="20" fill={`${s.c}22`} stroke={`${s.c}77`} strokeWidth="1.2" />
            <text x="36" y="106" textAnchor="middle" fontSize="20" fill={s.c} fontFamily="JetBrains Mono">{s.icon}</text>
            <text x="70" y="94" fontSize="14" fontWeight="700" fill={COLORS.ink}>{s.label}</text>
            <text x="70" y="114" fontSize="11" fill={COLORS.ink3}>{s.sub}</text>
            <text x="0" y="42" fontSize="9" letterSpacing="0.16em" fill={COLORS.ink3} fontFamily="JetBrains Mono">STAGE · 0{i + 1}</text>
            <line x1="0" y1="48" x2="48" y2="48" stroke={s.c} strokeWidth="2" opacity="0.7" />
            {/* drop-off tick */}
            {i < stages.length - 1 && (
              <text x={stepW + gap / 2} y="180" textAnchor="middle" fontSize="9" fill={COLORS.ink3} fontFamily="JetBrains Mono">
                <tspan x={stepW + gap / 2} dy="0">drop {[62, 38, 24, 12][i]}%</tspan>
              </text>
            )}
            {/* moving particle */}
            {i < stages.length - 1 && (
              <circle r="3" fill={COLORS.cyan} filter="url(#wf-glow)">
                <animateMotion dur={`${2 + (i * 0.4)}s`} repeatCount="indefinite"
                  path={`M${stepW},100 L${stepW + gap},100`} />
              </circle>
            )}
          </g>
        );
      })}
    </svg>
  );
};

// ----- AUTOMATION MAP (trigger → conditions → actions) -----
const AutomationMap = () => {
  return (
    <svg viewBox="0 0 1000 540" style={{ width: '100%', height: 'auto' }}>
      <SvgDefs id="am" />
      {/* swimlanes */}
      {['TRIGGER', 'CONDITION', 'ACTION', 'OUTCOME'].map((l, i) => (
        <g key={i}>
          <line x1={70 + i * 240} y1="40" x2={70 + i * 240} y2="500" stroke={COLORS.line} strokeWidth="0.7" strokeDasharray="2 6" />
          <text x={70 + i * 240} y="28" fontSize="9" letterSpacing="0.20em" fill={COLORS.ink3} fontFamily="JetBrains Mono">{l}</text>
        </g>
      ))}

      {/* nodes */}
      {[
        { c: COLORS.blue,   l: 'Form submitted',    s: 'pricing.html', x: 70,  y: 80 },
        { c: COLORS.blue,   l: 'Chat opened',       s: 'idle 12s',    x: 70,  y: 240 },
        { c: COLORS.blue,   l: 'Cart abandoned',    s: '> $80 value', x: 70,  y: 400 },

        { c: COLORS.amber,  l: 'High intent?',      s: 'score ≥ 7',   x: 310, y: 80 },
        { c: COLORS.amber,  l: 'Business hours?',   s: 'IST 9–19',    x: 310, y: 240 },
        { c: COLORS.amber,  l: 'Repeat visitor?',   s: 'session ≥ 2', x: 310, y: 400 },

        { c: COLORS.violet, l: 'Notify sales',      s: 'Slack #leads',x: 550, y: 60 },
        { c: COLORS.violet, l: 'Book intro call',   s: 'auto-hold',   x: 550, y: 160 },
        { c: COLORS.violet, l: 'WhatsApp reply',    s: 'AI template', x: 550, y: 280 },
        { c: COLORS.violet, l: 'Discount + DM',     s: '5% · 24h',    x: 550, y: 400 },

        { c: COLORS.green,  l: 'Deal opened',       s: 'CRM · stage 2', x: 790, y: 100 },
        { c: COLORS.green,  l: 'Calendar event',    s: 'GCal · 30m',  x: 790, y: 220 },
        { c: COLORS.green,  l: 'Recovery payment',  s: 'Stripe link', x: 790, y: 360 },
      ].map((n, i) => (
        <g key={i} transform={`translate(${n.x},${n.y})`}>
          <rect x="0" y="0" width="170" height="48" rx="10" fill={COLORS.panel} stroke={`${n.c}55`} strokeWidth="1.2" />
          <circle cx="18" cy="24" r="6" fill={n.c} opacity="0.85" />
          <circle cx="18" cy="24" r="9" fill="none" stroke={n.c} strokeWidth="1" opacity="0.4" />
          <text x="34" y="22" fontSize="12" fontWeight="700" fill={COLORS.ink}>{n.l}</text>
          <text x="34" y="38" fontSize="10" fill={COLORS.ink3} fontFamily="JetBrains Mono">{n.s}</text>
        </g>
      ))}

      {/* edges */}
      {[
        [80,104, 240,104], [80,264, 240,264], [80,424, 240,424],
        [240,104, 240,84],  [240,264, 240,184], [240,424, 240,184],
        [240,104, 240,304], [240,264, 240,304], [240,424, 240,424],
      ].map(() => null)}
      {/* draw curve edges left→middle and middle→right */}
      {[
        // triggers -> conditions
        ['M240,104 C270,104 290,104 310,104', COLORS.cyan],
        ['M240,264 C270,264 290,264 310,264', COLORS.cyan],
        ['M240,424 C270,424 290,424 310,424', COLORS.cyan],
        // conditions -> actions (multi-fanout)
        ['M480,104 C510,104 530,84 550,84', COLORS.amber],
        ['M480,104 C510,104 530,184 550,184', COLORS.amber],
        ['M480,264 C510,264 530,304 550,304', COLORS.amber],
        ['M480,424 C510,424 530,424 550,424', COLORS.amber],
        // actions -> outcomes
        ['M720,84 C750,84 770,124 790,124', COLORS.violet],
        ['M720,184 C750,184 770,144 790,144', COLORS.violet],
        ['M720,304 C750,304 770,244 790,244', COLORS.violet],
        ['M720,424 C750,424 770,384 790,384', COLORS.violet],
      ].map(([d, c], i) => (
        <g key={i}>
          <path d={d} stroke={`${c}55`} strokeWidth="1.2" fill="none" />
          <circle r="2.4" fill={c} filter="url(#am-glow)">
            <animateMotion dur={`${2.4 + (i % 4) * 0.3}s`} repeatCount="indefinite" path={d} />
          </circle>
        </g>
      ))}
    </svg>
  );
};

// ----- OPERATIONAL STRUCTURE (org of systems, not people) -----
const OperationalStructure = () => (
  <svg viewBox="0 0 900 480" style={{ width: '100%', height: 'auto' }}>
    <SvgDefs id="os" />
    {/* top */}
    <g transform="translate(330,40)">
      <rect width="240" height="64" rx="14" fill="rgba(20,27,45,0.9)" stroke={`${COLORS.blue}66`} />
      <text x="120" y="28" textAnchor="middle" fontSize="10" letterSpacing="0.16em" fill={COLORS.ink3} fontFamily="JetBrains Mono">OPERATIONAL CORE</text>
      <text x="120" y="48" textAnchor="middle" fontSize="16" fontWeight="800" fill={COLORS.ink}>Customer Data Layer</text>
    </g>
    {/* middle row */}
    {[
      { x: 60,  c: COLORS.cyan,   t: 'INBOUND',      l: 'Site · Chat · Ads',   icon: '▸' },
      { x: 320, c: COLORS.violet, t: 'CONVERSION',   l: 'Booking · Pricing · Pay', icon: '◆' },
      { x: 580, c: COLORS.green,  t: 'LIFECYCLE',    l: 'CRM · Email · WhatsApp', icon: '◉' },
    ].map((b, i) => (
      <g key={i} transform={`translate(${b.x},180)`}>
        <rect width="260" height="80" rx="14" fill={COLORS.panel} stroke={`${b.c}55`} />
        <text x="20" y="28" fontSize="10" letterSpacing="0.18em" fill={b.c} fontFamily="JetBrains Mono">{b.t}</text>
        <text x="20" y="56" fontSize="16" fontWeight="700" fill={COLORS.ink}>{b.l}</text>
        <text x="232" y="52" fontSize="22" fill={`${b.c}99`} fontFamily="JetBrains Mono">{b.icon}</text>
      </g>
    ))}
    {/* bottom */}
    <g transform="translate(180,340)">
      <rect width="540" height="64" rx="14" fill="rgba(20,27,45,0.9)" stroke={`${COLORS.amber}66`} />
      <text x="270" y="28" textAnchor="middle" fontSize="10" letterSpacing="0.16em" fill={COLORS.ink3} fontFamily="JetBrains Mono">OBSERVABILITY · ATTRIBUTION · REPORTING</text>
      <text x="270" y="50" textAnchor="middle" fontSize="14" fontWeight="700" fill={COLORS.ink}>Analytics · Logs · Cohort dashboards</text>
    </g>
    {/* connectors */}
    {[
      ['M450,104 L190,180', COLORS.cyan],
      ['M450,104 L450,180', COLORS.violet],
      ['M450,104 L710,180', COLORS.green],
      ['M190,260 L320,340', COLORS.cyan],
      ['M450,260 L450,340', COLORS.violet],
      ['M710,260 L600,340', COLORS.green],
    ].map(([d, c], i) => (
      <g key={i}>
        <path d={d} stroke={`${c}55`} strokeWidth="1.2" fill="none" />
        <circle r="2.4" fill={c} filter="url(#os-glow)">
          <animateMotion dur={`${3 + i * 0.2}s`} repeatCount="indefinite" path={d} />
        </circle>
      </g>
    ))}
  </svg>
);

// ----- CRM LOGIC (pipeline + scoring) -----
const CrmLogic = () => {
  const stages = [
    { name: 'New',         count: 84, c: COLORS.blue },
    { name: 'Working',     count: 41, c: COLORS.cyan },
    { name: 'Qualified',   count: 23, c: COLORS.violet },
    { name: 'Proposal',    count: 11, c: COLORS.amber },
    { name: 'Won',         count: 6,  c: COLORS.green },
  ];
  const total = 84;
  return (
    <svg viewBox="0 0 900 360" style={{ width: '100%', height: 'auto' }}>
      <SvgDefs id="crm" />
      {/* pipeline funnel */}
      {stages.map((s, i) => {
        const w = 150;
        const x = 30 + i * 170;
        const ratio = s.count / total;
        const h = 60 + ratio * 180;
        const y = 200 - h / 2;
        return (
          <g key={i}>
            <rect x={x} y={y} width={w} height={h} rx="10" fill={`${s.c}18`} stroke={`${s.c}66`} strokeWidth="1.2" />
            <text x={x + w / 2} y={y - 12} textAnchor="middle" fontSize="11" letterSpacing="0.14em" fill={COLORS.ink3} fontFamily="JetBrains Mono">{s.name.toUpperCase()}</text>
            <text x={x + w / 2} y={y + h / 2 - 2} textAnchor="middle" fontSize="32" fontWeight="800" fill={COLORS.ink}>{s.count}</text>
            <text x={x + w / 2} y={y + h / 2 + 22} textAnchor="middle" fontSize="11" fill={COLORS.ink3}>deals</text>
            {i < stages.length - 1 && (
              <g>
                <path d={`M${x + w + 10},200 L${x + w + 20},200`} stroke={s.c} strokeWidth="1.5" markerEnd={`url(#crm-arrow)`} />
              </g>
            )}
          </g>
        );
      })}
      {/* scoring legend */}
      <g transform="translate(30,310)">
        <text fontSize="10" letterSpacing="0.18em" fill={COLORS.ink3} fontFamily="JetBrains Mono">AI LEAD SCORE</text>
        {[
          ['cold', '0–3', COLORS.ink3],
          ['warm', '4–6', COLORS.amber],
          ['hot',  '7–9', COLORS.green],
          ['urgent', '10', COLORS.pink],
        ].map(([l, r, c], i) => (
          <g key={i} transform={`translate(${130 + i * 130},-10)`}>
            <circle cx="6" cy="6" r="4" fill={c} />
            <text x="18" y="10" fontSize="12" fill={COLORS.ink}>{l} <tspan fill={COLORS.ink3} fontFamily="JetBrains Mono">· {r}</tspan></text>
          </g>
        ))}
      </g>
    </svg>
  );
};

// ----- CUSTOMER JOURNEY (timeline strip) -----
const CustomerJourney = () => {
  const phases = [
    { p: 'Discover',  c: COLORS.blue,   t: 'Search · Ad · Referral' },
    { p: 'Evaluate',  c: COLORS.cyan,   t: 'Read · Chat · Compare' },
    { p: 'Commit',    c: COLORS.violet, t: 'Book · Sign · Pay' },
    { p: 'Onboard',   c: COLORS.green,  t: 'Setup · Welcome · Activate' },
    { p: 'Expand',    c: COLORS.amber,  t: 'Upsell · Renew · Refer' },
  ];
  return (
    <svg viewBox="0 0 1000 240" style={{ width: '100%', height: 'auto' }}>
      <SvgDefs id="cj" />
      {/* spine */}
      <path d="M40,140 C200,80 400,200 600,140 C800,80 920,160 960,120" stroke={COLORS.lineHi} strokeWidth="2" fill="none" />
      <path d="M40,140 C200,80 400,200 600,140 C800,80 920,160 960,120" stroke="url(#cj-edge)" strokeWidth="1.6" fill="none" strokeDasharray="4 8" opacity="0.6" />
      {phases.map((ph, i) => {
        const x = 40 + i * 230;
        const points = [{x:40,y:140},{x:240,y:110},{x:480,y:170},{x:720,y:110},{x:960,y:120}];
        const pt = points[i];
        return (
          <g key={i} transform={`translate(${pt.x},${pt.y})`}>
            <circle r="10" fill={ph.c} opacity="0.18" />
            <circle r="5" fill={ph.c} />
            <line x1="0" y1="-12" x2="0" y2="-44" stroke={`${ph.c}88`} strokeWidth="1" strokeDasharray="2 3" />
            <text x="0" y="-58" textAnchor="middle" fontSize="9" letterSpacing="0.18em" fill={ph.c} fontFamily="JetBrains Mono">{`0${i+1}`}</text>
            <text x="0" y="-44" textAnchor="middle" fontSize="14" fontWeight="800" fill={COLORS.ink}>{ph.p}</text>
            <text x="0" y="36" textAnchor="middle" fontSize="11" fill={COLORS.ink3}>{ph.t}</text>
          </g>
        );
      })}
    </svg>
  );
};

// ----- COMMS FLOW (multichannel routing) -----
const CommsFlow = () => (
  <svg viewBox="0 0 900 380" style={{ width: '100%', height: 'auto' }}>
    <SvgDefs id="cm" />
    {/* central router */}
    <g transform="translate(380,150)">
      <rect x="0" y="0" width="140" height="80" rx="14" fill="rgba(20,27,45,0.92)" stroke={`${COLORS.blue}88`} strokeWidth="1.4" />
      <text x="70" y="32" textAnchor="middle" fontSize="10" letterSpacing="0.18em" fill={COLORS.blue} fontFamily="JetBrains Mono">UNIFIED INBOX</text>
      <text x="70" y="54" textAnchor="middle" fontSize="14" fontWeight="700" fill={COLORS.ink}>Conversation Router</text>
    </g>
    {/* channels */}
    {[
      { l: 'Website Chat', x: 40,  y: 40,  c: COLORS.cyan },
      { l: 'WhatsApp',     x: 40,  y: 320, c: COLORS.green },
      { l: 'Email',        x: 40,  y: 180, c: COLORS.blue },
      { l: 'AI Replies',   x: 720, y: 40,  c: COLORS.violet, out: true },
      { l: 'Human Agent',  x: 720, y: 180, c: COLORS.amber,  out: true },
      { l: 'CRM Sync',     x: 720, y: 320, c: COLORS.pink,   out: true },
    ].map((n, i) => (
      <g key={i} transform={`translate(${n.x},${n.y})`}>
        <rect width="140" height="48" rx="10" fill={COLORS.panel} stroke={`${n.c}55`} />
        <circle cx="20" cy="24" r="6" fill={n.c} />
        <text x="36" y="29" fontSize="12" fontWeight="700" fill={COLORS.ink}>{n.l}</text>
      </g>
    ))}
    {/* lines */}
    {[
      ['M180,64 C260,64 320,150 380,170', COLORS.cyan],
      ['M180,204 C260,204 330,200 380,190', COLORS.blue],
      ['M180,344 C260,344 320,250 380,230', COLORS.green],
      ['M520,170 C580,150 640,64 720,64', COLORS.violet],
      ['M520,190 C580,190 640,204 720,204', COLORS.amber],
      ['M520,230 C580,260 640,344 720,344', COLORS.pink],
    ].map(([d, c], i) => (
      <g key={i}>
        <path d={d} stroke={`${c}55`} strokeWidth="1.2" fill="none" />
        <circle r="2.6" fill={c} filter="url(#cm-glow)">
          <animateMotion dur={`${2.6 + i * 0.25}s`} repeatCount="indefinite" path={d} />
        </circle>
      </g>
    ))}
  </svg>
);

// ----- BOOKING + PAYMENT FLOW -----
const BookingPaymentFlow = () => (
  <svg viewBox="0 0 1000 260" style={{ width: '100%', height: 'auto' }}>
    <SvgDefs id="bp" />
    {[
      { l: 'Service picked',  s: '/book',           c: COLORS.blue, x: 30 },
      { l: 'Slot reserved',   s: 'auto-hold 10m',   c: COLORS.cyan, x: 230 },
      { l: 'Deposit paid',    s: 'Stripe · 30%',    c: COLORS.violet, x: 430 },
      { l: 'Calendar synced', s: 'GCal · ICS · CRM', c: COLORS.green, x: 630 },
      { l: 'Reminders armed', s: 'SMS · WA · Email', c: COLORS.amber, x: 830 },
    ].map((n, i) => (
      <g key={i} transform={`translate(${n.x},80)`}>
        <rect width="170" height="100" rx="14" fill={COLORS.panel} stroke={`${n.c}55`} />
        <text x="20" y="28" fontSize="9" letterSpacing="0.18em" fill={n.c} fontFamily="JetBrains Mono">STEP · 0{i + 1}</text>
        <text x="20" y="56" fontSize="14" fontWeight="700" fill={COLORS.ink}>{n.l}</text>
        <text x="20" y="80" fontSize="11" fill={COLORS.ink3} fontFamily="JetBrains Mono">{n.s}</text>
      </g>
    ))}
    {[200, 400, 600, 800].map((x, i) => (
      <g key={i}>
        <path d={`M${x},130 L${x + 30},130`} stroke={COLORS.cyan} strokeWidth="1.4" markerEnd="url(#bp-arrow)" />
        <circle r="2.4" fill={COLORS.cyan} filter="url(#bp-glow)">
          <animateMotion dur={`${2 + i * 0.3}s`} repeatCount="indefinite" path={`M${x},130 L${x + 30},130`} />
        </circle>
      </g>
    ))}
    <text x="500" y="34" textAnchor="middle" fontSize="10" letterSpacing="0.18em" fill={COLORS.ink3} fontFamily="JetBrains Mono">BOOKING → PAYMENT → OPS HAND-OFF</text>
  </svg>
);

// ----- AI WORKFLOW (prompt → tools → action) -----
const AiWorkflow = () => (
  <svg viewBox="0 0 1000 360" style={{ width: '100%', height: 'auto' }}>
    <SvgDefs id="ai" />
    {/* prompt */}
    <g transform="translate(30,140)">
      <rect width="180" height="80" rx="14" fill={COLORS.panel} stroke={`${COLORS.blue}66`} />
      <text x="20" y="28" fontSize="10" letterSpacing="0.18em" fill={COLORS.blue} fontFamily="JetBrains Mono">INPUT</text>
      <text x="20" y="52" fontSize="14" fontWeight="700" fill={COLORS.ink}>Customer message</text>
      <text x="20" y="70" fontSize="11" fill={COLORS.ink3}>"need a quote for…"</text>
    </g>
    {/* AI core */}
    <g transform="translate(330,100)">
      <rect width="220" height="160" rx="18" fill="rgba(20,27,45,0.92)" stroke={`${COLORS.violet}88`} strokeWidth="1.4" />
      <text x="110" y="32" textAnchor="middle" fontSize="10" letterSpacing="0.18em" fill={COLORS.violet} fontFamily="JetBrains Mono">REASONING CORE</text>
      <text x="110" y="58" textAnchor="middle" fontSize="16" fontWeight="800" fill={COLORS.ink}>AI Agent</text>
      <line x1="20" y1="76" x2="200" y2="76" stroke={COLORS.line} />
      {[
        ['classify intent', '0.18s'],
        ['fetch CRM record', '0.42s'],
        ['draft reply', '0.91s'],
        ['route or send', '0.08s'],
      ].map(([t, ts], i) => (
        <g key={i} transform={`translate(20,${92 + i * 16})`}>
          <circle cx="4" cy="6" r="2.5" fill={COLORS.violet} />
          <text x="14" y="10" fontSize="11" fill={COLORS.ink2}>{t}</text>
          <text x="180" y="10" textAnchor="end" fontSize="10" fill={COLORS.ink3} fontFamily="JetBrains Mono">{ts}</text>
        </g>
      ))}
    </g>
    {/* tool fan-out */}
    {[
      { l: 'CRM',        c: COLORS.cyan,   x: 720, y: 40 },
      { l: 'Calendar',   c: COLORS.green,  x: 720, y: 120 },
      { l: 'WhatsApp',   c: COLORS.green,  x: 720, y: 200 },
      { l: 'Payments',   c: COLORS.amber,  x: 720, y: 280 },
    ].map((n, i) => (
      <g key={i} transform={`translate(${n.x},${n.y})`}>
        <rect width="160" height="48" rx="10" fill={COLORS.panel} stroke={`${n.c}55`} />
        <circle cx="20" cy="24" r="6" fill={n.c} />
        <text x="36" y="29" fontSize="12" fontWeight="700" fill={COLORS.ink}>{n.l} <tspan fill={COLORS.ink3} fontFamily="JetBrains Mono">.tool</tspan></text>
      </g>
    ))}
    {/* edges */}
    {[
      ['M210,180 L330,180', COLORS.blue],
      ['M550,140 C620,140 650,64 720,64', COLORS.violet],
      ['M550,160 C620,160 660,144 720,144', COLORS.violet],
      ['M550,200 C620,200 660,224 720,224', COLORS.violet],
      ['M550,220 C620,220 660,304 720,304', COLORS.violet],
    ].map(([d, c], i) => (
      <g key={i}>
        <path d={d} stroke={`${c}66`} strokeWidth="1.3" fill="none" />
        <circle r="2.6" fill={c} filter="url(#ai-glow)">
          <animateMotion dur={`${2.2 + i * 0.3}s`} repeatCount="indefinite" path={d} />
        </circle>
      </g>
    ))}
  </svg>
);

Object.assign(window, {
  HeroEcosystem, WorkflowDiagram, AutomationMap, OperationalStructure,
  CrmLogic, CustomerJourney, CommsFlow, BookingPaymentFlow, AiWorkflow,
});
