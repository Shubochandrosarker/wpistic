// marketing-shell.jsx — Shared mega-menu nav + footer for ALL marketing pages

// ─── Mega menu data ───────────────────────────────────────────
const MEGA = {
  Product: {
    intro: { label: 'WPistic Suite', title: '11 plugins. One workspace.',
      desc: 'Browse the full product line, or jump into any plugin page.', cta: 'Products overview', target: 'products-overview' },
    cols: [
      { title: 'Flagship products', items: [
        { id: 'product-chatbotistic', icon: 'inbox',    title: 'Chatbotistic', desc: 'AI WhatsApp, web chat, multi-channel inbox' },
        { id: 'product-memberistic',  icon: 'members',  title: 'Memberistic',  desc: 'Memberships, subscriptions, gated content', glyph: true },
        { id: 'product-bookingistic', icon: 'calendar', title: 'Bookingistic', desc: 'Appointments, classes, travel reservations', glyph: true },
      ]},
      { title: 'Insights & growth', items: [
        { id: 'product-insightistic', icon: 'chart', title: 'Insightistic', desc: 'Unified analytics for WP, Woo, Search Console' },
        { id: 'product-crmistic',     icon: 'users', title: 'CRMistic',     desc: 'Leads, customers, timelines, automation triggers' },
      ]},
    ],
  },
  Ecosystem: {
    intro: { label: 'WordPressistic', title: 'One ecosystem. One account.',
      desc: 'Eleven products that share licenses, contacts, inbox, and automations.', cta: 'Ecosystem overview', target: 'ecosystem-overview' },
    cols: [
      { title: 'Browse the ecosystem', items: [
        { id: 'ecosystem-plugins',    icon: 'wp',    title: 'WordPress Plugins',  desc: 'Core plugins for content, members, commerce' },
        { id: 'ecosystem-ai',         icon: 'bot',   title: 'AI Automation Tools', desc: 'Agents, automations, AI assistants' },
        { id: 'ecosystem-ops',        icon: 'cube',  title: 'Business Operations', desc: 'CRM, billing, support, ops' },
        { id: 'ecosystem-integrations', icon: 'external', title: 'Integrations',  desc: 'Stripe, GA4, Search Console, WhatsApp' },
      ]},
    ],
  },
  Platform: {
    intro: { label: 'WPistic Platform', title: 'The infrastructure layer.',
      desc: 'Platform features that work across every WPistic plugin.', cta: 'Platform overview', target: 'platform-overview' },
    cols: [
      { title: 'Core platform', items: [
        { id: 'platform-licenses',    icon: 'key',   title: 'License Manager', desc: 'Activations, domains, renewals, alerts' },
        { id: 'platform-agents',      icon: 'bot',   title: 'AI Agents',       desc: 'Sales, support, SEO, booking agents' },
        { id: 'platform-automations', icon: 'zap',   title: 'Automations',     desc: 'When-this-then-that workflows' },
      ]},
      { title: 'Connect & build', items: [
        { id: 'platform-inbox',       icon: 'inbox',  title: 'Inbox',       desc: 'Unified WhatsApp, web chat, email, tickets' },
        { id: 'platform-analytics',   icon: 'chart',  title: 'Analytics',   desc: 'Traffic, revenue, AI usage across sites' },
        { id: 'platform-developers',  icon: 'code',   title: 'Developers',  desc: 'REST API, webhooks, SDKs, event log' },
      ]},
    ],
  },
  Company: {
    cols: [
      { title: 'WPistic', items: [
        { id: 'about',     icon: 'spark',    title: 'About',     desc: 'Mission, story, and team' },
        { id: 'blog',      icon: 'chart',    title: 'Blog',      desc: 'Guides, product updates, growth' },
        { id: 'affiliate', icon: 'card',     title: 'Affiliate', desc: 'Earn 30% recurring commission' },
      ]},
      { title: 'Reach out', items: [
        { id: 'press',     icon: 'globe',    title: 'Press',     desc: 'Brand kit, screenshots, media' },
        { id: 'contact',   icon: 'inbox',    title: 'Contact',   desc: 'Sales, support, partnerships' },
      ]},
    ],
  },
};

// ─── Nav ──────────────────────────────────────────────────────
const MarketingNav = ({ onNav, onEnterApp }) => {
  const [openMenu, setOpenMenu] = React.useState(null);
  const closeTimerRef = React.useRef(null);
  const open = (k) => { clearTimeout(closeTimerRef.current); setOpenMenu(k); };
  const closeSoon = () => { closeTimerRef.current = setTimeout(() => setOpenMenu(null), 120); };

  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 100,
      background: 'rgba(255,255,255,0.92)',
      backdropFilter: 'blur(14px)',
      borderBottom: '1px solid #EDEFF8',
    }}>
      <div style={{
        maxWidth: 1240, margin: '0 auto', height: 68,
        padding: '0 36px',
        display: 'flex', alignItems: 'center', gap: 32,
      }}>
        <div style={{ cursor: 'pointer' }} onClick={() => onNav('homepage')}>
          <Logo size={28} />
        </div>
        <nav style={{ display: 'flex', gap: 4, flex: 1 }}>
          {Object.keys(MEGA).map(label => (
            <div key={label}
              onMouseEnter={() => open(label)} onMouseLeave={closeSoon}
              style={{ position: 'relative' }}>
              <button style={{
                fontFamily: 'inherit', fontSize: 14, fontWeight: 500,
                color: openMenu === label ? '#fff' : '#4B5263',
                background: openMenu === label ? '#121231' : 'transparent',
                border: 'none', cursor: 'pointer',
                padding: '8px 14px', borderRadius: 9,
                display: 'inline-flex', alignItems: 'center', gap: 4,
              }}>
                {label}
                <Icon name="arrow" size={11} style={{
                  transform: openMenu === label ? 'rotate(-90deg)' : 'rotate(90deg)',
                  transition: 'transform 0.18s',
                }} />
              </button>
              {openMenu === label && (
                <MegaMenuPanel content={MEGA[label]} onNav={(t) => { setOpenMenu(null); onNav(t); }} />
              )}
            </div>
          ))}
          <button onClick={() => onNav('pricing')} style={{
            fontFamily: 'inherit', fontSize: 14, fontWeight: 500,
            color: '#4B5263', background: 'transparent', border: 'none',
            cursor: 'pointer', padding: '8px 14px', borderRadius: 9,
          }}>Pricing</button>
        </nav>
        <Btn variant="ghost" size="sm" onClick={() => onNav('login')}>Sign in</Btn>
        <Btn size="sm" onClick={() => onNav('register')} rightIcon="arrow">Start Free</Btn>
      </div>
    </header>
  );
};

const MegaMenuPanel = ({ content, onNav }) => {
  const hasIntro = !!content.intro;
  return (
    <div style={{
      position: 'absolute', top: '100%', left: 0,
      paddingTop: 10, zIndex: 99,
      animation: 'megaFade 0.18s ease-out',
    }}>
      <div style={{
        background: '#fff', border: '1px solid #EDEFF8', borderRadius: 20,
        boxShadow: '0 20px 60px rgba(108,92,231,0.20)',
        display: 'grid',
        gridTemplateColumns: hasIntro ? '240px 1fr' : '1fr',
        minWidth: hasIntro ? 760 : 580,
        overflow: 'hidden',
      }}>
        {hasIntro && (
          <div style={{
            background: 'linear-gradient(160deg, #F3F1FE, #E8FAF0)',
            padding: '22px 22px', position: 'relative',
          }}>
            <SectionLabel>{content.intro.label}</SectionLabel>
            <div style={{ fontSize: 18, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em', lineHeight: 1.25 }}>
              {content.intro.title}
            </div>
            <p style={{ fontSize: 12.5, color: '#4B5263', lineHeight: 1.6, margin: '8px 0 16px' }}>
              {content.intro.desc}
            </p>
            <a onClick={() => onNav(content.intro.target)} style={{
              display: 'inline-flex', alignItems: 'center', gap: 5,
              fontSize: 12.5, fontWeight: 700, color: '#6C5CE7', cursor: 'pointer',
            }}>{content.intro.cta} <Icon name="arrow" size={12} /></a>
          </div>
        )}
        <div style={{ padding: 16, display: 'grid', gridTemplateColumns: content.cols.length > 1 ? '1fr 1fr' : '1fr', gap: 4 }}>
          {content.cols.map(col => (
            <div key={col.title}>
              <div style={{
                fontSize: 10.5, fontWeight: 700, color: '#9499BA',
                letterSpacing: '0.08em', textTransform: 'uppercase',
                padding: '8px 12px 6px',
              }}>{col.title}</div>
              {col.items.map(it => (
                <div key={it.id} onClick={() => onNav(it.id)} style={{
                  display: 'flex', gap: 10, padding: '10px 12px',
                  borderRadius: 11, cursor: 'pointer', transition: 'background 0.12s',
                }}
                  onMouseEnter={e => e.currentTarget.style.background = '#F8F9FF'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                  <div style={{
                    width: 34, height: 34, borderRadius: 9,
                    background: '#F3F1FE', color: '#6C5CE7',
                    display: 'grid', placeItems: 'center', flexShrink: 0,
                  }}>
                    {it.glyph
                      ? <ProductGlyph name={it.icon} color="#6C5CE7" bg="transparent" size={20} radius={0} />
                      : <Icon name={it.icon} size={16} />}
                  </div>
                  <div>
                    <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{it.title}</div>
                    <div style={{ fontSize: 11.5, color: '#6B7280', marginTop: 1, lineHeight: 1.4 }}>{it.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── Footer ──────────────────────────────────────────────────
const FOOTER_COLS = [
  { title: 'Product', links: [
    ['Products overview', 'products-overview'],
    ['Chatbotistic', 'product-chatbotistic'],
    ['Memberistic', 'product-memberistic'],
    ['Bookingistic', 'product-bookingistic'],
    ['Insightistic', 'product-insightistic'],
    ['CRMistic', 'product-crmistic'],
  ]},
  { title: 'Platform', links: [
    ['License Manager', 'platform-licenses'],
    ['AI Agents', 'platform-agents'],
    ['Automations', 'platform-automations'],
    ['Inbox', 'platform-inbox'],
    ['Analytics', 'platform-analytics'],
    ['Developers', 'platform-developers'],
  ]},
  { title: 'Ecosystem', links: [
    ['Overview', 'ecosystem-overview'],
    ['WordPress Plugins', 'ecosystem-plugins'],
    ['AI Automation', 'ecosystem-ai'],
    ['Business Operations', 'ecosystem-ops'],
    ['Integrations', 'ecosystem-integrations'],
  ]},
  { title: 'Resources', links: [
    ['Pricing', 'pricing'],
    ['Blog', 'blog'],
    ['Docs', 'platform-developers'],
    ['Affiliate', 'affiliate'],
    ['Press kit', 'press'],
  ]},
  { title: 'Company', links: [
    ['About', 'about'],
    ['Contact', 'contact'],
    ['Affiliate', 'affiliate'],
    ['Status', 'platform-overview'],
  ]},
  { title: 'Legal', links: [
    ['Privacy', 'legal-privacy'],
    ['Terms', 'legal-terms'],
    ['Refund Policy', 'legal-refunds'],
    ['Security', 'legal-security'],
  ]},
];

const MarketingFooter = ({ onNav }) => (
  <footer style={{ background: '#080A12', padding: '64px 36px 28px' }}>
    <div style={{ maxWidth: 1240, margin: '0 auto' }}>
      {/* Newsletter row */}
      <div style={{
        display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 36,
        paddingBottom: 36, marginBottom: 36, borderBottom: '1px solid #13161F',
        alignItems: 'center',
      }}>
        <div>
          <Logo variant="green" size={32} dark />
          <div style={{
            fontSize: 22, fontWeight: 800, color: '#fff',
            letterSpacing: '-0.025em', lineHeight: 1.3, marginTop: 14, maxWidth: 520,
          }}>
            Run your WordPress business stack from one AI-powered SaaS hub.
          </div>
        </div>
        <div>
          <div style={{ fontSize: 11.5, fontWeight: 700, color: '#9499BA', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Get product updates
          </div>
          <div style={{ fontSize: 13, color: '#6B7280', marginTop: 4 }}>One short email a month. No spam.</div>
          <div style={{
            marginTop: 14, display: 'flex', gap: 8,
            background: '#13161F', borderRadius: 9999, padding: 6,
            border: '1px solid #1E2130',
          }}>
            <input placeholder="you@company.com" style={{
              flex: 1, background: 'transparent', border: 'none',
              outline: 'none', color: '#fff', padding: '8px 14px',
              fontSize: 13, fontFamily: 'inherit',
            }} />
            <Btn variant="primary" size="sm" rightIcon="arrow">Subscribe</Btn>
          </div>
        </div>
      </div>

      {/* Link columns */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 28, marginBottom: 40 }}>
        {FOOTER_COLS.map(col => (
          <div key={col.title}>
            <div style={{
              fontSize: 11, fontWeight: 700, letterSpacing: '0.12em',
              textTransform: 'uppercase', color: '#fff', marginBottom: 16,
            }}>{col.title}</div>
            {col.links.map(([label, target]) => (
              <a key={label} onClick={(e) => { e.preventDefault(); onNav && onNav(target); }} href="#" style={{
                display: 'block', fontSize: 13, color: '#6B7280',
                textDecoration: 'none', marginBottom: 10, fontWeight: 500,
                cursor: 'pointer',
              }}>{label}</a>
            ))}
          </div>
        ))}
      </div>

      <div style={{
        borderTop: '1px solid #13161F', paddingTop: 22,
        display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12,
        fontSize: 12, color: '#4B5263',
      }}>
        <span>© 2026 WPistic — part of the WordPressistic ecosystem. Made for WordPress.</span>
        <div style={{ display: 'flex', gap: 6 }}>
          {['𝕏', 'in', 'fb', 'gh', 'yt'].map(s => (
            <div key={s} style={{
              width: 30, height: 30, borderRadius: 8, background: '#13161F',
              border: '1px solid #1E2130', display: 'grid', placeItems: 'center',
              color: '#6B7280', fontSize: 11, fontWeight: 600, cursor: 'pointer',
            }}>{s}</div>
          ))}
        </div>
        <span>hello@wpistic.com · status.wpistic.com</span>
      </div>
    </div>
  </footer>
);

// ─── Page wrapper ────────────────────────────────────────────
const MarketingPage = ({ onNav, children }) => (
  <div className="scroll" style={{ height: '100%', overflowY: 'auto', background: '#fff' }}>
    <MarketingNav onNav={onNav} />
    {children}
    <MarketingFooter onNav={onNav} />
  </div>
);

// ─── Reusable hero ───────────────────────────────────────────
const MktHero = ({ eyebrow, eyebrowTone = 'purple', title, gradient, sub, ctas, kicker, dark = false }) => (
  <section style={{
    position: 'relative', overflow: 'hidden',
    background: dark
      ? '#0D0F1A'
      : 'linear-gradient(155deg, #F3F1FE 0%, #EEF0FF 60%, #E8FAF0 130%)',
    padding: '80px 36px 90px', color: dark ? '#fff' : 'inherit',
  }}>
    <div style={{
      position: 'absolute', top: -120, right: -120, width: 500, height: 500,
      background: dark
        ? 'radial-gradient(circle, rgba(108,92,231,0.30), transparent 65%)'
        : 'radial-gradient(circle, rgba(108,92,231,0.20), transparent 65%)',
      pointerEvents: 'none',
    }} />
    <div style={{ maxWidth: 980, margin: '0 auto', position: 'relative', textAlign: 'center' }}>
      {eyebrow && <Badge tone={eyebrowTone} dot>{eyebrow}</Badge>}
      <h1 style={{
        fontSize: 60, fontWeight: 800, letterSpacing: '-0.035em',
        lineHeight: 1.08, color: dark ? '#fff' : '#0D0F1A',
        margin: '18px 0 0', textWrap: 'balance',
      }}>
        {title}
        {gradient && <> <span style={{
          background: '#00C04B',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
        }}>{gradient}</span></>}
      </h1>
      <p style={{
        fontSize: 18, lineHeight: 1.65,
        color: dark ? '#9499BA' : '#4B5263',
        maxWidth: 680, margin: '22px auto 0',
      }}>{sub}</p>
      {ctas && <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginTop: 32 }}>{ctas}</div>}
      {kicker && (
        <div style={{ display: 'flex', gap: 24, justifyContent: 'center', marginTop: 20, fontSize: 13, color: dark ? '#9499BA' : '#6B7280', fontWeight: 500 }}>
          {kicker.map(k => (
            <span key={k} style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
              <Icon name="check" size={14} color="#00C04B" strokeWidth={2.5} /> {k}
            </span>
          ))}
        </div>
      )}
    </div>
  </section>
);

const MktSection = ({ eyebrow, title, sub, bg, children, narrow }) => (
  <section style={{ background: bg || '#fff', padding: '72px 36px' }}>
    <div style={{ maxWidth: narrow ? 980 : 1240, margin: '0 auto' }}>
      {(eyebrow || title) && (
        <div style={{ textAlign: 'center', marginBottom: 48 }}>
          {eyebrow && <SectionLabel style={{ textAlign: 'center' }}>{eyebrow}</SectionLabel>}
          {title && (
            <h2 style={{
              fontSize: 40, fontWeight: 800, letterSpacing: '-0.03em',
              color: '#0D0F1A', lineHeight: 1.15, margin: 0, textWrap: 'balance',
            }}>{title}</h2>
          )}
          {sub && <p style={{ fontSize: 16, color: '#4B5263', lineHeight: 1.6, marginTop: 14, maxWidth: 640, marginLeft: 'auto', marginRight: 'auto' }}>{sub}</p>}
        </div>
      )}
      {children}
    </div>
  </section>
);

const FeatureGridCard = ({ icon, title, desc, glyph, tone = 'purple' }) => {
  const c = tone === 'green' ? { bg: '#E8FAF0', fg: '#00C04B' } : { bg: '#F3F1FE', fg: '#6C5CE7' };
  return (
    <Card padding={26} hoverable>
      <div style={{
        width: 46, height: 46, borderRadius: 13,
        background: c.bg, color: c.fg, display: 'grid', placeItems: 'center', marginBottom: 18,
      }}>
        {glyph ? <ProductGlyph name={icon} color={c.fg} bg="transparent" size={24} radius={0} /> : <Icon name={icon} size={22} />}
      </div>
      <div style={{ fontSize: 17, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.01em' }}>{title}</div>
      <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: '8px 0 0' }}>{desc}</p>
    </Card>
  );
};

const MktFinalCTA = ({ onNav, title, sub, primaryLabel = 'Start free', secondaryLabel = 'See pricing', secondaryTarget = 'pricing' }) => (
  <section style={{
    background: '#0D0F1A', padding: '90px 36px',
    position: 'relative', overflow: 'hidden', textAlign: 'center',
  }}>
    <div style={{
      position: 'absolute', inset: 0,
      background: 'radial-gradient(ellipse 60% 80% at 50% 110%, rgba(108,92,231,0.30) 0%, transparent 70%), radial-gradient(ellipse 60% 50% at 10% 0%, rgba(0,192,75,0.18) 0%, transparent 60%)',
    }} />
    <div style={{ maxWidth: 720, margin: '0 auto', position: 'relative' }}>
      <Badge tone="green" dot>Free tier · No credit card</Badge>
      <h2 style={{
        fontSize: 48, fontWeight: 800, letterSpacing: '-0.035em',
        color: '#fff', lineHeight: 1.1, margin: '18px 0 14px', textWrap: 'balance',
      }}>{title}</h2>
      <p style={{ fontSize: 16, color: '#9499BA', lineHeight: 1.7, margin: '0 auto 28px', maxWidth: 540 }}>{sub}</p>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
        <Btn variant="primary" size="xl" onClick={() => onNav('register')} rightIcon="arrow">{primaryLabel}</Btn>
        <Btn variant="dark-outline" size="xl" onClick={() => onNav(secondaryTarget)}>{secondaryLabel}</Btn>
      </div>
    </div>
  </section>
);

Object.assign(window, {
  MarketingNav, MarketingFooter, MarketingPage, MEGA, FOOTER_COLS,
  MktHero, MktSection, FeatureGridCard, MktFinalCTA,
});
