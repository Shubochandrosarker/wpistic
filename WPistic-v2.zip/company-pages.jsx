// company-pages.jsx — About, Blog, Affiliate, Press

// ═════════════════════════════════════════════════════════════
// ABOUT
// ═════════════════════════════════════════════════════════════
const AboutPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <section style={{
      position: 'relative', overflow: 'hidden',
      background: 'linear-gradient(155deg, #F3F1FE 0%, #EEF0FF 60%, #E8FAF0 130%)',
      padding: '90px 36px 100px',
    }}>
      <div style={{ position: 'absolute', top: -150, right: -100, width: 600, height: 600, background: 'radial-gradient(circle, rgba(108,92,231,0.18), transparent 65%)' }} />
      <div style={{ maxWidth: 980, margin: '0 auto', position: 'relative' }}>
        <Badge tone="purple" dot>About WPistic</Badge>
        <h1 style={{
          fontSize: 64, fontWeight: 800, letterSpacing: '-0.035em',
          color: '#0D0F1A', lineHeight: 1.08, margin: '20px 0 24px', textWrap: 'balance',
        }}>
          WordPress is the operating system of the open web.{' '}
          <span style={{
            background: '#00C04B',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>WPistic is the business layer on top of it.</span>
        </h1>
        <p style={{ fontSize: 18, color: '#4B5263', lineHeight: 1.65, maxWidth: 720 }}>
          We build the connected SaaS hub that turns a WordPress site into a real business — with AI agents, automations, licensing, CRM, inbox, analytics, and a beautiful dashboard that owners actually open every day.
        </p>
      </div>
    </section>

    {/* Mission + Why */}
    <MktSection eyebrow="Why we exist" title="WordPress runs the web. The tooling around it hasn't kept up." narrow>
      <div style={{ fontSize: 17, color: '#4B5263', lineHeight: 1.85, textWrap: 'pretty' }}>
        <p style={{ margin: '0 0 18px' }}>
          A real WordPress business stitches together fifteen plugins, three SaaS subscriptions, and a spreadsheet that nobody trusts. Licenses live in email threads. Customer data is split across five tools. Automations are duct-taped through Zapier.
        </p>
        <p style={{ margin: '0 0 18px' }}>
          We started WPistic because we'd lived this — running plugin businesses, agencies, and WooCommerce stores ourselves. We wanted one workspace that knew everything about our business: the contacts, the conversations, the orders, the licenses, the websites, the AI usage. One screen. One source of truth.
        </p>
        <p style={{ margin: 0 }}>
          WPistic is built on a simple bet: <strong style={{ color: '#0D0F1A' }}>the future of small business runs on WordPress, automated by AI, and managed from one connected SaaS hub.</strong>
        </p>
      </div>
    </MktSection>

    {/* Values */}
    <MktSection bg="#F8F9FF" eyebrow="What we believe" title="Our principles">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
        {[
          { i: 'zap',    t: 'Practical automation',     d: 'Automation that earns its keep on day one. No demos that fall apart. No AI that hallucinates pricing.' },
          { i: 'shield', t: 'WordPress-first ownership', d: "Your data, your content, your customer relationships — on your WordPress site. Not locked into someone else's cloud." },
          { i: 'spark',  t: 'Scalable business tools',  d: "Built for a solo founder on day one, ready for an agency with fifty client sites on day one thousand." },
          { i: 'cube',   t: 'Clean user experience',    d: "Software you don't dread opening. Dense when it needs to be, calm when it doesn't." },
        ].map(v => (
          <Card key={v.t} padding={30} hoverable>
            <div style={{ width: 50, height: 50, borderRadius: 14, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center', marginBottom: 18 }}>
              <Icon name={v.i} size={22} />
            </div>
            <div style={{ fontSize: 20, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>{v.t}</div>
            <p style={{ fontSize: 14.5, color: '#4B5263', lineHeight: 1.65, margin: '10px 0 0' }}>{v.d}</p>
          </Card>
        ))}
      </div>
    </MktSection>

    {/* Story / Founder */}
    <MktSection eyebrow="Origin" title="A founder's note">
      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: 36, alignItems: 'flex-start', maxWidth: 980, margin: '0 auto' }}>
        <div>
          <div style={{
            width: 200, height: 200, borderRadius: 24,
            background: 'linear-gradient(135deg, #6C5CE7, #00C04B)',
            color: '#fff', fontSize: 64, fontWeight: 800, letterSpacing: '-0.04em',
            display: 'grid', placeItems: 'center',
          }}>SR</div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A', marginTop: 14 }}>Shuvo Roy</div>
          <div style={{ fontSize: 12.5, color: '#6B7280' }}>Founder & CEO</div>
          <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
            {['𝕏', 'in', 'gh'].map(s => (
              <div key={s} style={{ width: 28, height: 28, borderRadius: 7, background: '#F3F1FE', color: '#5649CC', display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 700 }}>{s}</div>
            ))}
          </div>
        </div>
        <div style={{ fontSize: 16, color: '#4B5263', lineHeight: 1.85 }}>
          <p style={{ margin: '0 0 16px' }}>
            I started building WordPress plugins in 2014. By 2020 I was running a small plugin business, an agency, and three WooCommerce stores — and I had a different dashboard for every single one. Six payment processors, four analytics tools, two CRMs, and a license system that lived in a Google Sheet.
          </p>
          <p style={{ margin: '0 0 16px' }}>
            The day I built a Zap that emailed me when a license was about to expire — only to forget to renew the Zap subscription — I knew this had to change.
          </p>
          <p style={{ margin: 0 }}>
            WPistic is the dashboard I wished I'd had. We're building it for the next million WordPress businesses, with a team that has lived this problem firsthand.
          </p>
        </div>
      </div>
    </MktSection>

    {/* Roadmap */}
    <MktSection bg="#0D0F1A" eyebrow="Ecosystem roadmap" title="What we're building next.">
      <div style={{ maxWidth: 880, margin: '0 auto' }}>
        {[
          { q: 'Now · 2026', ship: ['Chatbotistic 5.0','Bookingistic group tours','License agency white-label'], status: 'live' },
          { q: 'Q3 2026',    ship: ['WPAgentistic GA','Postistic AI-image schedules','Verifyistic GA'], status: 'live' },
          { q: 'Q4 2026',    ship: ['Insightistic v2 + AI alerts','Custom agent SDK','Native mobile apps'], status: 'next' },
          { q: 'Q1 2027',    ship: ['SOC 2 Type II','SSO + SAML for Agency','EU data residency'], status: 'next' },
          { q: 'Q2 2027',    ship: ['Open marketplace for third-party agents','Workflows v2','LLM router'], status: 'planned' },
        ].map((r, i) => (
          <div key={r.q} style={{
            display: 'grid', gridTemplateColumns: '140px 1fr 100px', gap: 24,
            padding: '22px 0', borderTop: i === 0 ? '1px solid #1E2130' : 'none', borderBottom: '1px solid #1E2130',
            alignItems: 'center',
          }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#9499BA', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{r.q}</div>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {r.ship.map(s => (
                <span key={s} style={{
                  fontSize: 12.5, fontWeight: 600,
                  color: r.status === 'live' ? '#4ED48A' : r.status === 'next' ? '#fff' : '#9499BA',
                  background: r.status === 'live' ? 'rgba(0,192,75,0.10)' : r.status === 'next' ? '#13161F' : 'transparent',
                  padding: '6px 12px', borderRadius: 9999,
                  border: r.status === 'planned' ? '1px dashed #1E2130' : 'none',
                }}>{s}</span>
              ))}
            </div>
            <Badge tone={r.status === 'live' ? 'green' : r.status === 'next' ? 'purple' : 'gray'} dot>{r.status}</Badge>
          </div>
        ))}
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="Join the WordPressistic ecosystem."
      sub="The future of WordPress businesses runs on connected, AI-powered tools — built for owners, by owners." />
  </MarketingPage>
);

// ═════════════════════════════════════════════════════════════
// BLOG
// ═════════════════════════════════════════════════════════════
const BLOG_CATEGORIES = ['All', 'WordPress Automation', 'WooCommerce Growth', 'AI Agents', 'Plugin Business', 'Product Updates', 'Guides'];

const BLOG_POSTS = [
  { featured: true, cat: 'AI Agents', title: 'We replaced our Tier 1 support team with one Chatbotistic agent — here\'s what actually happened.',
    excerpt: 'A 60-day case study from ShopGlow showing what AI agents handle well, where they fall apart, and how to design the human-handoff that doesn\'t feel like a downgrade.',
    author: 'Sarah Patel', date: 'May 24, 2026', read: '12 min',
    color: 'linear-gradient(135deg, #6C5CE7, #1A1659)' },
  { cat: 'WooCommerce Growth', title: 'The cart-recovery playbook: 6 messages that recovered $47k in 90 days',
    excerpt: 'Exact templates, timing, and sequencing for WhatsApp cart recovery — with the numbers from real WooCommerce stores.',
    author: 'Marcus Reed', date: 'May 18, 2026', read: '8 min', color: '#E8FAF0' },
  { cat: 'WordPress Automation', title: 'Stop using Zapier for things WPistic does natively',
    excerpt: 'Five common Zapier workflows that you can rebuild inside WPistic in under five minutes — and run faster.',
    author: 'Priya Shah', date: 'May 14, 2026', read: '6 min', color: '#F3F1FE' },
  { cat: 'Plugin Business', title: 'How we got from $0 to $10k MRR selling one WordPress plugin',
    excerpt: 'A transparent breakdown of pricing, positioning, and the licensing infrastructure that made the difference.',
    author: 'Daniel Hoff', date: 'May 11, 2026', read: '11 min', color: '#DBEAFE' },
  { cat: 'Product Updates', title: 'WPAgentistic enters public beta — custom agents in 90 seconds',
    excerpt: 'The custom-agent studio is live. Train an agent on your URLs, docs, and product catalog. No code.',
    author: 'WPistic Team', date: 'May 08, 2026', read: '4 min', color: '#FEF3C7' },
  { cat: 'Guides', title: 'A complete WooCommerce + WhatsApp setup guide for 2026',
    excerpt: 'Cloud API approval, template messages, opt-in flows, and the WordPress glue code that makes it all work.',
    author: 'Jordan Yu', date: 'May 04, 2026', read: '14 min', color: '#FEE2E2' },
  { cat: 'AI Agents', title: 'Why we don\'t let AI agents handle pricing negotiation',
    excerpt: 'A short note on guardrails — the boring, unsexy thing that determines whether your AI is an asset or a liability.',
    author: 'Sarah Patel', date: 'Apr 30, 2026', read: '5 min', color: '#E9E6FD' },
  { cat: 'Product Updates', title: 'Insightistic v2: SEO + revenue + AI usage on one canvas',
    excerpt: 'The biggest analytics release in WPistic\'s history. Cluster keywords by intent, attribute revenue to channels, see everything in one screen.',
    author: 'WPistic Team', date: 'Apr 28, 2026', read: '6 min', color: '#F3F1FE' },
];

const BlogPage = ({ onNav }) => {
  const [cat, setCat] = React.useState('All');
  const filtered = cat === 'All' ? BLOG_POSTS.filter(p => !p.featured) : BLOG_POSTS.filter(p => p.cat === cat && !p.featured);
  const featured = BLOG_POSTS.find(p => p.featured);
  return (
    <MarketingPage onNav={onNav}>
      <section style={{
        background: 'linear-gradient(155deg, #F3F1FE 0%, #EEF0FF 60%, #E8FAF0 130%)',
        padding: '56px 36px 36px',
      }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <Badge tone="purple" dot>WPistic Blog</Badge>
          <h1 style={{
            fontSize: 52, fontWeight: 800, letterSpacing: '-0.035em',
            color: '#0D0F1A', lineHeight: 1.1, margin: '18px 0 14px', maxWidth: 700, textWrap: 'balance',
          }}>
            Guides, growth, and product updates for WordPress business owners.
          </h1>
          <p style={{ fontSize: 16.5, color: '#4B5263', maxWidth: 600, margin: 0, lineHeight: 1.6 }}>
            Practical playbooks from real WooCommerce stores, plugin businesses, and agencies running on WPistic.
          </p>
        </div>
      </section>

      {/* Featured */}
      {cat === 'All' && (
        <section style={{ padding: '36px 36px 16px', background: '#fff' }}>
          <div style={{ maxWidth: 1240, margin: '0 auto' }}>
            <Card padding={0} hoverable style={{ overflow: 'hidden' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0, alignItems: 'stretch' }}>
                <div style={{ background: featured.color, color: '#fff', padding: '48px 44px', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', minHeight: 320, position: 'relative' }}>
                  <div style={{ position: 'absolute', top: 24, left: 24 }}>
                    <Badge tone="green" dot>Featured</Badge>
                  </div>
                  <Icon name="spark" size={72} color="rgba(255,255,255,0.16)" />
                </div>
                <div style={{ padding: '40px 40px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                  <Badge tone="purple">{featured.cat}</Badge>
                  <h2 style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-0.025em', color: '#0D0F1A', lineHeight: 1.2, margin: '14px 0 14px', textWrap: 'balance' }}>{featured.title}</h2>
                  <p style={{ fontSize: 14.5, color: '#4B5263', lineHeight: 1.65, margin: '0 0 20px' }}>{featured.excerpt}</p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
                    <AvatarCircle name={featured.author} size={36} />
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>{featured.author}</div>
                      <div style={{ fontSize: 11.5, color: '#9499BA' }}>{featured.date} · {featured.read}</div>
                    </div>
                  </div>
                  <Btn variant="primary" size="md" rightIcon="arrow" style={{ alignSelf: 'flex-start' }}>Read article</Btn>
                </div>
              </div>
            </Card>
          </div>
        </section>
      )}

      {/* Filters */}
      <section style={{ padding: '32px 36px 16px', background: '#fff' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {BLOG_CATEGORIES.map(c => (
              <button key={c} onClick={() => setCat(c)} style={{
                fontFamily: 'inherit', fontSize: 12.5, fontWeight: 600,
                padding: '7px 14px', borderRadius: 9999,
                background: cat===c ? '#0D0F1A' : '#fff',
                color: cat===c ? '#fff' : '#4B5263',
                border: cat===c ? '1px solid #0D0F1A' : '1px solid #EDEFF8',
                cursor: 'pointer',
              }}>{c}</button>
            ))}
          </div>
          <TextInput placeholder="Search articles…" icon="search" size="sm" style={{ width: 240 }} />
        </div>
      </section>

      {/* Grid */}
      <section style={{ padding: '24px 36px 80px', background: '#fff' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18 }}>
          {filtered.map((p, i) => (
            <Card key={i} padding={0} hoverable style={{ overflow: 'hidden' }}>
              <div style={{ background: p.color, height: 160, display: 'grid', placeItems: 'center' }}>
                <Icon name="cube" size={48} color="rgba(255,255,255,0.6)" />
              </div>
              <div style={{ padding: 22 }}>
                <Badge tone="purple">{p.cat}</Badge>
                <h3 style={{ fontSize: 17, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.015em', lineHeight: 1.3, margin: '12px 0 8px' }}>{p.title}</h3>
                <p style={{ fontSize: 13, color: '#4B5263', lineHeight: 1.55, margin: '0 0 16px' }}>{p.excerpt}</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingTop: 14, borderTop: '1px solid #F0F2FF' }}>
                  <AvatarCircle name={p.author} size={28} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: '#0D0F1A' }}>{p.author}</div>
                    <div style={{ fontSize: 11, color: '#9499BA' }}>{p.date} · {p.read}</div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Newsletter CTA */}
      <MktSection bg="#F8F9FF" narrow>
        <Card padding={40} style={{ textAlign: 'center', background: 'linear-gradient(135deg, #F3F1FE, #E8FAF0)' }}>
          <Badge tone="purple" dot>Newsletter</Badge>
          <h2 style={{ fontSize: 32, fontWeight: 800, letterSpacing: '-0.025em', color: '#0D0F1A', margin: '14px 0 10px' }}>
            One short email a month. No spam.
          </h2>
          <p style={{ fontSize: 14.5, color: '#4B5263', maxWidth: 480, margin: '0 auto 22px', lineHeight: 1.6 }}>
            Best of the WPistic blog, product updates, and growth experiments from real WordPress businesses.
          </p>
          <div style={{ display: 'flex', gap: 8, maxWidth: 420, margin: '0 auto', background: '#fff', borderRadius: 9999, padding: 5, border: '1px solid #EDEFF8' }}>
            <input placeholder="you@company.com" style={{ flex: 1, padding: '10px 18px', border: 'none', background: 'transparent', outline: 'none', fontSize: 13.5, fontFamily: 'inherit', color: '#0D0F1A' }} />
            <Btn variant="primary" size="sm" rightIcon="arrow">Subscribe</Btn>
          </div>
        </Card>
      </MktSection>
    </MarketingPage>
  );
};

// ═════════════════════════════════════════════════════════════
// AFFILIATE
// ═════════════════════════════════════════════════════════════
const AffiliatePage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <MktHero
      eyebrow="WPistic Affiliate · 30% recurring"
      title="Get paid every month"
      gradient="for every customer you refer."
      sub="30% recurring commission for the lifetime of the customer. No cap, no tiers, no games — just real revenue share."
      ctas={[
        <Btn key="a" size="xl" onClick={() => onNav('register')} rightIcon="arrow">Apply to program</Btn>,
        <Btn key="d" size="xl" variant="outline">Affiliate FAQ</Btn>,
      ]} />

    {/* Commission */}
    <MktSection eyebrow="Commission structure" title="Simple. Generous. Recurring.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {[
          { v: '30%', l: 'Recurring commission', desc: 'Every month, forever, on every customer you refer.' },
          { v: '90 day', l: 'Cookie window', desc: 'Your referral counts for 90 days after the first click.' },
          { v: '$0',  l: 'Minimum payout', desc: 'Paid via Stripe Connect, weekly. No minimum threshold.' },
        ].map(s => (
          <Card key={s.l} padding={32} hoverable style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 60, fontWeight: 800, letterSpacing: '-0.04em',
              background: '#00C04B',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              lineHeight: 1 }}>{s.v}</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A', letterSpacing: '0.04em', textTransform: 'uppercase', marginTop: 10 }}>{s.l}</div>
            <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: '10px 0 0' }}>{s.desc}</p>
          </Card>
        ))}
      </div>
    </MktSection>

    {/* Who for */}
    <MktSection bg="#F8F9FF" eyebrow="Who it's for" title="Perfect partners for WPistic">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        {[
          { i: 'globe', t: 'WordPress agencies', d: 'Refer client sites, earn while you build.' },
          { i: 'spark', t: 'Course creators', d: 'WordPress, WooCommerce, or membership trainers.' },
          { i: 'users', t: 'Consultants',     d: 'Recommend tools you actually use.' },
          { i: 'chart', t: 'Content creators', d: 'Blog, YouTube, podcast affiliates welcome.' },
        ].map(p => (
          <Card key={p.t} padding={22} hoverable>
            <div style={{ width: 40, height: 40, borderRadius: 11, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center', marginBottom: 14 }}>
              <Icon name={p.i} size={18} />
            </div>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>{p.t}</div>
            <p style={{ fontSize: 12.5, color: '#4B5263', lineHeight: 1.55, margin: '6px 0 0' }}>{p.d}</p>
          </Card>
        ))}
      </div>
    </MktSection>

    {/* Dashboard preview */}
    <MktSection eyebrow="Affiliate dashboard" title="Track every click, signup, and dollar in one screen.">
      <Card padding={28}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 22 }}>
          {[
            { l: 'Clicks (30d)', v: '4,218', t: '+18%' },
            { l: 'Signups', v: '142', t: '+22%' },
            { l: 'Active customers', v: '38', t: '+5' },
            { l: 'MRR commission', v: '$842', t: '+$120' },
          ].map(s => (
            <div key={s.l} style={{ padding: 18, background: '#F8F9FF', borderRadius: 14, border: '1px solid #EDEFF8' }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#9499BA', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{s.l}</div>
              <div style={{ fontSize: 24, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em', marginTop: 6 }}>{s.v}</div>
              <div style={{ fontSize: 11, color: '#00C04B', fontWeight: 700, marginTop: 4 }}>↑ {s.t}</div>
            </div>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 18 }}>
          <Card padding={22}>
            <SectionLabel>Top referrals · this month</SectionLabel>
            {[
              { c: 'ByteFoundry Agency', plan: 'Agency annual', mrr: '$99/mo', s: 'Active 8 mo' },
              { c: 'Aurora Studio',      plan: 'Business annual', mrr: '$39/mo', s: 'Active 3 mo' },
              { c: 'TheClub.co',         plan: 'Business monthly', mrr: '$49/mo', s: 'Active 1 mo' },
            ].map(r => (
              <div key={r.c} style={{ padding: '12px 0', borderBottom: '1px solid #F0F2FF', display: 'flex', alignItems: 'center', gap: 10 }}>
                <AvatarCircle name={r.c} size={32} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>{r.c}</div>
                  <div style={{ fontSize: 11.5, color: '#6B7280' }}>{r.plan} · {r.s}</div>
                </div>
                <div style={{ fontSize: 13.5, fontWeight: 700, color: '#00C04B' }}>{r.mrr}</div>
              </div>
            ))}
          </Card>
          <Card padding={22} dark>
            <SectionLabel light color="#6C5CE7">Your referral link</SectionLabel>
            <code style={{
              display: 'block', padding: 12, background: '#0a0c14',
              borderRadius: 10, color: '#4ED48A', fontSize: 12,
              fontFamily: 'JetBrains Mono, monospace', marginTop: 4,
              border: '1px solid #1E2130', overflow: 'auto',
            }}>wpistic.com/?via=shuvo</code>
            <Btn variant="green" size="sm" leftIcon="copy" style={{ width: '100%', justifyContent: 'center', marginTop: 12 }}>Copy link</Btn>
            <div style={{ marginTop: 18 }}>
              <SectionLabel light color="#6C5CE7">Brand assets</SectionLabel>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 6 }}>
                {['Logo pack','Banners','Screenshots','Email templates'].map(a => (
                  <span key={a} style={{ fontSize: 11.5, fontWeight: 600, color: '#9499BA', background: '#13161F', padding: '5px 10px', borderRadius: 9999, cursor: 'pointer' }}>{a}</span>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </Card>
    </MktSection>

    {/* How it works */}
    <MktSection bg="#F8F9FF" eyebrow="How it works" title="From signup to first payout in days.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        {[
          { n: '01', t: 'Apply', d: 'Tell us about your audience and how you plan to promote WPistic.' },
          { n: '02', t: 'Get approved', d: '24-hour review. We approve most applicants who fit.' },
          { n: '03', t: 'Share your link', d: 'Use your tracked link, banners, and product screenshots.' },
          { n: '04', t: 'Earn forever', d: 'Get 30% MRR for the lifetime of every customer you refer.' },
        ].map(s => (
          <div key={s.n} style={{ padding: 24 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: '#6C5CE7', letterSpacing: '0.08em' }}>STEP {s.n}</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em', marginTop: 8 }}>{s.t}</div>
            <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: '8px 0 0' }}>{s.d}</p>
          </div>
        ))}
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="Recommend tools that actually work."
      sub="Apply to the WPistic affiliate program — most applicants are approved within 24 hours."
      primaryLabel="Apply to program" secondaryLabel="Affiliate FAQ" secondaryTarget="contact" />
  </MarketingPage>
);

// ═════════════════════════════════════════════════════════════
// PRESS
// ═════════════════════════════════════════════════════════════
const PressPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <MktHero
      eyebrow="Press kit"
      title="Brand, screenshots, and"
      gradient="company facts — all in one place."
      sub="Everything press, podcasters, conference organizers, and partners need to write about WPistic accurately."
      ctas={[
        <Btn key="d" size="xl" leftIcon="download" onClick={() => onNav('contact')}>Download press kit (12 MB)</Btn>,
        <Btn key="c" size="xl" variant="outline" onClick={() => onNav('contact')}>Contact press</Btn>,
      ]} />

    {/* Company facts */}
    <MktSection eyebrow="Company facts" title="WPistic by the numbers">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        {[
          { l: 'Founded', v: '2024' },
          { l: 'Headquarters', v: 'New York, NY' },
          { l: 'Team size', v: '38 across 14 countries' },
          { l: 'Workspaces', v: '2,847+ businesses' },
          { l: 'Products', v: '11 WordPress plugins' },
          { l: 'AI conversations', v: '2.1M / month' },
          { l: 'Connected sites', v: '14,200+' },
          { l: 'Funding', v: 'Bootstrapped & profitable' },
        ].map(f => (
          <Card key={f.l} padding={22}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#9499BA', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{f.l}</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.015em', marginTop: 6 }}>{f.v}</div>
          </Card>
        ))}
      </div>
    </MktSection>

    {/* Brand kit cards */}
    <MktSection bg="#F8F9FF" eyebrow="Downloads" title="Brand assets">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {[
          { t: 'Logo pack',         d: 'SVG, PNG (light + dark), favicon, social',  size: '2.4 MB',  preview: 'logo' },
          { t: 'Product screenshots', d: '4K screenshots of every key product UI',   size: '8.1 MB', preview: 'shots' },
          { t: 'Brand guidelines',  d: 'Colors, typography, voice, dos and don\'ts', size: '1.2 MB', preview: 'guide' },
          { t: 'Founder headshots', d: 'High-res photos of the founding team',       size: '12 MB',  preview: 'people' },
          { t: 'Demo videos',       d: '30s, 60s, 2-minute product demos · MP4',     size: '24 MB',  preview: 'video' },
          { t: 'One-pager PDF',     d: 'Company overview, mission, traction, asks',  size: '480 KB', preview: 'pdf' },
        ].map(k => (
          <Card key={k.t} padding={0} hoverable style={{ overflow: 'hidden' }}>
            <div style={{
              height: 160, display: 'grid', placeItems: 'center',
              background: k.preview === 'logo'  ? 'linear-gradient(135deg, #F3F1FE, #fff)'
                : k.preview === 'shots' ? 'linear-gradient(135deg, #1A1659, #0D0F1A)'
                : k.preview === 'guide' ? 'linear-gradient(135deg, #E8FAF0, #fff)'
                : k.preview === 'people' ? 'linear-gradient(135deg, #FEF3C7, #fff)'
                : k.preview === 'video' ? 'linear-gradient(135deg, #DBEAFE, #fff)'
                : 'linear-gradient(135deg, #FEE2E2, #fff)',
            }}>
              {k.preview === 'logo' && <Logo size={48} />}
              {k.preview === 'shots' && <Icon name="dashboard" size={48} color="rgba(255,255,255,0.5)" />}
              {k.preview === 'guide' && <Icon name="spark" size={48} color="rgba(0,192,75,0.5)" />}
              {k.preview === 'people' && <Icon name="users" size={48} color="rgba(245,158,11,0.5)" />}
              {k.preview === 'video' && <Icon name="cube" size={48} color="rgba(59,130,246,0.5)" />}
              {k.preview === 'pdf' && <Icon name="download" size={48} color="rgba(239,68,68,0.5)" />}
            </div>
            <div style={{ padding: 22 }}>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>{k.t}</div>
              <p style={{ fontSize: 12.5, color: '#4B5263', lineHeight: 1.55, margin: '6px 0 14px' }}>{k.d}</p>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 11.5, color: '#9499BA', fontWeight: 600 }}>{k.size}</span>
                <Btn variant="ghost" size="xs" leftIcon="download">Download</Btn>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </MktSection>

    {/* In the press */}
    <MktSection eyebrow="In the press" title="Recent coverage">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {[
          { src: 'WP Tavern',           q: '"The most ambitious WordPress SaaS launch of 2026."',           d: 'May 22, 2026' },
          { src: 'WordPress.com Blog',  q: '"WPistic is what every multi-plugin business has been missing."', d: 'May 18, 2026' },
          { src: 'TechCrunch',          q: '"AI agents that respect WordPress\'s open-web ethos."',          d: 'May 12, 2026' },
        ].map(p => (
          <Card key={p.src} padding={26} hoverable>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#6C5CE7', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 14 }}>{p.src}</div>
            <p style={{ fontSize: 16, color: '#0D0F1A', lineHeight: 1.55, margin: 0, fontWeight: 500, fontStyle: 'italic' }}>{p.q}</p>
            <div style={{ fontSize: 12, color: '#9499BA', marginTop: 16 }}>{p.d}</div>
          </Card>
        ))}
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="Writing about WPistic?"
      sub="Email press@wpistic.com — we reply within one business day with anything you need."
      primaryLabel="Email press" secondaryLabel="Download press kit" secondaryTarget="contact" />
  </MarketingPage>
);

Object.assign(window, { AboutPage, BlogPage, AffiliatePage, PressPage });
