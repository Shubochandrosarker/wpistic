// shell.jsx — App shell: sidebar + topbar + page router

const SIDEBAR_GROUPS = [
  {
    label: 'Workspace',
    items: [
      { id: 'dashboard', icon: 'dashboard', label: 'Dashboard' },
      { id: 'products', icon: 'cube', label: 'Products', badge: '11' },
      { id: 'licenses', icon: 'key', label: 'Licenses', badge: '12' },
      { id: 'downloads', icon: 'download', label: 'Downloads' },
      { id: 'websites', icon: 'globe', label: 'Websites' },
    ],
  },
  {
    label: 'Automation',
    items: [
      { id: 'agents', icon: 'bot', label: 'AI Agents' },
      { id: 'automations', icon: 'zap', label: 'Automations' },
    ],
  },
  {
    label: 'Customer',
    items: [
      { id: 'crm', icon: 'users', label: 'CRM' },
      { id: 'inbox', icon: 'inbox', label: 'Inbox', badge: '3', badgeTone: 'green' },
      { id: 'analytics', icon: 'chart', label: 'Analytics' },
    ],
  },
  {
    label: 'Account',
    items: [
      { id: 'billing', icon: 'card', label: 'Billing' },
      { id: 'support', icon: 'help', label: 'Support' },
      { id: 'developers', icon: 'code', label: 'Developers' },
      { id: 'settings', icon: 'cog', label: 'Settings' },
    ],
  },
];

const Sidebar = ({ active, onNav }) => (
  <aside className="scroll" style={{
    width: 256, height: '100%', overflowY: 'auto',
    background: '#fff',
    borderRight: '1px solid #EDEFF8',
    display: 'flex', flexDirection: 'column',
    flexShrink: 0,
  }}>
    {/* Brand */}
    <div style={{
      padding: '20px 22px 18px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      borderBottom: '1px solid #F0F2FF',
    }}>
      <div style={{ cursor: 'pointer' }} onClick={() => onNav('homepage')}>
        <Logo size={28} />
      </div>
      <button onClick={() => onNav('homepage')} title="View site"
        style={{
          background: '#F0F2FF', border: 'none', borderRadius: 8,
          width: 30, height: 30, display: 'grid', placeItems: 'center',
          color: '#6B7280', cursor: 'pointer',
        }}>
        <Icon name="external" size={14} />
      </button>
    </div>

    {/* Workspace switcher */}
    <div style={{ padding: '14px 14px 0' }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '9px 10px', background: '#F8F9FF',
        border: '1px solid #EDEFF8', borderRadius: 10, cursor: 'pointer',
      }}>
        <div style={{
          width: 32, height: 32, borderRadius: 9,
          background: 'linear-gradient(135deg, #6C5CE7, #4137A8)',
          color: '#fff', display: 'grid', placeItems: 'center',
          fontSize: 13, fontWeight: 800,
        }}>SR</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, color: '#0D0F1A', lineHeight: 1.2 }}>
            Shuvo's Workspace
          </div>
          <div style={{ fontSize: 11, color: '#6B7280', marginTop: 2 }}>
            Business · 5 sites
          </div>
        </div>
        <Icon name="cog" size={14} color="#9499BA" />
      </div>
    </div>

    {/* Nav groups */}
    <nav style={{ padding: '16px 14px', flex: 1 }}>
      {SIDEBAR_GROUPS.map((g, gi) => (
        <div key={g.label} style={{ marginBottom: gi === SIDEBAR_GROUPS.length - 1 ? 0 : 18 }}>
          <div style={{
            fontSize: 10.5, fontWeight: 700, letterSpacing: '0.12em',
            textTransform: 'uppercase', color: '#9499BA',
            padding: '6px 12px 8px',
          }}>{g.label}</div>
          {g.items.map(it => (
            <div key={it.id}
              className={'side-item ' + (active === it.id ? 'active' : '')}
              onClick={() => onNav(it.id)}>
              <Icon name={it.icon} size={17} />
              <span style={{ flex: 1 }}>{it.label}</span>
              {it.badge && (
                <span style={{
                  fontSize: 10.5, fontWeight: 700,
                  padding: '2px 7px', borderRadius: 9999,
                  background: it.badgeTone === 'green'
                    ? (active === it.id ? 'rgba(0,192,75,0.95)' : '#E8FAF0')
                    : (active === it.id ? 'rgba(255,255,255,0.20)' : '#F0F2FF'),
                  color: it.badgeTone === 'green'
                    ? (active === it.id ? '#fff' : '#007C2F')
                    : (active === it.id ? '#fff' : '#6B7280'),
                }}>{it.badge}</span>
              )}
            </div>
          ))}
        </div>
      ))}
    </nav>

    {/* Plan card */}
    <div style={{ padding: 14, paddingTop: 0 }}>
      <div style={{
        background: 'linear-gradient(145deg, #1A1659, #0D0F1A)',
        borderRadius: 14, padding: 16, color: '#fff',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -40, right: -40, width: 140, height: 140,
          background: 'radial-gradient(circle, rgba(108,92,231,0.45), transparent 70%)',
        }} />
        <div style={{ position: 'relative' }}>
          <Badge tone="green" dot>Business</Badge>
          <div style={{ fontSize: 14, fontWeight: 700, marginTop: 10, lineHeight: 1.35 }}>
            74% of monthly usage
          </div>
          <div style={{
            height: 6, background: 'rgba(255,255,255,0.10)', borderRadius: 9999,
            marginTop: 10, overflow: 'hidden',
          }}>
            <div style={{
              width: '74%', height: '100%',
              background: 'linear-gradient(90deg, #6C5CE7, #00C04B)',
              borderRadius: 9999,
            }} />
          </div>
          <div style={{ fontSize: 11, color: '#9499BA', marginTop: 8 }}>
            Resets in 9 days
          </div>
          <button style={{
            marginTop: 12, width: '100%',
            background: '#fff', color: '#6C5CE7', border: 'none',
            borderRadius: 9999, padding: '8px 14px',
            fontSize: 12.5, fontWeight: 700, cursor: 'pointer',
            fontFamily: 'inherit',
          }}>Upgrade plan</button>
        </div>
      </div>
    </div>
  </aside>
);

const Topbar = ({ title, subtitle, actions }) => (
  <header style={{
    height: 64, flexShrink: 0,
    background: '#fff',
    borderBottom: '1px solid #EDEFF8',
    display: 'flex', alignItems: 'center',
    padding: '0 28px', gap: 20,
  }}>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.02em', lineHeight: 1.2 }}>
        {title}
      </div>
      {subtitle && (
        <div style={{ fontSize: 12.5, color: '#6B7280', marginTop: 2 }}>{subtitle}</div>
      )}
    </div>

    {/* Search */}
    <TextInput placeholder="Search products, sites, licenses…" icon="search"
      size="sm" style={{ width: 320 }} />

    {actions}

    {/* Notifications */}
    <button style={{
      width: 36, height: 36, borderRadius: 10,
      background: '#F8F9FF', border: '1px solid #EDEFF8',
      display: 'grid', placeItems: 'center', cursor: 'pointer',
      position: 'relative',
    }}>
      <Icon name="bell" size={16} color="#4B5263" />
      <span style={{
        position: 'absolute', top: 7, right: 7,
        width: 8, height: 8, borderRadius: 9999,
        background: '#EF4444', border: '2px solid #fff',
      }} />
    </button>

    {/* User */}
    <div style={{
      display: 'flex', alignItems: 'center', gap: 9,
      padding: '4px 12px 4px 4px',
      background: '#F8F9FF', border: '1px solid #EDEFF8',
      borderRadius: 9999, cursor: 'pointer',
    }}>
      <div style={{
        width: 30, height: 30, borderRadius: '50%',
        background: 'linear-gradient(135deg, #00C04B, #6C5CE7)',
        color: '#fff', display: 'grid', placeItems: 'center',
        fontSize: 12, fontWeight: 800,
      }}>SR</div>
      <div style={{ fontSize: 12.5, fontWeight: 600, color: '#0D0F1A' }}>Shuvo Roy</div>
    </div>
  </header>
);

const AppShell = ({ active, onNav, title, subtitle, actions, children, hideTopbar }) => (
  <div style={{ display: 'flex', width: '100%', height: '100%' }}>
    <Sidebar active={active} onNav={onNav} />
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0,
      background: 'var(--bg-page)',
    }}>
      {!hideTopbar && <Topbar title={title} subtitle={subtitle} actions={actions} />}
      <main className="scroll" style={{ flex: 1, overflowY: hideTopbar ? 'hidden' : 'auto', minHeight: 0 }}>
        {children}
      </main>
    </div>
  </div>
);

Object.assign(window, { AppShell, Sidebar, Topbar });
