// downloads.jsx — Plugin downloads center

const DOWNLOADS = [
  { id: 'chatbotistic', version: '4.2.1', size: '2.4 MB', updated: 'May 22, 2026', wp: '6.0+', php: '7.4+', woo: true, channel: 'Stable',
    notes: ['New: Image attachment support in AI inbox','Improved: 38% faster response generation','Fixed: WhatsApp media webhook edge case'] },
  { id: 'memberistic',  version: '3.1.4', size: '1.8 MB', updated: 'May 18, 2026', wp: '6.0+', php: '7.4+', woo: false, channel: 'Stable',
    notes: ['New: Pause/resume member subscriptions','Improved: Cancellation flow with retention offers','Fixed: Stripe webhook duplicate event handling'] },
  { id: 'bookingistic', version: '2.7.0', size: '2.1 MB', updated: 'May 15, 2026', wp: '6.0+', php: '8.0+', woo: true,  channel: 'Stable',
    notes: ['New: Group bookings with capacity limits','New: Apple Wallet pass for confirmations','Fixed: Calendar timezone offset bug'] },
  { id: 'insightistic', version: '5.0.8', size: '3.2 MB', updated: 'May 24, 2026', wp: '6.0+', php: '8.0+', woo: true,  channel: 'Stable',
    notes: ['New: GA4 funnel reports','New: Search Console keyword clusters','Fixed: Heatmap rendering on long pages'] },
  { id: 'wpagentistic',  version: '0.9.3', size: '4.6 MB', updated: 'May 23, 2026', wp: '6.2+', php: '8.1+', woo: true,  channel: 'Beta',
    notes: ['Beta: Custom agent training from URL','New: Agent handoff to human','Fixed: Token usage report accuracy'] },
  { id: 'postistic',    version: '1.8.2', size: '1.6 MB', updated: 'May 12, 2026', wp: '6.0+', php: '7.4+', woo: false, channel: 'Stable',
    notes: ['New: Threaded social post scheduling','New: AI image generation for headers','Fixed: WordPress block editor compatibility'] },
  { id: 'crmistic',     version: '2.5.0', size: '2.0 MB', updated: 'May 09, 2026', wp: '6.0+', php: '7.4+', woo: true,  channel: 'Stable',
    notes: ['New: Pipeline view with kanban','New: Bulk tagging and merge','Fixed: Email open tracking pixel'] },
  { id: 'licenseistic', version: '1.4.1', size: '1.2 MB', updated: 'May 06, 2026', wp: '6.0+', php: '7.4+', woo: true,  channel: 'Stable',
    notes: ['New: Lifetime license issuing','Improved: Domain enforcement edge cases','Fixed: REST namespace conflict'] },
  { id: 'fflistic',     version: '0.6.1', size: '0.9 MB', updated: 'Apr 28, 2026', wp: '6.0+', php: '8.0+', woo: true,  channel: 'Beta',
    notes: ['Beta: ATF Form 4473 automation','New: Dealer-to-dealer transfer log','Fixed: WooCommerce checkout flag'] },
];

const DownloadsPage = () => {
  const [channel, setChannel] = React.useState('All');
  const [openId, setOpenId] = React.useState('chatbotistic');
  const filtered = channel === 'All' ? DOWNLOADS : DOWNLOADS.filter(d => d.channel === channel);

  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      <PageHeader
        eyebrow="Downloads"
        title="Plugin downloads"
        subtitle="Latest builds, beta channel, install guides, and changelogs."
        actions={
          <>
            <Btn variant="border-card" size="md" leftIcon="external">All releases</Btn>
            <Btn variant="border-card" size="md" leftIcon="code">Composer / WP-CLI</Btn>
          </>
        } />

      {/* Channel tabs */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', gap: 6 }}>
          {['All', 'Stable', 'Beta'].map(c => {
            const count = c === 'All' ? DOWNLOADS.length : DOWNLOADS.filter(d => d.channel === c).length;
            const active = channel === c;
            return (
              <button key={c} onClick={() => setChannel(c)} style={{
                fontFamily: 'inherit', fontSize: 13, fontWeight: 600,
                padding: '8px 14px', borderRadius: 9999,
                background: active ? '#0D0F1A' : '#fff',
                color: active ? '#fff' : '#4B5263',
                border: active ? '1px solid #0D0F1A' : '1px solid #EDEFF8',
                cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 7,
              }}>
                {c}
                <span style={{
                  fontSize: 10.5, fontWeight: 700,
                  background: active ? 'rgba(255,255,255,0.15)' : '#F0F2FF',
                  color: active ? '#fff' : '#6B7280',
                  padding: '1px 7px', borderRadius: 9999,
                }}>{count}</span>
              </button>
            );
          })}
        </div>
        <TextInput placeholder="Search plugins…" icon="search" size="sm" style={{ width: 280 }} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 18 }}>
        {/* Download list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(d => {
            const p = PRODUCTS.find(p => p.id === d.id);
            const open = openId === d.id;
            return (
              <Card key={d.id} padding={20} style={{
                border: open ? '1.5px solid #6C5CE7' : '1px solid #EDEFF8',
                boxShadow: open ? '0 12px 32px rgba(108,92,231,0.14)' : '0 2px 12px rgba(108,92,231,0.05)',
                cursor: 'pointer',
              }} >
                <div onClick={() => setOpenId(d.id)} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={44} radius={13} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>{p.name}</div>
                      <Badge tone={d.channel==='Beta'?'amber':'green'} dot>{d.channel} v{d.version}</Badge>
                    </div>
                    <div style={{ fontSize: 12.5, color: '#6B7280', marginTop: 3, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                      <span>Updated {d.updated}</span><span>·</span>
                      <span>{d.size}</span><span>·</span>
                      <span>WP {d.wp} · PHP {d.php}</span>
                      {d.woo && <><span>·</span><span style={{ color: '#7C3AED', fontWeight: 600 }}>WooCommerce</span></>}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <Btn variant="border-card" size="sm" leftIcon="code">Changelog</Btn>
                    <Btn variant="primary" size="sm" leftIcon="download">.zip</Btn>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Detail / install guide */}
        {(() => {
          const d = DOWNLOADS.find(x => x.id === openId);
          const p = PRODUCTS.find(x => x.id === openId);
          if (!p) return null;
          return (
            <div style={{ position: 'sticky', top: 12, alignSelf: 'flex-start' }}>
              <Card padding={24}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
                  <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={48} radius={14} />
                  <div>
                    <div style={{ fontSize: 17, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>{p.name}</div>
                    <div style={{ fontSize: 12.5, color: '#6B7280' }}>v{d.version} · {d.channel} channel</div>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
                  <Btn variant="primary" size="md" leftIcon="download" style={{ flex: 1, justifyContent: 'center' }}>Download .zip</Btn>
                  <Btn variant="border-card" size="md" leftIcon="copy" />
                </div>

                {/* What's new */}
                <div style={{ marginBottom: 18 }}>
                  <div style={{ fontSize: 11.5, fontWeight: 700, color: '#6C5CE7', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10 }}>
                    What's new
                  </div>
                  {d.notes.map((n, i) => (
                    <div key={i} style={{ display: 'flex', gap: 8, fontSize: 13, color: '#2E3245', marginBottom: 8, lineHeight: 1.5 }}>
                      <span style={{ color: '#00C04B', fontWeight: 800 }}>•</span>{n}
                    </div>
                  ))}
                </div>

                {/* Install guide */}
                <div style={{
                  padding: 16, background: '#0D0F1A', borderRadius: 12, marginBottom: 16,
                  fontFamily: 'JetBrains Mono, monospace', fontSize: 12, lineHeight: 1.7,
                }}>
                  <div style={{ color: '#9499BA', marginBottom: 6 }}># Install via WP-CLI</div>
                  <div style={{ color: '#4ED48A' }}>wp plugin install {p.id}.zip --activate</div>
                  <div style={{ color: '#9499BA', marginTop: 10, marginBottom: 6 }}># Or upload .zip via WP Admin → Plugins → Add New</div>
                </div>

                {/* Compatibility */}
                <div style={{
                  display: 'flex', gap: 6, flexWrap: 'wrap',
                  paddingTop: 16, borderTop: '1px solid #F0F2FF',
                }}>
                  <CompatChip>WordPress {d.wp}</CompatChip>
                  <CompatChip>PHP {d.php}</CompatChip>
                  {d.woo && <CompatChip green>WooCommerce</CompatChip>}
                  <CompatChip>{d.size}</CompatChip>
                </div>

                <a href="#" onClick={e => e.preventDefault()} style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                  fontSize: 13, fontWeight: 600, color: '#6C5CE7',
                  textDecoration: 'none', marginTop: 14,
                }}>
                  Read full installation guide <Icon name="arrow" size={13} />
                </a>
              </Card>
            </div>
          );
        })()}
      </div>
    </div>
  );
};

const CompatChip = ({ children, green }) => (
  <span style={{
    fontSize: 11, fontWeight: 700, color: green ? '#007C2F' : '#4B5263',
    background: green ? '#E8FAF0' : '#F0F2FF',
    padding: '4px 10px', borderRadius: 9999,
    letterSpacing: '0.03em',
  }}>{children}</span>
);

Object.assign(window, { DownloadsPage });
