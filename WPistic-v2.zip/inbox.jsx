// inbox.jsx — Unified inbox (3-pane)

const CHANNELS = [
  { id: 'all',      label: 'All',        icon: 'inbox', count: 12 },
  { id: 'whatsapp', label: 'WhatsApp',   icon: 'chat',  count: 5, tone: 'green' },
  { id: 'web',      label: 'Website',    icon: 'globe', count: 3, tone: 'purple' },
  { id: 'email',    label: 'Email',      icon: 'inbox', count: 2, tone: 'purple' },
  { id: 'tickets',  label: 'Tickets',    icon: 'help',  count: 2, tone: 'amber' },
];

const CONVOS = [
  { id: 1, name: 'Sarah Lin', channel: 'WhatsApp', site: 'shopglow.com',
    last: 'Add 2, please.', time: '2m', unread: 2, status: 'AI handling', tone: 'green' },
  { id: 2, name: 'Marcus Reed', channel: 'Website', site: 'shopglow.com',
    last: 'Do you ship to Canada by Friday?', time: '11m', unread: 1, status: 'You', tone: 'purple' },
  { id: 3, name: 'Daniel Hoff', channel: 'Email', site: 'wanderly.travel',
    last: 'Looks great. One question about the day 3 hike…', time: '34m', unread: 0, status: 'Pending', tone: 'amber' },
  { id: 4, name: 'Priya Shah', channel: 'WhatsApp', site: 'theclub.co',
    last: 'Thanks! Renewed for another year.', time: '1h', unread: 0, status: 'Resolved', tone: 'gray' },
  { id: 5, name: 'Emily Park', channel: 'Website', site: 'shopglow.com',
    last: 'My discount code DROP15 isn\'t working.', time: '2h', unread: 1, status: 'You', tone: 'purple' },
  { id: 6, name: 'Jordan Reyes', channel: 'Ticket #1182', site: 'agency-tools.io',
    last: '[Bookingistic] Calendar sync stopped at 3pm.', time: '3h', unread: 0, status: 'Sarah', tone: 'amber' },
  { id: 7, name: 'Aisha Khan', channel: 'WhatsApp', site: 'shopglow.com',
    last: 'When will the velvet armchair restock?', time: '5h', unread: 0, status: 'AI handling', tone: 'green' },
  { id: 8, name: 'Tom Becker', channel: 'Email', site: 'wanderly.travel',
    last: 'Subject: Group of 8 — possible discount?', time: '6h', unread: 0, status: 'Pending', tone: 'amber' },
];

const MESSAGES = [
  { side: 'them', t: 'Hi! Do you have the Aurora pendant lamp in matte black?', time: '11:38' },
  { side: 'ai',   t: 'Hi Sarah! Yes — we have 12 in stock. Free shipping over $80, delivered in 2–4 days. Want me to add it to your cart?', time: '11:38' },
  { side: 'them', t: 'How long is the warranty?', time: '11:39' },
  { side: 'ai',   t: '2 years on all electrical components and a lifetime guarantee on the metal frame.', time: '11:39' },
  { side: 'them', t: 'Perfect. Do you offer installation?', time: '11:40' },
  { side: 'ai',   t: 'We can recommend a local certified installer in your area. Want me to share contacts in NY for $60-100 service?', time: '11:40' },
  { side: 'them', t: 'Yes please. And add 2 lamps to my cart.', time: '11:41' },
  { side: 'ai',   t: 'Done — 2 Aurora pendants in matte black added. Cart total: $158.00 (free shipping included). Here are 3 installers near you with reviews and pricing →', time: '11:41' },
  { side: 'them', t: 'Add 2, please.', time: '11:42' },
];

const InboxPage = () => {
  const [convo, setConvo] = React.useState(CONVOS[0]);
  const [ch, setCh] = React.useState('all');
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header strip */}
      <div style={{
        padding: '18px 24px 14px', background: '#fff',
        borderBottom: '1px solid #EDEFF8', display: 'flex',
        justifyContent: 'space-between', alignItems: 'center', flexShrink: 0,
      }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 800, color: '#0D0F1A', margin: 0, letterSpacing: '-0.02em' }}>Inbox</h1>
          <div style={{ fontSize: 12.5, color: '#6B7280', marginTop: 2 }}>
            12 open · 8 across WhatsApp, web chat, email, and tickets
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="border-card" size="sm" leftIcon="filter">Filter</Btn>
          <Btn variant="primary" size="sm" leftIcon="plus">New conversation</Btn>
        </div>
      </div>

      <div style={{ flex: 1, minHeight: 0, display: 'grid', gridTemplateColumns: '224px 360px 1fr 280px', background: '#fff' }}>
        {/* Channels */}
        <aside style={{ borderRight: '1px solid #EDEFF8', padding: '18px 12px' }}>
          <div style={{ fontSize: 10.5, fontWeight: 700, color: '#9499BA', letterSpacing: '0.1em', textTransform: 'uppercase', padding: '4px 10px 10px' }}>
            Channels
          </div>
          {CHANNELS.map(c => {
            const active = ch === c.id;
            const tones = { green: '#00C04B', purple: '#6C5CE7', amber: '#F59E0B' };
            return (
              <div key={c.id} onClick={() => setCh(c.id)} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '8px 10px', borderRadius: 9, cursor: 'pointer',
                background: active ? '#F3F1FE' : 'transparent',
                color: active ? '#5649CC' : '#4B5263',
                fontSize: 13, fontWeight: active ? 700 : 500,
                marginBottom: 2,
              }}>
                <Icon name={c.icon} size={15} color={c.tone ? tones[c.tone] : (active ? '#6C5CE7' : '#9499BA')} />
                <span style={{ flex: 1 }}>{c.label}</span>
                <span style={{
                  fontSize: 11, fontWeight: 700,
                  color: active ? '#5649CC' : '#9499BA',
                }}>{c.count}</span>
              </div>
            );
          })}

          <div style={{ fontSize: 10.5, fontWeight: 700, color: '#9499BA', letterSpacing: '0.1em', textTransform: 'uppercase', padding: '22px 10px 10px' }}>
            Status
          </div>
          {[
            { label: 'Open',     dot: '#6C5CE7' },
            { label: 'Pending',  dot: '#F59E0B' },
            { label: 'Resolved', dot: '#9499BA' },
            { label: 'AI handling', dot: '#00C04B' },
          ].map(s => (
            <div key={s.label} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '7px 10px', fontSize: 13, color: '#4B5263',
            }}>
              <span style={{ width: 7, height: 7, borderRadius: 9999, background: s.dot }} />
              {s.label}
            </div>
          ))}
        </aside>

        {/* Conversation list */}
        <div className="scroll" style={{ borderRight: '1px solid #EDEFF8', overflowY: 'auto' }}>
          <div style={{ padding: 12, position: 'sticky', top: 0, background: '#fff', zIndex: 1, borderBottom: '1px solid #F0F2FF' }}>
            <TextInput placeholder="Search conversations…" icon="search" size="sm" />
          </div>
          {CONVOS.map(c => (
            <div key={c.id} onClick={() => setConvo(c)} style={{
              display: 'flex', gap: 12, padding: '14px 16px',
              cursor: 'pointer',
              borderBottom: '1px solid #F0F2FF',
              background: convo?.id === c.id ? '#F3F1FE' : 'transparent',
              borderLeft: convo?.id === c.id ? '3px solid #6C5CE7' : '3px solid transparent',
            }}>
              <AvatarCircle name={c.name} size={38} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A', flex: 1 }}>{c.name}</div>
                  <div style={{ fontSize: 11, color: '#9499BA' }}>{c.time}</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: '#6B7280', marginBottom: 4 }}>
                  <ChannelChip name={c.channel} />
                  <span>·</span>
                  <span>{c.site}</span>
                </div>
                <div style={{
                  fontSize: 12.5, color: c.unread ? '#0D0F1A' : '#6B7280',
                  fontWeight: c.unread ? 600 : 400, lineHeight: 1.4,
                  display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
                }}>{c.last}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
                  <Badge tone={c.tone} dot>{c.status}</Badge>
                  {c.unread > 0 && (
                    <span style={{
                      fontSize: 10, fontWeight: 800, color: '#fff',
                      background: '#6C5CE7', borderRadius: 9999,
                      padding: '1px 7px', minWidth: 18, textAlign: 'center',
                    }}>{c.unread}</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Chat panel */}
        <div style={{ display: 'flex', flexDirection: 'column', background: '#F8F9FF', minWidth: 0 }}>
          {/* Chat header */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '14px 22px', background: '#fff', borderBottom: '1px solid #EDEFF8', flexShrink: 0,
          }}>
            <AvatarCircle name={convo.name} size={38} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14.5, fontWeight: 700, color: '#0D0F1A' }}>{convo.name}</div>
              <div style={{ fontSize: 11.5, color: '#6B7280', display: 'flex', alignItems: 'center', gap: 6 }}>
                <ChannelChip name={convo.channel} /> · {convo.site}
              </div>
            </div>
            <Btn variant="border-card" size="xs" leftIcon="check">Mark resolved</Btn>
            <Btn variant="border-card" size="xs" leftIcon="users">Assign</Btn>
          </div>

          {/* Messages */}
          <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '24px 28px' }}>
            <div style={{ textAlign: 'center', fontSize: 11, color: '#9499BA', marginBottom: 18, fontWeight: 600 }}>
              Today · WhatsApp via Chatbotistic
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {MESSAGES.map((m, i) => <MsgBubble key={i} msg={m} />)}
              <TypingDots />
            </div>
          </div>

          {/* AI suggestion */}
          <div style={{ padding: '12px 22px', background: '#fff', borderTop: '1px solid #EDEFF8' }}>
            <div style={{
              padding: '12px 14px', borderRadius: 12,
              background: 'linear-gradient(120deg, #F3F1FE, #E8FAF0)',
              border: '1px solid #E9E6FD', marginBottom: 12,
              display: 'flex', alignItems: 'flex-start', gap: 10,
            }}>
              <div style={{ width: 28, height: 28, borderRadius: 8, background: '#fff', color: '#6C5CE7', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                <Icon name="spark" size={14} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#5649CC', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 4 }}>AI Suggested reply</div>
                <div style={{ fontSize: 13, color: '#0D0F1A', lineHeight: 1.55 }}>
                  Order created — cart total is $158.00. Want me to send the secure checkout link?
                </div>
              </div>
              <Btn variant="primary" size="xs">Use</Btn>
              <Btn variant="ghost-gray" size="xs">Dismiss</Btn>
            </div>

            <div style={{
              display: 'flex', alignItems: 'flex-end', gap: 10,
              padding: '10px 14px',
              background: '#F8F9FF', border: '1.5px solid #E8EAFF',
              borderRadius: 16,
            }}>
              <textarea placeholder="Reply to Sarah…"
                rows="2" style={{
                  flex: 1, border: 'none', background: 'transparent',
                  outline: 'none', resize: 'none', fontFamily: 'inherit',
                  fontSize: 13.5, color: '#0D0F1A', lineHeight: 1.5,
                }} />
              <div style={{ display: 'flex', gap: 6 }}>
                <button style={iconBtnStyle}><Icon name="copy" size={15} color="#6B7280" /></button>
                <button style={iconBtnStyle}><Icon name="spark" size={15} color="#6C5CE7" /></button>
                <Btn variant="primary" size="sm" rightIcon="arrow">Send</Btn>
              </div>
            </div>
          </div>
        </div>

        {/* Customer profile panel */}
        <aside style={{ background: '#fff', borderLeft: '1px solid #EDEFF8', padding: 22, overflowY: 'auto' }} className="scroll">
          <div style={{ textAlign: 'center', marginBottom: 16 }}>
            <AvatarCircle name={convo.name} size={64} />
            <div style={{ fontSize: 15, fontWeight: 800, color: '#0D0F1A', marginTop: 10 }}>{convo.name}</div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>Customer · since Apr 2026</div>
            <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginTop: 10 }}>
              <Badge tone="green" dot>VIP</Badge>
              <Badge tone="purple">WooCommerce</Badge>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 18 }}>
            <ProfileStat v="$2,840" l="Lifetime" />
            <ProfileStat v="11" l="Orders" />
            <ProfileStat v="4.9★" l="Reviews" />
            <ProfileStat v="84%" l="Engagement" />
          </div>

          <div style={{ marginBottom: 18 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#9499BA', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>Latest orders</div>
            {[
              { id: '#4218', d: 'Just now', total: '$158.00' },
              { id: '#4096', d: 'Apr 28', total: '$284.20' },
              { id: '#3940', d: 'Apr 12', total: '$96.00' },
            ].map((o, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '8px 0', borderBottom: i < 2 ? '1px solid #F0F2FF' : 'none',
                fontSize: 12.5,
              }}>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', color: '#5649CC', fontWeight: 600 }}>{o.id}</span>
                <span style={{ color: '#6B7280', flex: 1 }}>{o.d}</span>
                <span style={{ fontWeight: 700, color: '#0D0F1A' }}>{o.total}</span>
              </div>
            ))}
          </div>

          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#9499BA', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>Quick actions</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <Btn variant="border-card" size="sm" leftIcon="users" style={{ justifyContent: 'flex-start' }}>Open CRM record</Btn>
              <Btn variant="border-card" size="sm" leftIcon="zap" style={{ justifyContent: 'flex-start' }}>Trigger automation</Btn>
              <Btn variant="border-card" size="sm" leftIcon="card" style={{ justifyContent: 'flex-start' }}>Send checkout link</Btn>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

const iconBtnStyle = {
  width: 32, height: 32, borderRadius: 9, background: '#fff',
  border: '1px solid #EDEFF8', cursor: 'pointer',
  display: 'grid', placeItems: 'center',
};

const ProfileStat = ({ v, l }) => (
  <div style={{
    padding: 10, background: '#F8F9FF', border: '1px solid #EDEFF8',
    borderRadius: 10, textAlign: 'center',
  }}>
    <div style={{ fontSize: 15, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>{v}</div>
    <div style={{ fontSize: 10, fontWeight: 700, color: '#9499BA', letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 2 }}>{l}</div>
  </div>
);

const ChannelChip = ({ name }) => {
  const map = {
    WhatsApp: { bg: '#E8FAF0', fg: '#007C2F' },
    Website: { bg: '#F3F1FE', fg: '#5649CC' },
    Email: { bg: '#DBEAFE', fg: '#1E40AF' },
  };
  const m = map[name] || (name && name.startsWith('Ticket') ? { bg: '#FEF3C7', fg: '#92400E' } : { bg: '#F0F2FF', fg: '#4B5263' });
  return (
    <span style={{
      fontSize: 10.5, fontWeight: 700, color: m.fg, background: m.bg,
      padding: '2px 7px', borderRadius: 9999, letterSpacing: '0.02em',
    }}>{name}</span>
  );
};

const MsgBubble = ({ msg: m }) => {
  if (m.side === 'them') {
    return (
      <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
        <div style={{
          maxWidth: '62%', padding: '10px 14px', borderRadius: 16,
          borderBottomLeftRadius: 4, background: '#fff', border: '1px solid #EDEFF8',
          fontSize: 13.5, color: '#0D0F1A', lineHeight: 1.5,
        }}>{m.t}
          <div style={{ fontSize: 10, color: '#9499BA', marginTop: 4 }}>{m.time}</div>
        </div>
      </div>
    );
  }
  return (
    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6 }}>
      <div style={{
        maxWidth: '62%', padding: '10px 14px', borderRadius: 16,
        borderBottomRightRadius: 4, color: '#fff', fontSize: 13.5, lineHeight: 1.5,
        background: 'linear-gradient(135deg, #6C5CE7, #5649CC)',
      }}>{m.t}
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.7)', marginTop: 4, display: 'flex', alignItems: 'center', gap: 5 }}>
          {m.time} <Icon name="spark" size={9} /> Sent by AI
        </div>
      </div>
    </div>
  );
};

const TypingDots = () => (
  <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
    <div style={{
      padding: '12px 14px', borderRadius: 16, borderBottomLeftRadius: 4,
      background: '#fff', border: '1px solid #EDEFF8',
      display: 'flex', gap: 4,
    }}>
      {[0, 1, 2].map(i => (
        <span key={i} style={{
          width: 6, height: 6, borderRadius: 9999, background: '#9499BA',
          animation: `pulse-dot 1.4s ease-in-out infinite ${i * 0.2}s`,
        }} />
      ))}
    </div>
  </div>
);

Object.assign(window, { InboxPage });
