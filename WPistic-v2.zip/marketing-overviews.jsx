// marketing-overviews.jsx — Products Overview, Ecosystem Overview, Platform Overview, Pricing, Contact

// ═════════════════════════════════════════════════════════════
// PRODUCTS OVERVIEW
// ═════════════════════════════════════════════════════════════
const ProductsOverviewPage = ({ onNav }) => {
  const [cat, setCat] = React.useState('All');
  const cats = ['All', 'AI & Automation', 'Operations', 'Commerce', 'Members & Booking', 'Specialized'];
  const productCats = {
    'chatbotistic': 'AI & Automation', 'wpagentistic': 'AI & Automation', 'postistic': 'AI & Automation',
    'crmistic': 'Operations', 'licenseistic': 'Operations',
    'memberistic': 'Members & Booking', 'bookingistic': 'Members & Booking',
    'insightistic': 'Operations',
    'fflistic': 'Specialized', 'travelistic': 'Specialized', 'verifyistic': 'Specialized',
  };
  const all = PRODUCTS.concat([
    { id: 'travelistic',  name: 'Travelistic',  bg: '#E8FAF0', color: '#007C2F', glyph: 'inbox',
      tagline: 'Tours, multi-day itineraries, and travel booking.', features: ['Tour packages','Multi-leg itineraries','Voucher PDFs'] },
    { id: 'verifyistic',  name: 'Verifyistic',  bg: '#F3F1FE', color: '#5649CC', glyph: 'shield',
      tagline: 'ID verification, KYC, and compliance for WP forms.', features: ['ID checks','KYC capture','Audit logs'] },
  ]);
  const filtered = cat === 'All' ? all : all.filter(p => productCats[p.id] === cat);

  return (
    <MarketingPage onNav={onNav}>
      <MktHero
        eyebrow="WPistic Product Suite"
        title="Eleven products."
        gradient="One ecosystem."
        sub="Browse the full WPistic plugin line — flagship, specialized, and AI-powered. Each one snaps into the same workspace, license manager, and CRM."
        ctas={[
          <Btn key="s" size="xl" onClick={() => onNav('register')} rightIcon="arrow">Start free</Btn>,
          <Btn key="p" size="xl" variant="outline" onClick={() => onNav('pricing')}>See pricing</Btn>,
        ]}
        kicker={['Free tier — no credit card', 'Works with any WordPress site', 'Unified license + analytics']} />

      {/* Category filters */}
      <section style={{ padding: '48px 36px 16px', background: '#fff' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
          {cats.map(c => (
            <button key={c} onClick={() => setCat(c)} style={{
              fontFamily: 'inherit', fontSize: 13, fontWeight: 600,
              padding: '8px 16px', borderRadius: 9999,
              background: cat===c ? '#6C5CE7' : '#fff',
              color: cat===c ? '#fff' : '#4B5263',
              border: cat===c ? '1px solid #6C5CE7' : '1px solid #EDEFF8',
              cursor: 'pointer',
            }}>{c}</button>
          ))}
        </div>
      </section>

      {/* Featured + grid */}
      <section style={{ padding: '24px 36px 80px', background: '#fff' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          {cat === 'All' && <FeaturedProduct onNav={onNav} />}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
            {filtered.map(p => <OverviewProductCard key={p.id} product={p} onNav={onNav} />)}
          </div>
        </div>
      </section>

      {/* Which product do I need */}
      <MktSection bg="#F8F9FF" eyebrow="Guidance"
        title="Which product do I need?"
        sub="Pick a starting point — most teams add a second product within the first month.">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
          {[
            { who: 'WooCommerce store', start: 'Chatbotistic + Insightistic', why: 'Recover carts, answer pre-sales questions, watch revenue grow.', icon: 'cube', target: 'product-chatbotistic' },
            { who: 'Membership site', start: 'Memberistic + CRMistic', why: 'Manage members, automate renewals, follow up on churn risk.', icon: 'members', glyph: true, target: 'product-memberistic' },
            { who: 'Booking business', start: 'Bookingistic + Chatbotistic', why: 'Take bookings, send reminders, confirm via WhatsApp.', icon: 'calendar', glyph: true, target: 'product-bookingistic' },
            { who: 'Agency / multi-site', start: 'License Manager + Insightistic', why: 'One dashboard for every client site, license, and report.', icon: 'users', target: 'platform-licenses' },
          ].map(b => (
            <Card key={b.who} padding={22} hoverable>
              <div style={{ width: 42, height: 42, borderRadius: 12, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center', marginBottom: 14 }}>
                {b.glyph
                  ? <ProductGlyph name={b.icon} color="#6C5CE7" bg="transparent" size={22} radius={0} />
                  : <Icon name={b.icon} size={20} />}
              </div>
              <SectionLabel>{b.who}</SectionLabel>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>{b.start}</div>
              <p style={{ fontSize: 13, color: '#4B5263', lineHeight: 1.55, margin: '8px 0 14px', minHeight: 56 }}>{b.why}</p>
              <a onClick={() => onNav(b.target)} style={{
                fontSize: 13, fontWeight: 700, color: '#6C5CE7',
                display: 'inline-flex', alignItems: 'center', gap: 6, cursor: 'pointer',
              }}>Explore <Icon name="arrow" size={13} /></a>
            </Card>
          ))}
        </div>
      </MktSection>

      <MktFinalCTA onNav={onNav}
        title="Eleven products. One subscription. One workspace."
        sub="Install the plugins you need. Add more as you grow. Everything talks to everything." />
    </MarketingPage>
  );
};

const FeaturedProduct = ({ onNav }) => {
  const p = PRODUCTS.find(p => p.id === 'chatbotistic');
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0,
      background: 'linear-gradient(135deg, #1A1659, #0D0F1A)',
      borderRadius: 24, marginBottom: 32, overflow: 'hidden',
      position: 'relative',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(circle 400px at 80% 30%, rgba(108,92,231,0.30), transparent 70%)',
      }} />
      <div style={{ padding: '40px 44px', position: 'relative', color: '#fff' }}>
        <Badge tone="green" dot>Featured · 12,847 installs</Badge>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 18, marginBottom: 16 }}>
          <ProductGlyph name={p.glyph} color={p.color} bg="#fff" size={48} radius={14} />
          <div>
            <div style={{ fontSize: 30, fontWeight: 800, letterSpacing: '-0.025em' }}>{p.name}</div>
            <div style={{ fontSize: 13, color: '#9499BA' }}>AI multi-channel inbox</div>
          </div>
        </div>
        <p style={{ fontSize: 15, color: '#D4D6E0', lineHeight: 1.65, marginBottom: 24 }}>
          The AI inbox for WordPress + WooCommerce. Sells, supports, and recovers carts across WhatsApp, web chat, and email — runs on your store, your rules.
        </p>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="green" size="md" onClick={() => onNav('product-chatbotistic')} rightIcon="arrow">Explore Chatbotistic</Btn>
          <Btn variant="dark-outline" size="md" onClick={() => onNav('register')}>Try free</Btn>
        </div>
      </div>
      <div style={{ padding: '40px 44px', position: 'relative' }}>
        <FakeChatPreview />
      </div>
    </div>
  );
};

const FakeChatPreview = () => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 380, marginLeft: 'auto' }}>
    {[
      { side: 'user', t: 'Do you ship to Toronto by Friday?' },
      { side: 'ai', t: "Yes — orders before 3pm ET ship same-day, you'd have it Thursday." },
      { side: 'user', t: 'Add 2 Aurora pendants to my cart.' },
      { side: 'ai', t: '✓ Done. Cart total: $158. Want me to apply your VIP discount?' },
    ].map((m, i) => m.side === 'user' ? (
      <div key={i} style={{
        alignSelf: 'flex-start', maxWidth: '85%',
        padding: '10px 14px', borderRadius: 16, borderBottomLeftRadius: 4,
        background: '#fff', color: '#0D0F1A', fontSize: 13.5, lineHeight: 1.5,
      }}>{m.t}</div>
    ) : (
      <div key={i} style={{
        alignSelf: 'flex-end', maxWidth: '85%',
        padding: '10px 14px', borderRadius: 16, borderBottomRightRadius: 4,
        background: 'linear-gradient(135deg, #6C5CE7, #00C04B)', color: '#fff', fontSize: 13.5, lineHeight: 1.5,
      }}>{m.t}</div>
    ))}
  </div>
);

const OverviewProductCard = ({ product: p, onNav }) => (
  <Card padding={26} hoverable>
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, marginBottom: 16 }}>
      <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={44} radius={13} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 17, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.01em' }}>{p.name}</div>
      </div>
    </div>
    <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: '0 0 16px', minHeight: 64 }}>{p.tagline}</p>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 18 }}>
      {p.features.slice(0, 3).map(f => (
        <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12.5, color: '#2E3245' }}>
          <Icon name="check" size={13} color="#00C04B" strokeWidth={2.5} />{f}
        </div>
      ))}
    </div>
    <div style={{ display: 'flex', gap: 6, paddingTop: 16, borderTop: '1px solid #F0F2FF' }}>
      <Btn variant="ghost" size="sm" rightIcon="arrow"
        onClick={() => p.id === 'chatbotistic' ? onNav('product-chatbotistic')
          : p.id === 'memberistic' ? onNav('product-memberistic')
          : p.id === 'bookingistic' ? onNav('product-bookingistic')
          : p.id === 'insightistic' ? onNav('product-insightistic')
          : p.id === 'crmistic' ? onNav('product-crmistic')
          : onNav('products-overview')}>Explore</Btn>
      <Btn variant="ghost-gray" size="sm" leftIcon="download">Try free</Btn>
    </div>
  </Card>
);

// ═════════════════════════════════════════════════════════════
// ECOSYSTEM OVERVIEW
// ═════════════════════════════════════════════════════════════
const EcosystemOverviewPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <MktHero
      eyebrow="WordPressistic Ecosystem"
      title="WPistic is the operating layer"
      gradient="for the whole WordPressistic ecosystem."
      sub="Eleven independent products. One account, one workspace, one license system. They share customers, contacts, automations, inbox, and analytics — automatically."
      ctas={[
        <Btn key="s" size="xl" onClick={() => onNav('register')} rightIcon="arrow">Start free</Btn>,
        <Btn key="p" size="xl" variant="outline" onClick={() => onNav('products-overview')}>Browse products</Btn>,
      ]} />

    {/* Diagram */}
    <section style={{ padding: '24px 36px 80px', background: '#fff' }}>
      <div style={{ maxWidth: 1240, margin: '0 auto' }}>
        <EcosystemDiagram />
      </div>
    </section>

    {/* Pillars */}
    <MktSection bg="#F8F9FF" eyebrow="What you get for free"
      title="One account. One ecosystem. One source of truth."
      sub="Every WPistic plugin you install gets these capabilities for free — no extra setup, no separate logins.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {[
          { icon: 'key',   title: 'One license system', desc: 'Activate every plugin from one license manager. Issue licenses to clients, enforce domains, see expiry alerts.' },
          { icon: 'users', title: 'Shared CRM',         desc: 'A customer who chats with Chatbotistic, books via Bookingistic, and subscribes via Memberistic is one contact — not three.' },
          { icon: 'inbox', title: 'Shared inbox',       desc: 'WhatsApp, web chat, email, and support tickets — every channel and every plugin lands in one unified inbox.' },
          { icon: 'zap',   title: 'Shared automations', desc: 'Trigger on any plugin event. "When a member churns, send a WhatsApp win-back via Chatbotistic" — that\'s one rule.' },
          { icon: 'chart', title: 'Shared analytics',   desc: 'Insightistic stitches GA4, Search Console, Woo, and AI usage from every plugin into one set of dashboards.' },
          { icon: 'globe', title: 'Multi-site control', desc: 'Manage one WordPress site or fifty from a single workspace. Agencies and franchises live here.' },
        ].map(f => <FeatureGridCard key={f.title} {...f} />)}
      </div>
    </MktSection>

    {/* Categories */}
    <MktSection eyebrow="Four ecosystem layers" title="How the products fit together"
      sub="Each WPistic product sits in one of four ecosystem layers. Mix and match — they're built to work together.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 18 }}>
        {[
          { name: 'WordPress Plugins', desc: 'Core building blocks for content, members, commerce, bookings, and posts.', tone: 'purple',
            items: ['Memberistic','Bookingistic','Postistic','Travelistic'], target: 'ecosystem-plugins' },
          { name: 'AI & Automation', desc: 'AI agents and automation infrastructure that runs across every plugin.', tone: 'green',
            items: ['Chatbotistic','WPAgentistic','Automations engine'], target: 'ecosystem-ai' },
          { name: 'Business Operations', desc: 'CRM, billing, support, licensing, and the customer-facing dashboard.', tone: 'purple',
            items: ['CRMistic','Licenseistic','Insightistic'], target: 'ecosystem-ops' },
          { name: 'Integrations', desc: 'Native connections to the platforms you already use to run the business.', tone: 'green',
            items: ['WhatsApp Cloud API','Stripe','GA4 + Search Console','Slack & Zapier'], target: 'ecosystem-integrations' },
        ].map(c => {
          const tones = c.tone === 'green' ? { bg: '#E8FAF0', fg: '#00C04B' } : { bg: '#F3F1FE', fg: '#6C5CE7' };
          return (
            <Card key={c.name} padding={30} hoverable>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14 }}>
                <div style={{ width: 44, height: 44, borderRadius: 12, background: tones.bg, color: tones.fg, display: 'grid', placeItems: 'center' }}>
                  <Icon name="cube" size={20} />
                </div>
                <a onClick={() => onNav(c.target)} style={{ fontSize: 13, fontWeight: 700, color: '#6C5CE7', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                  Explore <Icon name="arrow" size={12} />
                </a>
              </div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>{c.name}</div>
              <p style={{ fontSize: 14, color: '#4B5263', lineHeight: 1.6, margin: '8px 0 18px' }}>{c.desc}</p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {c.items.map(i => (
                  <span key={i} style={{ fontSize: 12, fontWeight: 600, color: '#4B5263', background: '#F8F9FF', border: '1px solid #EDEFF8', padding: '5px 11px', borderRadius: 9999 }}>{i}</span>
                ))}
              </div>
            </Card>
          );
        })}
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="A connected stack beats a pile of plugins."
      sub="WPistic gives every product the same workspace, licenses, contacts, inbox, automations, and analytics." />
  </MarketingPage>
);

const EcosystemDiagram = () => (
  <div style={{
    position: 'relative', height: 520,
    background: 'linear-gradient(160deg, #F3F1FE, #E8FAF0)',
    borderRadius: 28, padding: 40, overflow: 'hidden',
  }}>
    {/* Central hub */}
    <div style={{
      position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
      width: 200, height: 200, borderRadius: '50%',
      background: 'linear-gradient(135deg, #1A1659, #0D0F1A)',
      color: '#fff', display: 'grid', placeItems: 'center', textAlign: 'center',
      boxShadow: '0 24px 60px rgba(108,92,231,0.45), inset 0 0 0 6px rgba(255,255,255,0.06)',
      zIndex: 5,
    }}>
      <div>
        <div style={{ fontSize: 14, color: '#9499BA', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase' }}>The hub</div>
        <div style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-0.02em', marginTop: 4 }}>WPistic</div>
        <div style={{ fontSize: 12, color: '#9499BA', marginTop: 8, lineHeight: 1.4, maxWidth: 140 }}>
          Workspace, licenses, agents, automations
        </div>
      </div>
    </div>
    {/* Orbiting products */}
    {[
      { id: 'chatbotistic',  angle: -85,  r: 220 },
      { id: 'memberistic',   angle: -35,  r: 220 },
      { id: 'bookingistic',  angle: 15,   r: 220 },
      { id: 'insightistic',  angle: 65,   r: 220 },
      { id: 'crmistic',      angle: 115,  r: 220 },
      { id: 'postistic',     angle: 165,  r: 220 },
      { id: 'licenseistic',  angle: 215,  r: 220 },
      { id: 'wpagentistic',  angle: 265,  r: 220 },
    ].map(o => {
      const p = PRODUCTS.find(p => p.id === o.id);
      if (!p) return null;
      const rad = (o.angle * Math.PI) / 180;
      const x = Math.cos(rad) * o.r;
      const y = Math.sin(rad) * o.r * 0.7;
      return (
        <div key={p.id} style={{
          position: 'absolute', top: '50%', left: '50%',
          transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
          zIndex: 2,
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 9,
            padding: '8px 14px 8px 8px', background: '#fff',
            borderRadius: 9999, boxShadow: '0 8px 22px rgba(108,92,231,0.16)',
            border: '1px solid rgba(255,255,255,0.6)',
          }}>
            <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={26} radius={8} />
            <span style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>{p.name}</span>
          </div>
        </div>
      );
    })}
    {/* Connection lines */}
    <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', zIndex: 1 }}>
      <defs>
        <radialGradient id="ringFade">
          <stop offset="40%" stopColor="#6C5CE7" stopOpacity="0" />
          <stop offset="100%" stopColor="#6C5CE7" stopOpacity="0.18" />
        </radialGradient>
      </defs>
      <circle cx="50%" cy="50%" r="190" fill="none" stroke="url(#ringFade)" strokeWidth="60" />
    </svg>
  </div>
);

// ═════════════════════════════════════════════════════════════
// PLATFORM OVERVIEW
// ═════════════════════════════════════════════════════════════
const PlatformOverviewPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <MktHero
      eyebrow="WPistic Platform"
      title="The infrastructure layer behind"
      gradient="every WPistic product."
      sub="Licenses, AI agents, automations, inbox, analytics, and developer APIs — built once, shared by every plugin."
      ctas={[
        <Btn key="s" size="xl" onClick={() => onNav('register')} rightIcon="arrow">Start free</Btn>,
        <Btn key="d" size="xl" variant="outline" onClick={() => onNav('platform-developers')}>Read API docs</Btn>,
      ]} />

    <MktSection eyebrow="Six platform pillars" title="What every WPistic workspace gets">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {[
          { id: 'platform-licenses',    icon: 'key',   title: 'License Manager', desc: 'Issue, revoke, and manage licenses across plugins, products, and customer sites.' },
          { id: 'platform-agents',      icon: 'bot',   title: 'AI Agents',       desc: 'Drop-in AI agents for sales, support, SEO, and bookings — trained on your data.' },
          { id: 'platform-automations', icon: 'zap',   title: 'Automations',     desc: 'Visual when-this-then-that workflows across every plugin and channel.' },
          { id: 'platform-inbox',       icon: 'inbox', title: 'Inbox',           desc: 'WhatsApp, web chat, email, and tickets — unified in one screen.' },
          { id: 'platform-analytics',   icon: 'chart', title: 'Analytics',       desc: 'Traffic, revenue, search, AI conversations, and automation runs — all on one canvas.' },
          { id: 'platform-developers',  icon: 'code',  title: 'Developers',      desc: 'REST API, webhooks, OAuth apps, event log, SDKs (coming soon).' },
        ].map(f => (
          <Card key={f.title} padding={28} hoverable style={{ cursor: 'pointer' }}>
            <div onClick={() => onNav(f.id)}>
              <div style={{ width: 50, height: 50, borderRadius: 14, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center', marginBottom: 18 }}>
                <Icon name={f.icon} size={24} />
              </div>
              <div style={{ fontSize: 19, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>{f.title}</div>
              <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: '8px 0 18px' }}>{f.desc}</p>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#6C5CE7', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                Explore <Icon name="arrow" size={12} />
              </div>
            </div>
          </Card>
        ))}
      </div>
    </MktSection>

    <MktSection bg="#0D0F1A" eyebrow="App preview" title="Built into the WPistic dashboard.">
      <div style={{
        background: 'linear-gradient(165deg, #13161F, #0D0F1A)',
        borderRadius: 24, border: '1px solid #1E2130',
        padding: 32, boxShadow: '0 24px 80px rgba(0,0,0,0.5)',
      }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
          {[
            { l: 'Active workspaces', v: '2,847' },
            { l: 'Plugins managed',   v: '14,219' },
            { l: 'Automations / day', v: '184k' },
            { l: 'AI conversations',  v: '2.1M' },
          ].map(s => (
            <div key={s.l} style={{
              padding: 22, background: '#0D0F1A', borderRadius: 16,
              border: '1px solid #1E2130',
            }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#9499BA', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{s.l}</div>
              <div style={{ fontSize: 32, fontWeight: 800, color: '#fff', letterSpacing: '-0.025em', marginTop: 8 }}>{s.v}</div>
              <div style={{ fontSize: 11.5, color: '#4ED48A', fontWeight: 700, marginTop: 4 }}>↑ This month</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ textAlign: 'center', marginTop: 28 }}>
        <Btn variant="primary" size="lg" onClick={() => onNav('register')} rightIcon="arrow">Open the platform</Btn>
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="Platform-grade infrastructure for your WordPress business."
      sub="Built once, shared by every plugin. Designed to scale from one site to fifty." />
  </MarketingPage>
);

// ═════════════════════════════════════════════════════════════
// PRICING
// ═════════════════════════════════════════════════════════════
const MKT_PRICING_PLANS = [
  { name: 'Free', price: { mo: 0, yr: 0 }, cta: 'Start free', tag: 'For exploring',
    features: ['1 connected site', '2 products', '100 AI conversations / mo', '1 team seat', 'Community support', 'Basic automations'] },
  { name: 'Starter', price: { mo: 19, yr: 15 }, cta: 'Start trial', tag: 'For solo creators',
    features: ['3 connected sites', '5 products', '1,000 AI conversations / mo', '2 team seats', 'Email support', 'All automation triggers'] },
  { name: 'Business', price: { mo: 49, yr: 39 }, cta: 'Start trial', tag: 'Most popular', popular: true,
    features: ['15 connected sites', 'All 11 products', '50,000 AI conversations / mo', '5 team seats', 'Priority live chat', 'Full REST API', 'Custom AI agents'] },
  { name: 'Agency', price: { mo: 129, yr: 99 }, cta: 'Start trial', tag: 'For agencies & multi-site',
    features: ['Unlimited sites', 'All products + early access', '250,000 AI conversations / mo', '15 team seats', 'Dedicated CSM', 'White-label dashboard', 'Custom integrations'] },
  { name: 'Enterprise', price: { mo: null, yr: null }, cta: 'Contact sales', tag: 'Custom',
    features: ['Unlimited everything', 'Custom AI tenant + SLA', 'SSO / SAML / SOC 2', 'Custom data residency', 'Dedicated infra', 'Solution engineer'] },
];

const COMPARE_GROUPS = [
  { name: 'Workspace', rows: [
    { label: 'Connected sites', vals: ['1','3','15','Unlimited','Unlimited'] },
    { label: 'Team seats', vals: ['1','2','5','15','Unlimited'] },
    { label: 'Products included', vals: ['2','5','All 11','All 11 + beta','All + custom'] },
  ]},
  { name: 'AI & automation', rows: [
    { label: 'AI conversations / mo', vals: ['100','1,000','50,000','250,000','Custom'] },
    { label: 'Custom AI agents', vals: ['—','—','✓','✓','✓'] },
    { label: 'Automation runs / mo', vals: ['500','5,000','50,000','Unlimited','Unlimited'] },
    { label: 'Channels (WhatsApp, web, email)', vals: ['1','2','All','All','All'] },
  ]},
  { name: 'Developer & data', rows: [
    { label: 'REST API access', vals: ['Read','Read','Full','Full + SLA','Custom'] },
    { label: 'Webhooks', vals: ['—','5','Unlimited','Unlimited','Unlimited'] },
    { label: 'Data export', vals: ['CSV','CSV','CSV + API','CSV + API','Custom'] },
    { label: 'SSO / SAML', vals: ['—','—','—','—','✓'] },
  ]},
  { name: 'Support', rows: [
    { label: 'Support level', vals: ['Community','Email','Priority chat','Dedicated CSM','24/7 + Engineer'] },
    { label: 'SLA', vals: ['—','—','—','99.9%','99.99%'] },
    { label: 'Onboarding', vals: ['Docs','Docs','Webinar','1:1 onboarding','Custom'] },
  ]},
];

const PricingPage = ({ onNav }) => {
  const [cad, setCad] = React.useState('yr');
  return (
    <MarketingPage onNav={onNav}>
      <section style={{
        position: 'relative', overflow: 'hidden',
        background: 'linear-gradient(155deg, #F3F1FE 0%, #EEF0FF 60%, #E8FAF0 130%)',
        padding: '70px 36px 40px',
      }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', textAlign: 'center', position: 'relative' }}>
          <Badge tone="purple" dot>Pricing</Badge>
          <h1 style={{
            fontSize: 54, fontWeight: 800, letterSpacing: '-0.035em',
            color: '#0D0F1A', lineHeight: 1.08, margin: '18px 0 0',
          }}>
            Simple, scalable pricing.{' '}
            <span style={{
              background: '#00C04B',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>11 products. 1 subscription.</span>
          </h1>
          <p style={{ fontSize: 17, color: '#4B5263', lineHeight: 1.6, maxWidth: 640, margin: '20px auto 30px' }}>
            Start free. Add sites and seats as your business grows. Cancel anytime.
          </p>

          {/* Toggle */}
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12, background: '#fff', padding: 6, borderRadius: 9999, border: '1px solid #EDEFF8', boxShadow: '0 4px 16px rgba(108,92,231,0.06)' }}>
            <button onClick={() => setCad('mo')} style={{
              fontFamily: 'inherit', fontSize: 13.5, fontWeight: 700,
              padding: '8px 22px', borderRadius: 9999, border: 'none', cursor: 'pointer',
              background: cad === 'mo' ? '#0D0F1A' : 'transparent',
              color: cad === 'mo' ? '#fff' : '#6B7280',
            }}>Monthly</button>
            <button onClick={() => setCad('yr')} style={{
              fontFamily: 'inherit', fontSize: 13.5, fontWeight: 700,
              padding: '8px 22px', borderRadius: 9999, border: 'none', cursor: 'pointer',
              background: cad === 'yr' ? '#0D0F1A' : 'transparent',
              color: cad === 'yr' ? '#fff' : '#6B7280',
              display: 'inline-flex', alignItems: 'center', gap: 6,
            }}>Annual <Badge tone="green">Save 20%</Badge></button>
          </div>
        </div>
      </section>

      {/* Plan cards */}
      <section style={{ padding: '24px 36px 40px', background: 'linear-gradient(180deg, #EEF0FF 0%, #fff 50%)' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
          {MKT_PRICING_PLANS.map(p => <PricingCard key={p.name} plan={p} cad={cad} onNav={onNav} />)}
        </div>
      </section>

      {/* Compare table */}
      <MktSection eyebrow="Detailed feature comparison" title="Every plan, side by side.">
        <Card padding={0} style={{ overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table className="wpt" style={{ width: '100%' }}>
              <thead>
                <tr>
                  <th style={{ paddingLeft: 24, minWidth: 200 }}></th>
                  {MKT_PRICING_PLANS.map(p => (
                    <th key={p.name} style={{
                      textAlign: 'center', minWidth: 140,
                      background: p.popular ? '#F3F1FE' : '#F8F9FF',
                      color: p.popular ? '#5649CC' : '#0D0F1A',
                      paddingTop: 18, paddingBottom: 14,
                    }}>
                      <div style={{ fontSize: 14, fontWeight: 800, letterSpacing: '-0.01em', color: '#0D0F1A' }}>{p.name}</div>
                      {p.popular && <Badge tone="purple" style={{ marginTop: 6 }}>Recommended</Badge>}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {COMPARE_GROUPS.map(g => (
                  <React.Fragment key={g.name}>
                    <tr>
                      <td colSpan={6} style={{
                        padding: '14px 24px', background: '#fff',
                        fontSize: 11, fontWeight: 700, color: '#6C5CE7',
                        letterSpacing: '0.1em', textTransform: 'uppercase',
                        borderTop: '1px solid #F0F2FF',
                      }}>{g.name}</td>
                    </tr>
                    {g.rows.map(r => (
                      <tr key={r.label}>
                        <td style={{ paddingLeft: 24, fontSize: 13.5, color: '#4B5263', fontWeight: 500 }}>{r.label}</td>
                        {r.vals.map((v, i) => (
                          <td key={i} style={{
                            textAlign: 'center', fontSize: 13, fontWeight: 600,
                            color: v === '—' ? '#9499BA' : v === '✓' ? '#00C04B' : '#0D0F1A',
                            background: MKT_PRICING_PLANS[i].popular ? '#F8FBFF' : 'transparent',
                          }}>{v}</td>
                        ))}
                      </tr>
                    ))}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </MktSection>

      {/* FAQ */}
      <MktSection bg="#F8F9FF" narrow eyebrow="FAQ" title="Pricing questions, answered.">
        <FAQList items={[
          { q: 'Can I switch plans anytime?', a: 'Yes. Upgrades are pro-rated to the day. Downgrades take effect at the next billing period.' },
          { q: 'Do you offer a free trial?', a: 'The Starter, Business, and Agency plans all start with a 14-day free trial — no credit card required.' },
          { q: 'What counts as an AI conversation?', a: 'A back-and-forth exchange (up to 20 messages) with a customer through Chatbotistic or a WPAgentistic agent. Internal team messages don\'t count.' },
          { q: 'Can I bring my own AI API key?', a: 'On Business and above. Bring your own OpenAI or Anthropic key and pay only for our orchestration layer.' },
          { q: 'What if I need more than the Agency plan?', a: 'Contact sales — Enterprise plans include custom AI tenants, SSO, SOC 2, and dedicated infra.' },
          { q: 'Do you offer non-profit or education pricing?', a: 'Yes — 50% off on Business and Agency plans. Email hello@wpistic.com from your org domain.' },
        ]} />
      </MktSection>

      <MktFinalCTA onNav={onNav}
        title="Start free. Upgrade when it pays for itself."
        sub="Every paid plan ships with a 14-day trial. No credit card. Cancel any time." />
    </MarketingPage>
  );
};

const PricingCard = ({ plan: p, cad, onNav }) => {
  const price = p.price[cad];
  return (
    <div style={{
      padding: 24, background: p.popular ? '#0D0F1A' : '#fff',
      color: p.popular ? '#fff' : '#0D0F1A',
      borderRadius: 22, border: p.popular ? '1px solid #1E2130' : '1px solid #EDEFF8',
      boxShadow: p.popular ? '0 24px 60px rgba(108,92,231,0.28)' : '0 2px 12px rgba(108,92,231,0.05)',
      position: 'relative', transform: p.popular ? 'translateY(-12px)' : 'none',
    }}>
      {p.popular && (
        <div style={{
          position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)',
          background: '#00C04B', color: '#fff',
          fontSize: 11, fontWeight: 800, padding: '4px 14px', borderRadius: 9999,
          letterSpacing: '0.05em',
        }}>MOST POPULAR</div>
      )}
      <div style={{
        fontSize: 11, fontWeight: 700, color: p.popular ? '#6C5CE7' : '#9499BA',
        letterSpacing: '0.08em', textTransform: 'uppercase',
      }}>{p.tag}</div>
      <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.02em', marginTop: 6 }}>{p.name}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 14, minHeight: 50 }}>
        {price === null
          ? <span style={{ fontSize: 26, fontWeight: 800 }}>Custom</span>
          : <>
              <span style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-0.03em' }}>${price}</span>
              <span style={{ fontSize: 13, color: p.popular ? '#9499BA' : '#9499BA' }}>/ mo</span>
            </>}
      </div>
      {cad === 'yr' && price !== null && price > 0 && (
        <div style={{ fontSize: 11, color: p.popular ? '#4ED48A' : '#00C04B', fontWeight: 700, marginTop: 2 }}>
          Billed annually
        </div>
      )}
      <Btn variant={p.popular ? 'green' : price === null ? 'border-card' : 'primary'} size="md"
        style={{ width: '100%', justifyContent: 'center', marginTop: 18 }}
        onClick={() => onNav(p.name === 'Enterprise' ? 'contact' : 'register')}>{p.cta}</Btn>
      <div style={{ marginTop: 20, paddingTop: 18, borderTop: p.popular ? '1px solid #1E2130' : '1px solid #F0F2FF' }}>
        {p.features.map(f => (
          <div key={f} style={{
            display: 'flex', alignItems: 'flex-start', gap: 8, fontSize: 12.5,
            marginBottom: 9, color: p.popular ? '#D4D6E0' : '#2E3245',
          }}>
            <Icon name="check" size={13} color={p.popular ? '#4ED48A' : '#00C04B'} strokeWidth={2.5} style={{ marginTop: 2, flexShrink: 0 }} />
            {f}
          </div>
        ))}
      </div>
    </div>
  );
};

const FAQList = ({ items }) => {
  const [open, setOpen] = React.useState(0);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {items.map((it, i) => (
        <Card key={i} padding={0}>
          <button onClick={() => setOpen(open === i ? -1 : i)} style={{
            display: 'flex', alignItems: 'center', width: '100%',
            padding: '20px 24px', background: 'transparent', border: 'none',
            cursor: 'pointer', fontFamily: 'inherit', textAlign: 'left',
          }}>
            <span style={{ flex: 1, fontSize: 15.5, fontWeight: 700, color: '#0D0F1A' }}>{it.q}</span>
            <Icon name="plus" size={18} color="#6C5CE7" style={{ transform: open === i ? 'rotate(45deg)' : 'none', transition: 'transform 0.2s' }} />
          </button>
          {open === i && (
            <div style={{ padding: '0 24px 22px', fontSize: 14, color: '#4B5263', lineHeight: 1.7 }}>
              {it.a}
            </div>
          )}
        </Card>
      ))}
    </div>
  );
};

// ═════════════════════════════════════════════════════════════
// CONTACT
// ═════════════════════════════════════════════════════════════
const ContactPage = ({ onNav }) => {
  const [topic, setTopic] = React.useState('sales');
  return (
    <MarketingPage onNav={onNav}>
      <section style={{
        background: 'linear-gradient(155deg, #F3F1FE 0%, #EEF0FF 60%, #E8FAF0 130%)',
        padding: '56px 36px 32px',
      }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', textAlign: 'center' }}>
          <Badge tone="purple" dot>We're here to help</Badge>
          <h1 style={{ fontSize: 52, fontWeight: 800, letterSpacing: '-0.035em', color: '#0D0F1A', lineHeight: 1.1, margin: '18px 0 14px' }}>
            Talk to a real human at WPistic.
          </h1>
          <p style={{ fontSize: 17, color: '#4B5263', maxWidth: 600, margin: '0 auto', lineHeight: 1.6 }}>
            Sales, support, partnerships, or a demo — pick the right inbox and we'll get back within one business day.
          </p>
        </div>
      </section>

      <section style={{ padding: '40px 36px 80px', background: '#fff' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: 32 }}>
          {/* Topic cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[
              { id: 'sales',      icon: 'spark', title: 'Sales',         desc: 'Custom pricing, demos, and Enterprise plans.', sla: 'Reply in 4 hours' },
              { id: 'support',    icon: 'help',  title: 'Support',       desc: 'Help with installs, licenses, or bug reports.', sla: 'Reply in 38 min' },
              { id: 'partner',    icon: 'users', title: 'Partnerships',  desc: 'Integrations, co-marketing, and reseller programs.', sla: 'Reply in 1 day' },
              { id: 'demo',       icon: 'globe', title: 'Book a demo',   desc: '30-min walkthrough with a solutions engineer.', sla: 'Schedule directly' },
            ].map(t => {
              const active = topic === t.id;
              return (
                <Card key={t.id} padding={20} hoverable style={{
                  border: active ? '2px solid #6C5CE7' : '1px solid #EDEFF8',
                  background: active ? '#F3F1FE' : '#fff', cursor: 'pointer',
                }}>
                  <div onClick={() => setTopic(t.id)} style={{ display: 'flex', gap: 14 }}>
                    <div style={{ width: 42, height: 42, borderRadius: 12, background: active ? '#fff' : '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                      <Icon name={t.icon} size={20} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>{t.title}</div>
                      <div style={{ fontSize: 12.5, color: '#4B5263', marginTop: 3, lineHeight: 1.5 }}>{t.desc}</div>
                      <div style={{ fontSize: 11, color: '#00C04B', fontWeight: 700, marginTop: 6, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{t.sla}</div>
                    </div>
                  </div>
                </Card>
              );
            })}

            <Card padding={22} dark style={{ marginTop: 12 }}>
              <SectionLabel light color="#6C5CE7">Need it right now?</SectionLabel>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#fff', marginBottom: 10 }}>Live chat with engineering</div>
              <p style={{ fontSize: 12.5, color: '#9499BA', lineHeight: 1.6, margin: '0 0 14px' }}>Business and Agency plans include real-time chat with the team that builds WPistic. Typical reply under 4 minutes.</p>
              <Btn variant="green" size="sm" rightIcon="arrow" style={{ width: '100%', justifyContent: 'center' }}>Open chat</Btn>
            </Card>
          </div>

          {/* Form */}
          <Card padding={36}>
            <div style={{ fontSize: 20, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em', marginBottom: 6 }}>
              {topic === 'sales' ? 'Talk to sales'
                : topic === 'support' ? 'Open a support request'
                : topic === 'partner' ? 'Partnership inquiry'
                : 'Book a demo'}
            </div>
            <p style={{ fontSize: 13.5, color: '#6B7280', margin: '0 0 24px' }}>
              {topic === 'sales' ? 'Tell us about your business and we\'ll get you a custom quote.'
                : topic === 'support' ? 'Describe the issue and we\'ll route you to the right engineer.'
                : topic === 'partner' ? 'Tell us about your integration or partnership idea.'
                : 'Pick a time and we\'ll send the meeting link.'}
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <AuthInput label="Full name" placeholder="Jane Doe" />
              <AuthInput label="Work email" type="email" placeholder="jane@company.com" />
            </div>
            <AuthInput label="Company" placeholder="Aurora Studio" />
            <AuthInput label="Website URL" placeholder="https://aurora.co" />
            {topic === 'sales' && <AuthInput label="Team size" placeholder="1–10 people" />}
            <label style={{ display: 'block', marginBottom: 16 }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: '#0D0F1A', marginBottom: 6 }}>How can we help?</div>
              <textarea rows="5" placeholder={topic === 'demo' ? 'What\'s most important to see in the demo?' : 'Tell us what you\'re trying to do.'} style={{
                width: '100%', padding: '12px 16px',
                borderRadius: 12, border: '1.5px solid #E8EAFF',
                fontSize: 14, color: '#0D0F1A', fontFamily: 'inherit',
                outline: 'none', resize: 'vertical', lineHeight: 1.5,
              }} />
            </label>
            <Btn variant="primary" size="lg" rightIcon="arrow" style={{ width: '100%', justifyContent: 'center' }}>
              Send message
            </Btn>
          </Card>
        </div>
      </section>

      {/* Offices + quick links */}
      <MktSection bg="#F8F9FF" eyebrow="Offices" title="Where to find us">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
          {[
            { city: 'New York',  role: 'HQ · Sales & Support',  addr: '447 Broadway, 2nd Floor', tz: 'EST · UTC−05:00' },
            { city: 'Berlin',    role: 'Engineering',            addr: 'Mitte, Berlin 10117',     tz: 'CET · UTC+01:00' },
            { city: 'Dhaka',     role: 'Product & Operations',   addr: 'Gulshan-2, Dhaka 1212',   tz: 'BST · UTC+06:00' },
            { city: 'Remote',    role: '14 countries',           addr: 'wpistic.com/careers',    tz: 'Worldwide' },
          ].map(o => (
            <Card key={o.city} padding={22} hoverable>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#6C5CE7', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{o.role}</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em', marginTop: 6 }}>{o.city}</div>
              <div style={{ fontSize: 13, color: '#4B5263', marginTop: 8, lineHeight: 1.6 }}>{o.addr}</div>
              <div style={{ fontSize: 11.5, color: '#9499BA', marginTop: 6, fontWeight: 600 }}>{o.tz}</div>
            </Card>
          ))}
        </div>
      </MktSection>
    </MarketingPage>
  );
};

Object.assign(window, {
  ProductsOverviewPage, EcosystemOverviewPage, PlatformOverviewPage,
  PricingPage, ContactPage, PricingCard, FAQList,
});
