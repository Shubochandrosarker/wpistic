// billing.jsx — Plan, usage, invoices, payment method, add-ons

const BillingPage = () => {
  const [tab, setTab] = React.useState('Plan');
  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      <PageHeader
        eyebrow="Billing & Plans"
        title="Billing"
        subtitle="Plan, payment method, invoices, and add-ons for Shuvo's Workspace."
        actions={
          <>
            <Btn variant="border-card" size="md" leftIcon="download">Download invoices</Btn>
            <Btn variant="primary" size="md" leftIcon="spark">Upgrade plan</Btn>
          </>
        } />

      {/* Plan card */}
      <Card padding={0} style={{ marginBottom: 22, overflow: 'hidden' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', alignItems: 'stretch' }}>
          <div style={{
            background: 'linear-gradient(145deg, #1A1659, #0D0F1A)',
            color: '#fff', padding: 28, position: 'relative', overflow: 'hidden',
          }}>
            <div style={{
              position: 'absolute', inset: 0,
              background: 'radial-gradient(ellipse 280px 240px at 80% 80%, rgba(108,92,231,0.40), transparent 70%)',
            }} />
            <div style={{ position: 'relative' }}>
              <Badge tone="green" dot>Active</Badge>
              <div style={{ fontSize: 30, fontWeight: 800, marginTop: 14, letterSpacing: '-0.025em' }}>
                Business plan
              </div>
              <p style={{ fontSize: 13.5, color: '#9499BA', lineHeight: 1.6, margin: '6px 0 20px', maxWidth: 320 }}>
                15 sites · 5 team seats · all products · 50,000 AI conversations / mo.
              </p>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                <span style={{ fontSize: 42, fontWeight: 800, letterSpacing: '-0.03em' }}>$129</span>
                <span style={{ fontSize: 14, color: '#9499BA' }}>/ month · billed annually</span>
              </div>
              <div style={{ fontSize: 12, color: '#4ED48A', fontWeight: 700, marginTop: 8 }}>
                Saving $310 / year vs monthly
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 22 }}>
                <Btn variant="white" size="sm" rightIcon="arrow">Compare plans</Btn>
                <Btn variant="dark-outline" size="sm">Switch to monthly</Btn>
              </div>
              <div style={{
                marginTop: 22, paddingTop: 18,
                borderTop: '1px solid rgba(255,255,255,0.10)',
                fontSize: 12, color: '#9499BA',
              }}>
                Renews <strong style={{ color: '#fff' }}>March 18, 2027</strong> · auto-renew on
              </div>
            </div>
          </div>

          <div style={{ padding: '24px 28px' }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A', marginBottom: 16 }}>This billing period</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 22 }}>
              <UsageMeter label="AI conversations" value={37428} cap={50000} unit="conv." color="#6C5CE7" />
              <UsageMeter label="Automation runs" value={2847} cap={10000} unit="runs" color="#00C04B" />
              <UsageMeter label="Connected sites" value={5} cap={15} unit="sites" color="#5649CC" />
              <UsageMeter label="Team seats" value={3} cap={5} unit="seats" color="#F59E0B" />
              <UsageMeter label="Storage (assets)" value={2.1} cap={20} unit="GB" color="#00C04B" />
              <UsageMeter label="API requests" value={184000} cap={500000} unit="req" color="#6C5CE7" />
            </div>
            <div style={{
              marginTop: 22, padding: '12px 16px',
              background: '#F8F9FF', border: '1px solid #E9E6FD',
              borderRadius: 12, display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <Icon name="spark" size={16} color="#6C5CE7" />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>You're using 75% of AI conversations</div>
                <div style={{ fontSize: 12, color: '#6B7280' }}>Resets in 9 days · upgrade to Agency for unlimited.</div>
              </div>
              <Btn variant="primary" size="xs">Add credits</Btn>
            </div>
          </div>
        </div>
      </Card>

      {/* Sub tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, borderBottom: '1px solid #EDEFF8' }}>
        {['Plan', 'Invoices', 'Payment methods', 'Add-ons'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            fontFamily: 'inherit', fontSize: 13.5, fontWeight: 600,
            padding: '10px 14px', background: 'transparent', border: 'none',
            color: tab===t ? '#0D0F1A' : '#6B7280', cursor: 'pointer',
            borderBottom: tab===t ? '2px solid #6C5CE7' : '2px solid transparent',
            marginBottom: -1,
          }}>{t}</button>
        ))}
      </div>

      {tab === 'Plan' && <PlanCompare />}
      {tab === 'Invoices' && <InvoiceTable />}
      {tab === 'Payment methods' && <PaymentMethods />}
      {tab === 'Add-ons' && <AddonsGrid />}
    </div>
  );
};

const UsageMeter = ({ label, value, cap, unit, color }) => {
  const pct = (value / cap) * 100;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#6B7280', marginBottom: 6 }}>
        <span style={{ fontWeight: 700, color: '#0D0F1A' }}>{label}</span>
        <span><strong style={{ color: '#0D0F1A' }}>{fmt(value)}</strong> / {fmt(cap)} {unit}</span>
      </div>
      <div style={{ height: 8, background: '#F0F2FF', borderRadius: 9999, overflow: 'hidden' }}>
        <div style={{
          width: pct + '%', height: '100%',
          background: pct > 85 ? '#EF4444' : pct > 70 ? '#F59E0B' : color,
          borderRadius: 9999, transition: 'width 0.3s',
        }} />
      </div>
    </div>
  );
};

const PLANS_FULL = [
  { name: 'Free', price: '$0', cadence: '/mo',
    cta: 'Downgrade', current: false,
    features: { 'Sites': '1', 'Products': '2', 'AI conversations / mo': '100', 'Team seats': '1',
      'Support': 'Community', 'API access': '—', 'White-label': '—' } },
  { name: 'Starter', price: '$19',
    cta: 'Downgrade', current: false,
    features: { 'Sites': '3', 'Products': '5', 'AI conversations / mo': '1,000', 'Team seats': '2',
      'Support': 'Email', 'API access': 'Basic', 'White-label': '—' } },
  { name: 'Pro', price: '$49',
    cta: 'Downgrade', current: false, recommend: false,
    features: { 'Sites': '5', 'Products': 'All', 'AI conversations / mo': '10,000', 'Team seats': '3',
      'Support': 'Priority', 'API access': 'Full', 'White-label': '—' } },
  { name: 'Business', price: '$129',
    cta: 'Current plan', current: true,
    features: { 'Sites': '15', 'Products': 'All', 'AI conversations / mo': '50,000', 'Team seats': '5',
      'Support': 'Live chat', 'API access': 'Full', 'White-label': '—' } },
  { name: 'Agency', price: '$299',
    cta: 'Upgrade', current: false, recommend: true,
    features: { 'Sites': 'Unlimited', 'Products': 'All', 'AI conversations / mo': '250,000', 'Team seats': '15',
      'Support': 'Dedicated CSM', 'API access': 'Full + SLA', 'White-label': 'Yes' } },
];

const PlanCompare = () => {
  const allFeatures = Object.keys(PLANS_FULL[0].features);
  return (
    <Card padding={0}>
      <div style={{ overflowX: 'auto' }}>
        <table className="wpt">
          <thead>
            <tr>
              <th style={{ paddingLeft: 22, minWidth: 180 }}>Feature</th>
              {PLANS_FULL.map(p => (
                <th key={p.name} style={{
                  textAlign: 'center', minWidth: 160,
                  background: p.recommend ? '#F3F1FE' : p.current ? '#E8FAF0' : '#F8F9FF',
                  color: p.recommend ? '#5649CC' : p.current ? '#007C2F' : '#6B7280',
                }}>
                  {p.name}
                  {p.recommend && <Badge tone="purple" style={{ marginLeft: 6 }}>Recommended</Badge>}
                  {p.current && <Badge tone="green" style={{ marginLeft: 6 }}>Current</Badge>}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={{ paddingLeft: 22, fontWeight: 700, color: '#0D0F1A' }}>Price</td>
              {PLANS_FULL.map(p => (
                <td key={p.name} style={{
                  textAlign: 'center', fontWeight: 800, fontSize: 18, color: '#0D0F1A',
                  background: p.current ? '#F8FFF9' : 'transparent',
                }}>{p.price}<span style={{ fontSize: 11, color: '#9499BA', fontWeight: 600 }}>/mo</span></td>
              ))}
            </tr>
            {allFeatures.map(f => (
              <tr key={f}>
                <td style={{ paddingLeft: 22, color: '#4B5263', fontWeight: 500 }}>{f}</td>
                {PLANS_FULL.map(p => (
                  <td key={p.name} style={{
                    textAlign: 'center', fontWeight: 600, color: p.features[f] === '—' ? '#9499BA' : '#0D0F1A',
                    background: p.current ? '#F8FFF9' : 'transparent',
                  }}>{p.features[f]}</td>
                ))}
              </tr>
            ))}
            <tr>
              <td style={{ paddingLeft: 22 }}></td>
              {PLANS_FULL.map(p => (
                <td key={p.name} style={{
                  textAlign: 'center', paddingTop: 18, paddingBottom: 18,
                  background: p.current ? '#F8FFF9' : 'transparent',
                }}>
                  {p.current
                    ? <Btn variant="border-card" size="sm" style={{ width: 120, justifyContent: 'center' }}>{p.cta}</Btn>
                    : p.recommend
                      ? <Btn variant="primary" size="sm" style={{ width: 120, justifyContent: 'center' }}>{p.cta}</Btn>
                      : <Btn variant="ghost" size="sm" style={{ width: 120, justifyContent: 'center' }}>{p.cta}</Btn>}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </Card>
  );
};

const INVOICES = [
  { num: 'INV-2026-005', date: 'May 18, 2026',  plan: 'Business · Annual', amount: '$1,290.00', status: 'Paid' },
  { num: 'INV-2026-004', date: 'Apr 18, 2026',  plan: 'Add-on: +10k AI conv.', amount: '$29.00', status: 'Paid' },
  { num: 'INV-2026-003', date: 'Mar 18, 2026',  plan: 'Business · Annual renew', amount: '$1,290.00', status: 'Paid' },
  { num: 'INV-2026-002', date: 'Feb 02, 2026',  plan: 'Beta agent credits',     amount: '$49.00',  status: 'Paid' },
  { num: 'INV-2026-001', date: 'Jan 14, 2026',  plan: 'Memberistic seat',       amount: '$19.00',  status: 'Paid' },
  { num: 'INV-2025-018', date: 'Dec 18, 2025',  plan: 'Pro · Monthly',          amount: '$49.00',  status: 'Refunded' },
];

const InvoiceTable = () => (
  <Card padding={0}>
    <table className="wpt">
      <thead>
        <tr>
          <th style={{ paddingLeft: 22 }}>Invoice</th>
          <th>Date</th>
          <th>Description</th>
          <th>Amount</th>
          <th>Status</th>
          <th style={{ paddingRight: 22 }}></th>
        </tr>
      </thead>
      <tbody>
        {INVOICES.map((iv, i) => (
          <tr key={i}>
            <td style={{ paddingLeft: 22, fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#5649CC', fontWeight: 700 }}>{iv.num}</td>
            <td style={{ fontSize: 13, color: '#4B5263' }}>{iv.date}</td>
            <td style={{ fontSize: 13, color: '#0D0F1A', fontWeight: 500 }}>{iv.plan}</td>
            <td style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{iv.amount}</td>
            <td><Badge tone={iv.status==='Paid'?'green':iv.status==='Refunded'?'gray':'amber'} dot>{iv.status}</Badge></td>
            <td style={{ paddingRight: 22, textAlign: 'right' }}>
              <Btn variant="ghost" size="xs" leftIcon="download">PDF</Btn>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </Card>
);

const PaymentMethods = () => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
    <CardOnFile primary />
    <CardOnFile />
    <Card padding={28} style={{
      border: '2px dashed #D4CCFB', background: 'rgba(243,241,254,0.4)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', gap: 10,
      minHeight: 200,
    }}>
      <div style={{ width: 48, height: 48, borderRadius: 14, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center' }}>
        <Icon name="plus" size={22} />
      </div>
      <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A' }}>Add payment method</div>
      <p style={{ fontSize: 12.5, color: '#6B7280', margin: 0, lineHeight: 1.55 }}>Credit card, ACH, SEPA, or PayPal.</p>
      <Btn variant="primary" size="sm" leftIcon="plus">Add method</Btn>
    </Card>
  </div>
);

const CardOnFile = ({ primary }) => (
  <Card padding={22}>
    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 18 }}>
      <div style={{
        width: 44, height: 30, borderRadius: 6,
        background: primary ? 'linear-gradient(135deg, #1A1F71, #2E77BC)' : 'linear-gradient(135deg, #EB001B, #F79E1B)',
        color: '#fff', display: 'grid', placeItems: 'center',
        fontSize: 10, fontWeight: 800, letterSpacing: '0.1em',
      }}>{primary ? 'VISA' : 'MC'}</div>
      {primary
        ? <Badge tone="purple" dot>Primary</Badge>
        : <Badge tone="gray">Backup</Badge>}
    </div>
    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 14, color: '#0D0F1A', letterSpacing: '0.1em' }}>
      •••• •••• •••• {primary ? '4242' : '8821'}
    </div>
    <div style={{ fontSize: 12, color: '#6B7280', marginTop: 6 }}>
      Expires {primary ? '08 / 2028' : '02 / 2027'} · Shuvo Roy
    </div>
    <div style={{ display: 'flex', gap: 8, marginTop: 16, paddingTop: 14, borderTop: '1px solid #F0F2FF' }}>
      <Btn variant="ghost-gray" size="xs">Edit</Btn>
      <Btn variant="ghost-gray" size="xs">Remove</Btn>
      {!primary && <Btn variant="ghost" size="xs">Make primary</Btn>}
    </div>
  </Card>
);

const ADDONS = [
  { name: '+10,000 AI conversations',   price: '$29 / mo', desc: 'Extra capacity for Chatbotistic and WPAgentistic.', icon: 'bot', tone: 'green' },
  { name: 'Extra connected site',       price: '$9 / site', desc: 'Add another WordPress site beyond your plan limit.', icon: 'globe', tone: 'purple' },
  { name: 'Team seat',                  price: '$15 / seat', desc: 'Invite another member with roles and permissions.', icon: 'users', tone: 'purple' },
  { name: 'White-label dashboard',      price: '$79 / mo', desc: 'Your logo, colors, and domain on the client dashboard.', icon: 'shield', tone: 'green' },
  { name: 'Dedicated AI infra',         price: '$249 / mo', desc: 'Isolated AI tenant with custom rate limits and SLA.', icon: 'spark', tone: 'green' },
  { name: 'Priority support',           price: '$49 / mo', desc: '4-hour response SLA, live chat with engineers.', icon: 'help', tone: 'purple' },
];

const AddonsGrid = () => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
    {ADDONS.map((a, i) => {
      const c = a.tone === 'purple' ? { bg: '#F3F1FE', fg: '#6C5CE7' } : { bg: '#E8FAF0', fg: '#00C04B' };
      return (
        <Card key={i} hoverable padding={22}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 11,
              background: c.bg, color: c.fg,
              display: 'grid', placeItems: 'center',
            }}>
              <Icon name={a.icon} size={18} />
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>{a.price.split(' ')[0]}</div>
              <div style={{ fontSize: 11, color: '#9499BA', fontWeight: 600 }}>{a.price.split(' ').slice(1).join(' ')}</div>
            </div>
          </div>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A' }}>{a.name}</div>
          <p style={{ fontSize: 12.5, color: '#4B5263', lineHeight: 1.55, margin: '6px 0 16px', minHeight: 44 }}>{a.desc}</p>
          <Btn variant="border-card" size="sm" leftIcon="plus" style={{ width: '100%', justifyContent: 'center' }}>Add to plan</Btn>
        </Card>
      );
    })}
  </div>
);

Object.assign(window, { BillingPage });
