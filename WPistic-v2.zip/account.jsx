// account.jsx — Support, Developers, Settings (account area pages)

// ─────────────────────────────────────────────────────────────
// SUPPORT
// ─────────────────────────────────────────────────────────────
const TICKETS = [
  { id: 1182, subj: 'Calendar sync stopped at 3pm CET', product: 'bookingistic', priority: 'High',  status: 'Open',
    last: 'Sarah · 28 min ago', site: 'wanderly.travel', age: '3h' },
  { id: 1176, subj: 'WhatsApp media webhook failing intermittently', product: 'chatbotistic', priority: 'High', status: 'Awaiting reply',
    last: 'You · 1 day ago', site: 'shopglow.com', age: '2d' },
  { id: 1164, subj: 'Member churn report not loading', product: 'memberistic', priority: 'Medium', status: 'In progress',
    last: 'Marcus · yesterday', site: 'theclub.co', age: '3d' },
  { id: 1158, subj: 'Insightistic widget overlapping footer on iPad', product: 'insightistic', priority: 'Low', status: 'In progress',
    last: 'You · 2 days ago', site: 'shopglow.com', age: '4d' },
  { id: 1132, subj: 'Feature request: bulk export segments', product: 'crmistic', priority: 'Low', status: 'Resolved',
    last: 'Resolved · 5 days ago', site: 'shopglow.com', age: '7d' },
];

const PRIORITY_TONE = { High: 'red', Medium: 'amber', Low: 'gray' };
const STATUS_TONE_T = { Open: 'purple', 'Awaiting reply': 'amber', 'In progress': 'purple', Resolved: 'green' };

const SupportPage = () => (
  <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
    <PageHeader
      eyebrow="Support center"
      title="Support"
      subtitle="Tickets, knowledge base, video tutorials, and engineer-on-call."
      actions={
        <>
          <Btn variant="border-card" size="md" leftIcon="external">Status page</Btn>
          <Btn variant="primary" size="md" leftIcon="plus">New ticket</Btn>
        </>
      } />

    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 22 }}>
      <MiniStat label="Open tickets" value="2" icon="help" iconBg="#F3F1FE" iconColor="#6C5CE7" />
      <MiniStat label="Avg response" value="38 min" icon="zap" iconBg="#E8FAF0" iconColor="#00C04B" sub="SLA target: 4h" />
      <MiniStat label="Resolved (mo)" value="14" icon="check" iconBg="#E8FAF0" iconColor="#00C04B" />
      <MiniStat label="CSAT" value="4.9 / 5" icon="spark" iconBg="#F3F1FE" iconColor="#6C5CE7" sub="based on 87 ratings" />
    </div>

    <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 18 }}>
      <Card padding={0}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid #F0F2FF', display: 'flex', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>Your tickets</div>
          <TextInput placeholder="Search tickets…" icon="search" size="sm" style={{ width: 220 }} />
        </div>
        {TICKETS.map(t => {
          const p = PRODUCTS.find(p => p.id === t.product);
          return (
            <div key={t.id} style={{
              padding: '16px 20px', borderBottom: '1px solid #F0F2FF',
              display: 'flex', alignItems: 'center', gap: 14,
              cursor: 'pointer', transition: 'background 0.12s',
            }}
              onMouseEnter={e => e.currentTarget.style.background = '#F8F9FF'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
              <code style={{
                fontFamily: 'JetBrains Mono, monospace', fontSize: 11.5,
                color: '#5649CC', fontWeight: 700, background: '#F3F1FE',
                padding: '3px 8px', borderRadius: 6, flexShrink: 0,
              }}>#{t.id}</code>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A', marginBottom: 4 }}>{t.subj}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11.5, color: '#6B7280' }}>
                  <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                    <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={14} radius={4} />
                    {p.name}
                  </div>
                  <span>·</span><span>{t.site}</span>
                  <span>·</span><span>{t.last}</span>
                </div>
              </div>
              <Badge tone={PRIORITY_TONE[t.priority]} dot>{t.priority}</Badge>
              <Badge tone={STATUS_TONE_T[t.status]}>{t.status}</Badge>
              <Icon name="arrow" size={14} color="#9499BA" />
            </div>
          );
        })}
      </Card>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Quick contact */}
        <Card padding={22} style={{
          background: 'linear-gradient(150deg, #1A1659, #0D0F1A)',
          color: '#fff', border: 'none', position: 'relative', overflow: 'hidden',
        }}>
          <div style={{
            position: 'absolute', top: -50, right: -50, width: 200, height: 200,
            background: 'radial-gradient(circle, rgba(0,192,75,0.25), transparent 65%)',
          }} />
          <div style={{ position: 'relative' }}>
            <Badge tone="green" dot>Live chat open</Badge>
            <div style={{ fontSize: 18, fontWeight: 700, marginTop: 12, letterSpacing: '-0.01em' }}>
              Talk to an engineer
            </div>
            <p style={{ fontSize: 13, color: '#9499BA', lineHeight: 1.6, margin: '8px 0 16px' }}>
              Business plan includes priority live chat with the WPistic engineering team — typical response in under 4 minutes.
            </p>
            <Btn variant="green" size="sm" rightIcon="arrow" style={{ width: '100%', justifyContent: 'center' }}>Start chat</Btn>
          </div>
        </Card>

        {/* KB */}
        <Card padding={22}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A' }}>Knowledge base</div>
            <Btn variant="ghost-gray" size="xs">All articles</Btn>
          </div>
          <TextInput placeholder="Search 240+ articles…" icon="search" size="sm" style={{ marginBottom: 14 }} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { i: 'globe', t: 'Connecting a WordPress site to WPistic', tone: 'purple' },
              { i: 'key',   t: 'License activation and domain enforcement', tone: 'green' },
              { i: 'bot',   t: 'Setting up your first AI agent', tone: 'purple' },
              { i: 'zap',   t: 'Building cart-recovery automations', tone: 'green' },
              { i: 'card',  t: 'Switching plans and proration', tone: 'purple' },
            ].map((kb, i) => {
              const c = kb.tone === 'purple' ? { bg: '#F3F1FE', fg: '#6C5CE7' } : { bg: '#E8FAF0', fg: '#00C04B' };
              return (
                <a key={i} href="#" onClick={e => e.preventDefault()} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '10px 12px', borderRadius: 10,
                  background: '#F8F9FF', textDecoration: 'none', color: '#0D0F1A',
                  fontSize: 13, fontWeight: 600,
                }}>
                  <div style={{ width: 28, height: 28, borderRadius: 8, background: c.bg, color: c.fg, display: 'grid', placeItems: 'center' }}>
                    <Icon name={kb.i} size={14} />
                  </div>
                  <span style={{ flex: 1 }}>{kb.t}</span>
                  <Icon name="arrow" size={12} color="#9499BA" />
                </a>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  </div>
);

// ─────────────────────────────────────────────────────────────
// DEVELOPERS
// ─────────────────────────────────────────────────────────────
const API_KEYS = [
  { name: 'Production', key: 'wpst_live_8H2K_pQ9rT4mV2nL', created: 'Mar 12, 2026', last: '2 min ago', perm: 'Read/Write' },
  { name: 'Staging',    key: 'wpst_test_4F2J_kK8vR1pX9nQ', created: 'Apr 02, 2026', last: '1 hr ago', perm: 'Read/Write' },
  { name: 'CI bot',     key: 'wpst_ci_9P4M_xT2qY8wK3sB',   created: 'Apr 22, 2026', last: 'Yesterday', perm: 'Read only' },
];

const WEBHOOKS = [
  { url: 'https://api.shopglow.com/wpistic/hook', events: ['license.activated','site.connected','order.created'], status: 'Active', last: '11 min ago', delivered: 1842 },
  { url: 'https://relay.agencytools.io/in',       events: ['booking.created','automation.completed'],            status: 'Active', last: '34 min ago', delivered: 287 },
  { url: 'https://logs.theclub.co/webhook',       events: ['license.activated'],                                  status: 'Failing', last: '2 hr ago', delivered: 12 },
];

const DevelopersPage = () => {
  const [tab, setTab] = React.useState('API keys');
  const tabs = ['API keys', 'Webhooks', 'OAuth apps', 'Event log', 'REST API'];

  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      <PageHeader
        eyebrow="Developers"
        title="API & Developers"
        subtitle="Keys, webhooks, OAuth apps, REST API, and event logs."
        actions={
          <>
            <Btn variant="border-card" size="md" leftIcon="external">REST docs</Btn>
            <Btn variant="primary" size="md" leftIcon="plus">New API key</Btn>
          </>
        } />

      <div style={{ display: 'flex', gap: 4, marginBottom: 16, borderBottom: '1px solid #EDEFF8' }}>
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            fontFamily: 'inherit', fontSize: 13.5, fontWeight: 600,
            padding: '10px 14px', background: 'transparent', border: 'none',
            color: tab===t ? '#0D0F1A' : '#6B7280', cursor: 'pointer',
            borderBottom: tab===t ? '2px solid #6C5CE7' : '2px solid transparent',
            marginBottom: -1,
          }}>{t}</button>
        ))}
      </div>

      {tab === 'API keys' && <APIKeys />}
      {tab === 'Webhooks' && <Webhooks />}
      {tab === 'OAuth apps' && <OAuthApps />}
      {tab === 'Event log' && <EventLog />}
      {tab === 'REST API' && <RestApi />}
    </div>
  );
};

const APIKeys = () => (
  <Card padding={0}>
    <table className="wpt">
      <thead>
        <tr>
          <th style={{ paddingLeft: 22 }}>Name</th>
          <th>Key</th>
          <th>Permissions</th>
          <th>Created</th>
          <th>Last used</th>
          <th style={{ paddingRight: 22 }}></th>
        </tr>
      </thead>
      <tbody>
        {API_KEYS.map((k, i) => (
          <tr key={i}>
            <td style={{ paddingLeft: 22, fontWeight: 700, color: '#0D0F1A' }}>{k.name}</td>
            <td>
              <code style={{
                fontFamily: 'JetBrains Mono, monospace', fontSize: 11.5,
                background: '#0D0F1A', color: '#4ED48A',
                padding: '5px 10px', borderRadius: 7, letterSpacing: '0.02em',
              }}>{k.key.slice(0, 14)}{'•'.repeat(8)}</code>
            </td>
            <td><Badge tone={k.perm === 'Read only' ? 'gray' : 'purple'} dot>{k.perm}</Badge></td>
            <td style={{ fontSize: 12.5, color: '#6B7280' }}>{k.created}</td>
            <td style={{ fontSize: 12.5, color: '#6B7280' }}>{k.last}</td>
            <td style={{ paddingRight: 22, textAlign: 'right' }}>
              <Btn variant="ghost-gray" size="xs" leftIcon="copy">Copy</Btn>
              <Btn variant="ghost-gray" size="xs" leftIcon="refresh">Rotate</Btn>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </Card>
);

const Webhooks = () => (
  <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 18 }}>
    <Card padding={0}>
      <div style={{ padding: '14px 20px', borderBottom: '1px solid #F0F2FF', display: 'flex', justifyContent: 'space-between' }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>Endpoints</div>
        <Btn variant="ghost" size="xs" leftIcon="plus">Add endpoint</Btn>
      </div>
      {WEBHOOKS.map((w, i) => (
        <div key={i} style={{
          padding: '18px 22px', borderBottom: i < WEBHOOKS.length - 1 ? '1px solid #F0F2FF' : 'none',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
            <code style={{
              fontFamily: 'JetBrains Mono, monospace', fontSize: 12.5,
              color: '#0D0F1A', flex: 1, fontWeight: 600,
            }}>{w.url}</code>
            <Badge tone={w.status==='Active'?'green':'red'} dot>{w.status}</Badge>
            <ToggleSwitchD on={w.status === 'Active'} />
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {w.events.map(e => (
              <code key={e} style={{
                fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
                color: '#5649CC', background: '#F3F1FE',
                padding: '3px 9px', borderRadius: 9999, fontWeight: 600,
              }}>{e}</code>
            ))}
          </div>
          <div style={{ fontSize: 11.5, color: '#9499BA', marginTop: 8 }}>
            {fmt(w.delivered)} delivered · last attempt {w.last}
          </div>
        </div>
      ))}
    </Card>

    <Card padding={22}>
      <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A', marginBottom: 12 }}>Sample event payload</div>
      <pre style={{
        background: '#0D0F1A', color: '#D4D6E0',
        padding: 16, borderRadius: 12, fontSize: 11.5,
        fontFamily: 'JetBrains Mono, monospace', overflow: 'auto',
        lineHeight: 1.65, margin: 0,
      }}>
{`{
  "event": "order.created",
  "id": "evt_8H2K_pQ9rT4",
  "created": "2026-05-26T11:42:18Z",
  "site": "shopglow.com",
  "data": {
    "order_id": 4218,
    "customer": "sarah@aurora.co",
    "amount": 15800,
    "currency": "USD",
    "items": [...]
  }
}`}
      </pre>
      <div style={{ marginTop: 14, fontSize: 12, color: '#6B7280', lineHeight: 1.6 }}>
        Verify deliveries with the <code style={{ background: '#F0F2FF', padding: '2px 6px', borderRadius: 5, fontSize: 11 }}>X-WPistic-Signature</code> header (HMAC-SHA256).
      </div>
    </Card>
  </div>
);

const ToggleSwitchD = ({ on }) => (
  <div style={{
    width: 32, height: 18, borderRadius: 9999,
    background: on ? '#00C04B' : '#E5E7F2', position: 'relative',
  }}>
    <div style={{
      position: 'absolute', top: 2, left: on ? 16 : 2,
      width: 14, height: 14, borderRadius: 9999, background: '#fff',
      boxShadow: '0 2px 4px rgba(0,0,0,0.18)', transition: 'left 0.2s',
    }} />
  </div>
);

const OAuthApps = () => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
    {[
      { name: 'Shopglow Dashboard',  client: 'app_shopglow_2026',  scopes: ['read:sites','write:automations'], status: 'Live' },
      { name: 'Agency CSM Portal',   client: 'app_agency_csm',     scopes: ['read:licenses','read:sites'],     status: 'Live' },
      { name: 'Internal CLI',        client: 'app_wpistic_cli',    scopes: ['admin:*'],                        status: 'Internal' },
    ].map((a, i) => (
      <Card key={i} hoverable padding={22}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
          <div style={{ width: 38, height: 38, borderRadius: 11, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center' }}>
            <Icon name="shield" size={18} />
          </div>
          <Badge tone={a.status==='Live'?'green':'gray'} dot>{a.status}</Badge>
        </div>
        <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>{a.name}</div>
        <code style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: '#6B7280', display: 'block', marginTop: 4 }}>{a.client}</code>
        <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginTop: 12 }}>
          {a.scopes.map(s => <code key={s} style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10.5, background: '#F0F2FF', color: '#4B5263', padding: '2px 7px', borderRadius: 5 }}>{s}</code>)}
        </div>
      </Card>
    ))}
  </div>
);

const LOG_EVENTS = [
  { t: '11:42:18', ev: 'order.created',       res: '200', site: 'shopglow.com' },
  { t: '11:39:02', ev: 'automation.completed', res: '200', site: 'shopglow.com' },
  { t: '11:34:48', ev: 'license.activated',    res: '200', site: 'theclub.co' },
  { t: '11:28:11', ev: 'site.connected',       res: '200', site: 'localcafe.com' },
  { t: '11:22:04', ev: 'booking.created',      res: '500', site: 'theclub.co' },
  { t: '11:18:38', ev: 'order.created',        res: '200', site: 'shopglow.com' },
  { t: '11:12:14', ev: 'license.activated',    res: '200', site: 'wanderly.travel' },
];

const EventLog = () => (
  <Card padding={0}>
    <table className="wpt">
      <thead>
        <tr>
          <th style={{ paddingLeft: 22 }}>Time</th>
          <th>Event</th>
          <th>Response</th>
          <th>Site</th>
          <th style={{ paddingRight: 22 }}></th>
        </tr>
      </thead>
      <tbody>
        {LOG_EVENTS.map((e, i) => (
          <tr key={i}>
            <td style={{ paddingLeft: 22, fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#6B7280' }}>{e.t}</td>
            <td>
              <code style={{
                fontFamily: 'JetBrains Mono, monospace', fontSize: 12,
                color: '#5649CC', background: '#F3F1FE',
                padding: '3px 9px', borderRadius: 6, fontWeight: 600,
              }}>{e.ev}</code>
            </td>
            <td>
              <Badge tone={e.res === '200' ? 'green' : 'red'} dot>{e.res}</Badge>
            </td>
            <td style={{ fontSize: 12.5, color: '#4B5263' }}>{e.site}</td>
            <td style={{ paddingRight: 22, textAlign: 'right' }}>
              <Btn variant="ghost" size="xs">View payload</Btn>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </Card>
);

const RestApi = () => (
  <Card padding={28}>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 32, alignItems: 'flex-start' }}>
      <div>
        <div style={{ fontSize: 11.5, fontWeight: 700, color: '#6C5CE7', letterSpacing: '0.08em', textTransform: 'uppercase' }}>REST API</div>
        <div style={{ fontSize: 24, fontWeight: 800, color: '#0D0F1A', marginTop: 8, letterSpacing: '-0.02em' }}>Build with WPistic</div>
        <p style={{ fontSize: 14, color: '#4B5263', lineHeight: 1.7, marginTop: 12 }}>
          Programmatic access to every product, license, site, automation, contact, and conversation in your workspace. JSON over HTTPS. Bearer tokens. 50,000 req/day.
        </p>
        <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
          <Btn variant="primary" size="sm" rightIcon="external">Open docs</Btn>
          <Btn variant="border-card" size="sm" leftIcon="download">OpenAPI spec</Btn>
        </div>
        <div style={{ marginTop: 24, paddingTop: 18, borderTop: '1px solid #F0F2FF' }}>
          <div style={{ fontSize: 11.5, fontWeight: 700, color: '#6B7280', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10 }}>Webhook events</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 6 }}>
            {['license.activated','site.connected','order.created','booking.created','automation.completed','agent.handoff','member.upgraded','ticket.created'].map(e => (
              <code key={e} style={{
                fontFamily: 'JetBrains Mono, monospace', fontSize: 11.5,
                color: '#5649CC', background: '#F3F1FE',
                padding: '5px 9px', borderRadius: 6, fontWeight: 600,
              }}>{e}</code>
            ))}
          </div>
        </div>
      </div>

      <pre style={{
        background: '#0D0F1A', color: '#D4D6E0',
        padding: 20, borderRadius: 14, fontSize: 12,
        fontFamily: 'JetBrains Mono, monospace', overflow: 'auto',
        lineHeight: 1.7, margin: 0,
      }}>
{`# List your sites
curl https://api.wpistic.com/v1/sites \\
  -H "Authorization: Bearer $WPISTIC_KEY"

{
  "data": [
    {
      "id": "site_shopglow",
      "domain": "shopglow.com",
      "wp_version": "6.5.3",
      "status": "healthy",
      "products": ["chatbotistic", "crmistic", ...]
    },
    ...
  ],
  "next_cursor": null
}

# Create an automation
curl -X POST https://api.wpistic.com/v1/automations \\
  -H "Authorization: Bearer $WPISTIC_KEY" \\
  -d '{
    "name": "Cart recovery → WhatsApp",
    "trigger": "cart.abandoned",
    "delay_min": 15,
    "action": "chat.send_template"
  }'`}
      </pre>
    </div>
  </Card>
);

// ─────────────────────────────────────────────────────────────
// SETTINGS
// ─────────────────────────────────────────────────────────────
const SETTINGS_NAV = [
  { id: 'profile',    icon: 'users',  label: 'Profile' },
  { id: 'workspace',  icon: 'cube',   label: 'Workspace' },
  { id: 'team',       icon: 'users',  label: 'Team & roles' },
  { id: 'notify',     icon: 'bell',   label: 'Notifications' },
  { id: 'security',   icon: 'shield', label: 'Security' },
  { id: 'connected',  icon: 'globe',  label: 'Connected accounts' },
  { id: 'branding',   icon: 'spark',  label: 'Agency branding' },
  { id: 'apikeys',    icon: 'code',   label: 'API access' },
];

const SettingsPage = () => {
  const [section, setSection] = React.useState('profile');
  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      <PageHeader eyebrow="Account" title="Settings" subtitle="Profile, workspace, team, security, and integrations." />

      <div style={{ display: 'grid', gridTemplateColumns: '224px 1fr', gap: 18 }}>
        <Card padding={10} style={{ alignSelf: 'flex-start', position: 'sticky', top: 12 }}>
          {SETTINGS_NAV.map(n => {
            const active = section === n.id;
            return (
              <div key={n.id} onClick={() => setSection(n.id)} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 12px', borderRadius: 9, cursor: 'pointer',
                background: active ? '#F3F1FE' : 'transparent',
                color: active ? '#5649CC' : '#4B5263',
                fontSize: 13, fontWeight: active ? 700 : 500,
              }}>
                <Icon name={n.icon} size={15} color={active ? '#6C5CE7' : '#9499BA'} />
                {n.label}
              </div>
            );
          })}
        </Card>

        <div>
          {section === 'profile' && <ProfileSettings />}
          {section === 'workspace' && <WorkspaceSettings />}
          {section === 'team' && <TeamSettings />}
          {section === 'notify' && <NotifySettings />}
          {section === 'security' && <SecuritySettings />}
          {section === 'connected' && <ConnectedSettings />}
          {section === 'branding' && <BrandingSettings />}
          {section === 'apikeys' && <APIKeys />}
        </div>
      </div>
    </div>
  );
};

const SettingRow = ({ label, hint, children }) => (
  <div style={{
    padding: '20px 24px', borderBottom: '1px solid #F0F2FF',
    display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 24, alignItems: 'flex-start',
  }}>
    <div>
      <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{label}</div>
      {hint && <div style={{ fontSize: 12, color: '#6B7280', marginTop: 4, lineHeight: 1.55 }}>{hint}</div>}
    </div>
    <div>{children}</div>
  </div>
);

const InputField = ({ value, placeholder, type = 'text' }) => {
  const [v, setV] = React.useState(value || '');
  return (
    <input type={type} defaultValue={v} placeholder={placeholder} style={{
      width: '100%', padding: '10px 14px',
      borderRadius: 10, border: '1.5px solid #E8EAFF',
      fontSize: 13.5, color: '#0D0F1A', fontFamily: 'inherit',
      outline: 'none', background: '#fff',
    }} />
  );
};

const ProfileSettings = () => (
  <Card padding={0}>
    <div style={{ padding: '20px 24px', borderBottom: '1px solid #F0F2FF', display: 'flex', alignItems: 'center', gap: 16 }}>
      <div style={{
        width: 64, height: 64, borderRadius: '50%',
        background: 'linear-gradient(135deg, #00C04B, #6C5CE7)',
        color: '#fff', fontSize: 22, fontWeight: 800,
        display: 'grid', placeItems: 'center', letterSpacing: '-0.02em',
      }}>SR</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>Shuvo Roy</div>
        <div style={{ fontSize: 12.5, color: '#6B7280' }}>Owner · shuvo@wpistic.com</div>
      </div>
      <Btn variant="border-card" size="sm">Upload photo</Btn>
      <Btn variant="ghost-gray" size="sm">Remove</Btn>
    </div>
    <SettingRow label="Full name" hint="As it appears on invoices and emails.">
      <InputField value="Shuvo Roy" />
    </SettingRow>
    <SettingRow label="Email" hint="Your primary login email. Verification required to change.">
      <InputField value="shuvo@wpistic.com" type="email" />
    </SettingRow>
    <SettingRow label="Timezone" hint="Affects automation schedules and notifications.">
      <SelectChip value="(UTC−05:00) Eastern Time — New York" onChange={() => {}}
        options={['(UTC−05:00) Eastern Time — New York','(UTC) London','(UTC+01:00) Berlin','(UTC+05:30) Kolkata']} />
    </SettingRow>
    <SettingRow label="Language" hint="UI language for the dashboard.">
      <SelectChip value="English (US)" onChange={() => {}}
        options={['English (US)','English (UK)','Deutsch','Français','Bangla']} />
    </SettingRow>
    <div style={{ padding: 24, display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
      <Btn variant="ghost-gray" size="md">Cancel</Btn>
      <Btn variant="primary" size="md">Save changes</Btn>
    </div>
  </Card>
);

const WorkspaceSettings = () => (
  <Card padding={0}>
    <SettingRow label="Workspace name" hint="Visible to your team and on the dashboard.">
      <InputField value="Shuvo's Workspace" />
    </SettingRow>
    <SettingRow label="Workspace URL" hint="Your unique workspace subdomain.">
      <div style={{ display: 'flex', alignItems: 'center', border: '1.5px solid #E8EAFF', borderRadius: 10, overflow: 'hidden' }}>
        <input defaultValue="shuvo" style={{
          flex: 1, padding: '10px 14px', border: 'none', fontSize: 13.5, outline: 'none', fontFamily: 'inherit',
        }} />
        <div style={{ padding: '10px 14px', background: '#F8F9FF', borderLeft: '1.5px solid #E8EAFF', fontSize: 13, color: '#6B7280' }}>
          .wpistic.com
        </div>
      </div>
    </SettingRow>
    <SettingRow label="Industry" hint="Helps us recommend agents and automations.">
      <SelectChip value="WooCommerce / Retail" onChange={() => {}}
        options={['WooCommerce / Retail','Agency','Membership / SaaS','Travel & Hospitality','Local Services']} />
    </SettingRow>
    <SettingRow label="Default site" hint="Where new automations and agents go by default.">
      <SelectChip value="shopglow.com" onChange={() => {}}
        options={['shopglow.com','theclub.co','wanderly.travel','localcafe.com','agency-tools.io']} />
    </SettingRow>
    <SettingRow label="Delete workspace" hint="Permanently delete all workspace data. This cannot be undone.">
      <Btn variant="danger" size="sm">Delete workspace</Btn>
    </SettingRow>
  </Card>
);

const TEAM = [
  { name: 'Shuvo Roy',     email: 'shuvo@wpistic.com',     role: 'Owner',  status: 'Active',  last: 'Now' },
  { name: 'Sarah Patel',   email: 'sarah@wpistic.com',     role: 'Admin',  status: 'Active',  last: '12 min ago' },
  { name: 'Marcus Reed',   email: 'marcus@wpistic.com',    role: 'Editor', status: 'Active',  last: 'Yesterday' },
  { name: 'Jordan Yu',     email: 'jordan@partner.dev',    role: 'Viewer', status: 'Invited', last: '—' },
];

const TeamSettings = () => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
    <Card padding={0}>
      <div style={{ padding: '14px 22px', borderBottom: '1px solid #F0F2FF', display: 'flex', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>Team members</div>
          <div style={{ fontSize: 12, color: '#6B7280', marginTop: 2 }}>3 / 5 seats used on Business plan</div>
        </div>
        <Btn variant="primary" size="sm" leftIcon="plus">Invite member</Btn>
      </div>
      <table className="wpt">
        <thead>
          <tr>
            <th style={{ paddingLeft: 22 }}>Member</th>
            <th>Role</th>
            <th>Status</th>
            <th>Last active</th>
            <th style={{ paddingRight: 22 }}></th>
          </tr>
        </thead>
        <tbody>
          {TEAM.map(t => (
            <tr key={t.email}>
              <td style={{ paddingLeft: 22 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <AvatarCircle name={t.name} size={34} />
                  <div>
                    <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{t.name}</div>
                    <div style={{ fontSize: 11.5, color: '#6B7280' }}>{t.email}</div>
                  </div>
                </div>
              </td>
              <td>
                <Badge tone={t.role==='Owner'?'dark':t.role==='Admin'?'purple':t.role==='Editor'?'amber':'gray'}>{t.role}</Badge>
              </td>
              <td><Badge tone={t.status === 'Active' ? 'green' : 'gray'} dot>{t.status}</Badge></td>
              <td style={{ fontSize: 12, color: '#9499BA' }}>{t.last}</td>
              <td style={{ paddingRight: 22, textAlign: 'right' }}>
                <Btn variant="ghost-gray" size="xs">Edit role</Btn>
                {t.role !== 'Owner' && <Btn variant="ghost-gray" size="xs">Remove</Btn>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>

    <Card padding={22}>
      <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A', marginBottom: 12 }}>Roles & permissions</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {[
          { role: 'Owner', tone: 'dark', desc: 'Full access. Billing. Delete workspace.' },
          { role: 'Admin', tone: 'purple', desc: 'Manage sites, products, team. Not billing.' },
          { role: 'Editor', tone: 'amber', desc: 'Edit content, automations, agents. View licenses.' },
          { role: 'Viewer', tone: 'gray', desc: 'Read-only. View dashboards and reports.' },
        ].map(r => (
          <div key={r.role} style={{
            padding: 16, background: '#F8F9FF', border: '1px solid #EDEFF8', borderRadius: 12,
          }}>
            <Badge tone={r.tone}>{r.role}</Badge>
            <div style={{ fontSize: 12, color: '#4B5263', marginTop: 10, lineHeight: 1.55 }}>{r.desc}</div>
          </div>
        ))}
      </div>
    </Card>
  </div>
);

const NotifySettings = () => {
  const groups = [
    { title: 'Licenses', items: ['License expires in 14 days', 'License activation succeeded', 'Domain limit reached'] },
    { title: 'Sites',    items: ['Site sync failed', 'Plugin update available', 'WP / PHP version incompatible'] },
    { title: 'Automations', items: ['Automation failed 3+ times', 'New flow created by team', 'Weekly automation digest'] },
    { title: 'Billing',  items: ['Invoice issued', 'Payment failed', 'Usage at 80% / 95% of plan'] },
  ];
  return (
    <Card padding={0}>
      {groups.map((g, gi) => (
        <div key={g.title} style={{ borderBottom: gi < groups.length - 1 ? '1px solid #F0F2FF' : 'none' }}>
          <div style={{ padding: '14px 24px 8px', fontSize: 11.5, fontWeight: 700, color: '#6C5CE7', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
            {g.title}
          </div>
          <div style={{ padding: '0 24px 14px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px 80px 80px', gap: 14, fontSize: 11, fontWeight: 700, color: '#9499BA', letterSpacing: '0.06em', textTransform: 'uppercase', paddingBottom: 8, borderBottom: '1px solid #F0F2FF' }}>
              <span></span><span style={{ textAlign: 'center' }}>Email</span><span style={{ textAlign: 'center' }}>In-app</span><span style={{ textAlign: 'center' }}>Slack</span>
            </div>
            {g.items.map((it, i) => (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 80px 80px 80px', gap: 14, padding: '12px 0', fontSize: 13.5, color: '#0D0F1A', borderBottom: i < g.items.length - 1 ? '1px solid #F8F9FF' : 'none', alignItems: 'center' }}>
                <span>{it}</span>
                <div style={{ display: 'grid', placeItems: 'center' }}><ToggleSwitchD on={i !== 1} /></div>
                <div style={{ display: 'grid', placeItems: 'center' }}><ToggleSwitchD on /></div>
                <div style={{ display: 'grid', placeItems: 'center' }}><ToggleSwitchD on={i === 0} /></div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </Card>
  );
};

const SecuritySettings = () => (
  <Card padding={0}>
    <SettingRow label="Two-factor authentication" hint="Add an extra layer of security with TOTP authenticator apps.">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Badge tone="green" dot>Enabled</Badge>
        <Btn variant="border-card" size="sm">Reconfigure</Btn>
      </div>
    </SettingRow>
    <SettingRow label="Password" hint="Last changed Mar 12, 2026.">
      <Btn variant="border-card" size="sm">Change password</Btn>
    </SettingRow>
    <SettingRow label="Active sessions" hint="3 active sessions. Revoke any you don't recognize.">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {[
          { d: 'MacBook Pro · Chrome', loc: 'New York, NY', this: true, when: 'Now' },
          { d: 'iPhone 16 · iOS app',  loc: 'New York, NY', when: '2 hr ago' },
          { d: 'Windows · Firefox',    loc: 'Berlin, DE',   when: 'Yesterday', flag: true },
        ].map((s, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '12px 14px', background: '#F8F9FF', borderRadius: 10, border: '1px solid #EDEFF8',
          }}>
            <Icon name="shield" size={16} color={s.flag ? '#EF4444' : '#6C5CE7'} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#0D0F1A' }}>{s.d} {s.this && <span style={{ color: '#00C04B', fontSize: 11, fontWeight: 700 }}>· This device</span>}</div>
              <div style={{ fontSize: 11.5, color: '#6B7280' }}>{s.loc} · {s.when}</div>
            </div>
            {!s.this && <Btn variant="ghost-gray" size="xs">Revoke</Btn>}
          </div>
        ))}
      </div>
    </SettingRow>
    <SettingRow label="SSO / SAML" hint="Available on Business and Agency plans.">
      <Btn variant="border-card" size="sm" leftIcon="plus">Configure SSO</Btn>
    </SettingRow>
  </Card>
);

const ConnectedSettings = () => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14 }}>
    {[
      { name: 'WhatsApp Business', desc: 'Send and receive messages via official Cloud API.', connected: true, tone: 'green' },
      { name: 'Stripe',            desc: 'Customers, subscriptions, and invoice payments.',    connected: true, tone: 'purple' },
      { name: 'Google Analytics',  desc: 'GA4 properties for Insightistic reporting.',          connected: true, tone: 'purple' },
      { name: 'Google Search Console', desc: 'Clicks, impressions, and keyword data.',           connected: true, tone: 'purple' },
      { name: 'Slack',             desc: 'Real-time alerts in your team channels.',             connected: false, tone: 'purple' },
      { name: 'Zapier',            desc: 'Connect to 6,000+ apps via Zaps.',                    connected: false, tone: 'purple' },
    ].map((c, i) => (
      <Card key={i} padding={22} hoverable>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
          <div style={{ width: 40, height: 40, borderRadius: 11, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center' }}>
            <Icon name="external" size={18} />
          </div>
          {c.connected
            ? <Badge tone="green" dot>Connected</Badge>
            : <Badge tone="gray">Not connected</Badge>}
        </div>
        <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>{c.name}</div>
        <p style={{ fontSize: 12.5, color: '#4B5263', lineHeight: 1.55, margin: '6px 0 14px' }}>{c.desc}</p>
        <Btn variant={c.connected?'border-card':'primary'} size="sm" style={{ width: '100%', justifyContent: 'center' }}>
          {c.connected ? 'Manage' : 'Connect'}
        </Btn>
      </Card>
    ))}
  </div>
);

const BrandingSettings = () => (
  <Card padding={0}>
    <div style={{ padding: 24, background: 'linear-gradient(135deg, #F3F1FE, #E8FAF0)', borderBottom: '1px solid #EDEFF8' }}>
      <Badge tone="purple" dot>Agency plan add-on · $79/mo</Badge>
      <div style={{ fontSize: 18, fontWeight: 800, color: '#0D0F1A', marginTop: 10, letterSpacing: '-0.02em' }}>
        White-label the WPistic dashboard for your clients
      </div>
      <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: '6px 0 0', maxWidth: 600 }}>
        Replace logos, colors, login pages, and email senders with your agency brand. Clients see your name, not WPistic.
      </p>
    </div>
    <SettingRow label="Brand name" hint="Shown in nav and emails."><InputField value="Shuvo Studio" /></SettingRow>
    <SettingRow label="Primary color" hint="Used for buttons, accents, and gradients.">
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <div style={{ width: 38, height: 38, borderRadius: 10, background: '#6C5CE7', border: '1px solid #EDEFF8' }} />
        <InputField value="#6C5CE7" />
      </div>
    </SettingRow>
    <SettingRow label="Logo" hint="SVG or PNG. Light and dark variants recommended.">
      <div style={{ display: 'flex', gap: 10 }}>
        <Btn variant="border-card" size="sm" leftIcon="download">Upload light</Btn>
        <Btn variant="border-card" size="sm" leftIcon="download">Upload dark</Btn>
      </div>
    </SettingRow>
    <SettingRow label="Custom domain" hint="Point dashboard.youragency.com → WPistic.">
      <InputField value="dashboard.shuvo.studio" />
    </SettingRow>
  </Card>
);

Object.assign(window, { SupportPage, DevelopersPage, SettingsPage });
