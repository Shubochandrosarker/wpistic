// app.jsx — Root router (marketing + auth + app)

const PAGE_TITLES = {
  dashboard:   { title: 'Dashboard',     subtitle: "Today's overview · Tuesday, May 26" },
  products:    { title: 'Products',      subtitle: 'Browse and manage the WordPressistic ecosystem' },
  licenses:    { title: 'Licenses',      subtitle: '12 licenses · 3 need attention' },
  downloads:   { title: 'Downloads',     subtitle: 'Latest builds and changelogs' },
  websites:    { title: 'Websites',      subtitle: '5 sites connected · WordPress + WooCommerce' },
  agents:      { title: 'AI Agents',     subtitle: 'Marketplace and active agents · WPAgentistic beta' },
  automations: { title: 'Automations',   subtitle: '5 active flows · 2,847 runs this month' },
  crm:         { title: 'CRM',           subtitle: '2,847 contacts across every channel' },
  inbox:       { title: 'Inbox',         subtitle: 'WhatsApp, web chat, email, and tickets' },
  analytics:   { title: 'Analytics',     subtitle: 'Traffic, revenue, AI usage across sites' },
  billing:     { title: 'Billing',       subtitle: 'Business plan · renews March 18, 2027' },
  support:     { title: 'Support',       subtitle: 'Tickets, knowledge base, live chat' },
  developers:  { title: 'Developers',    subtitle: 'API keys, webhooks, REST docs, event log' },
  settings:    { title: 'Settings',      subtitle: 'Profile, workspace, team, security' },
};

const APP_PAGES = new Set(Object.keys(PAGE_TITLES));

const App = () => {
  const [page, setPage] = React.useState('homepage');

  // App pages live in the dashboard shell
  if (APP_PAGES.has(page)) {
    const fullBleedPages = { inbox: true };
    const meta = PAGE_TITLES[page];
    const pageBody = (() => {
      switch (page) {
        case 'dashboard':   return <DashboardHome />;
        case 'products':    return <ProductsPage />;
        case 'licenses':    return <LicensesPage />;
        case 'downloads':   return <DownloadsPage />;
        case 'websites':    return <WebsitesPage />;
        case 'agents':      return <AgentsPage />;
        case 'automations': return <AutomationsPage />;
        case 'crm':         return <CrmPage />;
        case 'inbox':       return <InboxPage />;
        case 'analytics':   return <AnalyticsPage />;
        case 'billing':     return <BillingPage />;
        case 'support':     return <SupportPage />;
        case 'developers':  return <DevelopersPage />;
        case 'settings':    return <SettingsPage />;
        default: return null;
      }
    })();
    return (
      <AppShell
        active={page}
        onNav={setPage}
        title={meta.title}
        subtitle={meta.subtitle}
        hideTopbar={fullBleedPages[page]}>
        {pageBody}
      </AppShell>
    );
  }

  // Auth pages
  if (page === 'login')    return <LoginPage    onEnterApp={() => setPage('dashboard')} onHome={() => setPage('homepage')} onSwitch={setPage} />;
  if (page === 'register') return <RegisterPage onEnterApp={() => setPage('workspace-setup')} onHome={() => setPage('homepage')} onSwitch={setPage} />;
  if (page === 'forgot')   return <ForgotPage   onEnterApp={() => setPage('login')} onHome={() => setPage('homepage')} onSwitch={setPage} />;
  if (page === 'workspace-setup') return <WorkspaceSetupPage onEnterApp={() => setPage('dashboard')} onHome={() => setPage('homepage')} />;

  // Marketing pages
  const nav = setPage;
  switch (page) {
    case 'homepage':              return <Homepage onNav={nav} onEnterApp={() => nav('register')} />;
    case 'products-overview':     return <ProductsOverviewPage onNav={nav} />;
    case 'ecosystem-overview':    return <EcosystemOverviewPage onNav={nav} />;
    case 'platform-overview':     return <PlatformOverviewPage onNav={nav} />;
    case 'pricing':               return <PricingPage onNav={nav} />;
    case 'contact':               return <ContactPage onNav={nav} />;

    // Product pages
    case 'product-chatbotistic':  return <ChatbotisticPage onNav={nav} />;
    case 'product-memberistic':   return <MemberisticPage onNav={nav} />;
    case 'product-bookingistic':  return <BookingisticPage onNav={nav} />;
    case 'product-insightistic':  return <InsightisticPage onNav={nav} />;
    case 'product-crmistic':      return <CrmisticPage onNav={nav} />;

    // Platform pages
    case 'platform-licenses':     return <LicensesPlatformPage onNav={nav} />;
    case 'platform-agents':       return <AgentsPlatformPage onNav={nav} />;
    case 'platform-automations':  return <AutomationsPlatformPage onNav={nav} />;
    case 'platform-inbox':        return <InboxPlatformPage onNav={nav} />;
    case 'platform-analytics':    return <AnalyticsPlatformPage onNav={nav} />;
    case 'platform-developers':   return <DevelopersPlatformPage onNav={nav} />;

    // Ecosystem sub-pages
    case 'ecosystem-plugins':       return <PluginsEcosystemPage onNav={nav} />;
    case 'ecosystem-ai':            return <AIEcosystemPage onNav={nav} />;
    case 'ecosystem-ops':           return <OpsEcosystemPage onNav={nav} />;
    case 'ecosystem-integrations':  return <IntegrationsEcosystemPage onNav={nav} />;

    // Company
    case 'about':     return <AboutPage onNav={nav} />;
    case 'blog':      return <BlogPage onNav={nav} />;
    case 'affiliate': return <AffiliatePage onNav={nav} />;
    case 'press':     return <PressPage onNav={nav} />;

    // Legal
    case 'legal-privacy':  return <PrivacyPage onNav={nav} />;
    case 'legal-terms':    return <TermsPage onNav={nav} />;
    case 'legal-refunds':  return <RefundsPage onNav={nav} />;
    case 'legal-security': return <SecurityPage onNav={nav} />;

    default: return <Homepage onNav={nav} onEnterApp={() => nav('register')} />;
  }
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
