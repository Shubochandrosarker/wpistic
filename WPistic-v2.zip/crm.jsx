// crm.jsx — Contacts / leads / customers

const LEADS = [
  { name: 'Sarah Lin',       email: 'sarah@aurora.co',      source: 'Chatbotistic', site: 'shopglow.com',    status: 'Customer', value: '$2,840', tags: ['VIP','WooCommerce'],   last: '2 min ago',  product: 'chatbotistic' },
  { name: 'Marcus Reed',     email: 'marcus@spincycle.io',  source: 'WhatsApp',     site: 'shopglow.com',    status: 'Qualified', value: '$486', tags: ['Lead'],                 last: '14 min ago', product: 'chatbotistic' },
  { name: 'Priya Shah',      email: 'priya@theclub.co',     source: 'Memberistic',  site: 'theclub.co',      status: 'Active member', value: '$29/mo', tags: ['Annual'],          last: '32 min ago', product: 'memberistic' },
  { name: 'Daniel Hoff',     email: 'd.hoff@hofflaw.com',   source: 'Bookingistic', site: 'wanderly.travel', status: 'Booked',    value: '$1,290', tags: ['Repeat'],              last: '1 hr ago',   product: 'bookingistic' },
  { name: 'Emily Park',      email: 'emily.p@gmail.com',    source: 'Web form',     site: 'shopglow.com',    status: 'New',       value: '—',     tags: ['Cold'],                 last: '2 hr ago',   product: 'crmistic' },
  { name: 'Jordan Reyes',    email: 'jordan@bytefoundry.co', source: 'Chatbotistic',site: 'agency-tools.io', status: 'Qualified', value: '$3,200', tags: ['Enterprise'],         last: '3 hr ago',   product: 'crmistic' },
  { name: 'Aisha Khan',      email: 'aisha@thehouse.studio',source: 'WhatsApp',     site: 'shopglow.com',    status: 'Customer',  value: '$640',   tags: ['VIP','Repeat'],        last: '6 hr ago',   product: 'chatbotistic' },
  { name: 'Tom Becker',      email: 't.becker@northwind.de', source: 'Insightistic',site: 'wanderly.travel', status: 'New',       value: '—',     tags: ['Cold'],                 last: 'Yesterday',  product: 'insightistic' },
];

const STATUS_LEAD = {
  'New': 'gray',
  'Qualified': 'purple',
  'Booked': 'amber',
  'Customer': 'green',
  'Active member': 'green',
};

const CrmPage = () => {
  const [selected, setSelected] = React.useState(LEADS[0]);
  const [view, setView] = React.useState('Contacts');

  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      <PageHeader
        eyebrow="CRMistic"
        title="CRM"
        subtitle="Every contact across your sites, plugins, channels, and AI agents — unified."
        actions={
          <>
            <Btn variant="border-card" size="md" leftIcon="download">Export</Btn>
            <Btn variant="border-card" size="md" leftIcon="filter">Segments</Btn>
            <Btn variant="primary" size="md" leftIcon="plus">Add contact</Btn>
          </>
        } />

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14, marginBottom: 22 }}>
        <MiniStat label="All contacts" value="2,847" icon="users" iconBg="#F3F1FE" iconColor="#6C5CE7" sub="+218 this week" />
        <MiniStat label="Customers" value="612" icon="check" iconBg="#E8FAF0" iconColor="#00C04B" sub="21% of contacts" />
        <MiniStat label="Active members" value="284" icon="members" iconBg="#F3F1FE" iconColor="#6C5CE7" sub="from Memberistic" />
        <MiniStat label="Lifetime value" value="$184k" icon="card" iconBg="#E8FAF0" iconColor="#00C04B" sub="+12% MoM" />
      </div>

      {/* Sub view tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, borderBottom: '1px solid #EDEFF8' }}>
        {['Contacts', 'Customers', 'Members', 'Leads', 'Segments'].map(t => (
          <button key={t} onClick={() => setView(t)} style={{
            fontFamily: 'inherit', fontSize: 13.5, fontWeight: 600,
            padding: '10px 14px', background: 'transparent', border: 'none',
            color: view===t ? '#0D0F1A' : '#6B7280', cursor: 'pointer',
            borderBottom: view===t ? '2px solid #6C5CE7' : '2px solid transparent',
            marginBottom: -1,
          }}>{t}</button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: selected ? '1.6fr 1fr' : '1fr', gap: 18 }}>
        <Card padding={0}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid #F0F2FF', display: 'flex', gap: 8 }}>
            <TextInput placeholder="Search by name, email, tag, source…" icon="search" size="sm" style={{ flex: 1 }} />
            <Btn variant="border-card" size="sm" leftIcon="filter">Filter</Btn>
          </div>
          <table className="wpt">
            <thead>
              <tr>
                <th style={{ paddingLeft: 22 }}>Contact</th>
                <th>Source</th>
                <th>Status</th>
                <th>Value</th>
                <th>Last activity</th>
              </tr>
            </thead>
            <tbody>
              {LEADS.map((l, i) => (
                <tr key={i}
                  onClick={() => setSelected(l)}
                  style={{
                    cursor: 'pointer',
                    background: selected?.email === l.email ? '#F3F1FE' : 'transparent',
                  }}>
                  <td style={{ paddingLeft: 22 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <AvatarCircle name={l.name} />
                      <div>
                        <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{l.name}</div>
                        <div style={{ fontSize: 11.5, color: '#6B7280' }}>{l.email}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ fontSize: 12.5, color: '#4B5263' }}>{l.source}</td>
                  <td><Badge tone={STATUS_LEAD[l.status] || 'gray'} dot>{l.status}</Badge></td>
                  <td style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>{l.value}</td>
                  <td style={{ fontSize: 12, color: '#9499BA' }}>{l.last}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        {selected && <ContactPanel contact={selected} onClose={() => setSelected(null)} />}
      </div>
    </div>
  );
};

const AvatarCircle = ({ name, size = 36 }) => {
  const initials = name.split(' ').map(w => w[0]).slice(0, 2).join('');
  const hues = [
    'linear-gradient(135deg, #6C5CE7, #4137A8)',
    'linear-gradient(135deg, #00C04B, #007C2F)',
    'linear-gradient(135deg, #F59E0B, #D97706)',
    'linear-gradient(135deg, #5649CC, #6C5CE7)',
    'linear-gradient(135deg, #1A1659, #6C5CE7)',
  ];
  const c = hues[name.charCodeAt(0) % hues.length];
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: c, color: '#fff',
      fontSize: size * 0.36, fontWeight: 800, letterSpacing: '-0.02em',
      display: 'grid', placeItems: 'center', flexShrink: 0,
    }}>{initials.toUpperCase()}</div>
  );
};

const ContactPanel = ({ contact: c }) => {
  const product = PRODUCTS.find(p => p.id === c.product);
  const timeline = [
    { icon: 'chat', tone: '#6C5CE7', t: 'Conversation on WhatsApp', d: 'Asked about Aurora pendant lamp in matte black', time: '2 min ago' },
    { icon: 'cube', tone: '#00C04B', t: 'Order #4218 placed', d: '2x Aurora pendant · $158.00', time: '4 min ago' },
    { icon: 'spark', tone: '#6C5CE7', t: 'AI agent suggested upsell', d: 'Matching wall sconce · accepted', time: '6 min ago' },
    { icon: 'globe', tone: '#9499BA', t: 'Visited shopglow.com', d: '8 pages · 4m 12s · came from Google', time: '20 min ago' },
    { icon: 'inbox', tone: '#6C5CE7', t: 'Email opened', d: '“Summer collection just dropped” · 2x opens', time: '3 hr ago' },
  ];

  return (
    <Card padding={0}>
      <div style={{ padding: '22px 22px 18px', borderBottom: '1px solid #F0F2FF' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <AvatarCircle name={c.name} size={50} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 17, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.01em' }}>{c.name}</div>
            <div style={{ fontSize: 12.5, color: '#6B7280' }}>{c.email}</div>
          </div>
          <button style={{
            background: '#F0F2FF', border: 'none', borderRadius: 8,
            width: 30, height: 30, color: '#6B7280', cursor: 'pointer',
            display: 'grid', placeItems: 'center',
          }}><Icon name="dots" size={14} /></button>
        </div>

        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 14 }}>
          <Badge tone={STATUS_LEAD[c.status] || 'gray'} dot>{c.status}</Badge>
          {c.tags.map(t => <Badge key={t} tone="purple">{t}</Badge>)}
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="primary" size="sm" style={{ flex: 1, justifyContent: 'center' }} leftIcon="inbox">Message</Btn>
          <Btn variant="border-card" size="sm" leftIcon="zap">Automate</Btn>
        </div>
      </div>

      {/* Meta */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0, borderBottom: '1px solid #F0F2FF' }}>
        <MetaBlock label="Value" value={c.value} />
        <MetaBlock label="Source" value={c.source} sub />
        <MetaBlock label="Site" value={c.site} />
        <MetaBlock label="From product">
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <ProductGlyph name={product.glyph} color={product.color} bg={product.bg} size={18} radius={5} />
            <span style={{ fontSize: 13, fontWeight: 600, color: '#0D0F1A' }}>{product.name}</span>
          </div>
        </MetaBlock>
      </div>

      {/* Timeline */}
      <div style={{ padding: 22 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>Activity</div>
          <Btn variant="ghost-gray" size="xs">Add note</Btn>
        </div>
        <div style={{ position: 'relative', paddingLeft: 22 }}>
          <div style={{ position: 'absolute', left: 9, top: 6, bottom: 6, width: 1.5, background: '#E9E6FD' }} />
          {timeline.map((e, i) => (
            <div key={i} style={{ position: 'relative', paddingBottom: 18 }}>
              <div style={{
                position: 'absolute', left: -22, top: 0, width: 19, height: 19, borderRadius: 9999,
                background: '#fff', border: '2px solid ' + e.tone,
                color: e.tone, display: 'grid', placeItems: 'center',
              }}>
                <Icon name={e.icon} size={9} />
              </div>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#0D0F1A' }}>{e.t}</div>
              <div style={{ fontSize: 11.5, color: '#6B7280', marginTop: 2, lineHeight: 1.5 }}>{e.d}</div>
              <div style={{ fontSize: 11, color: '#9499BA', marginTop: 3 }}>{e.time}</div>
            </div>
          ))}
        </div>

        {/* Follow-up */}
        <div style={{
          marginTop: 8, padding: 14, background: '#FEF3C7', border: '1px solid #FCD34D',
          borderRadius: 12, display: 'flex', alignItems: 'flex-start', gap: 10,
        }}>
          <Icon name="warn" size={16} color="#92400E" />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#78350F' }}>Follow-up task</div>
            <div style={{ fontSize: 12, color: '#92400E', marginTop: 2 }}>Send hand-written thank-you · due tomorrow</div>
          </div>
          <Btn variant="primary" size="xs">Done</Btn>
        </div>
      </div>
    </Card>
  );
};

const MetaBlock = ({ label, value, children, sub }) => (
  <div style={{ padding: '14px 18px', borderRight: '1px solid #F0F2FF' }}>
    <div style={{ fontSize: 10, fontWeight: 700, color: '#9499BA', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 5 }}>{label}</div>
    {children || <div style={{ fontSize: 13.5, fontWeight: sub ? 600 : 700, color: '#0D0F1A' }}>{value}</div>}
  </div>
);

Object.assign(window, { CrmPage, AvatarCircle });
