// platform-pages.jsx — 6 platform pages + 4 ecosystem sub-pages

// ─── Shared platform hero ────────────────────────────────────
const PlatformHero = ({ icon, eyebrow, title, gradient, sub, onNav, mock }) => (
  <section style={{
    position: 'relative', overflow: 'hidden',
    background: 'linear-gradient(155deg, #F3F1FE 0%, #EEF0FF 60%, #E8FAF0 130%)',
    padding: '70px 36px 80px',
  }}>
    <div style={{
      position: 'absolute', top: -120, right: -120, width: 500, height: 500,
      background: 'radial-gradient(circle, rgba(108,92,231,0.20), transparent 65%)',
    }} />
    <div style={{
      maxWidth: 1240, margin: '0 auto', position: 'relative',
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'center',
    }}>
      <div>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10, padding: '6px 14px', background: '#fff', borderRadius: 9999, border: '1px solid #EDEFF8', boxShadow: '0 4px 14px rgba(108,92,231,0.08)' }}>
          <div style={{ width: 22, height: 22, borderRadius: 6, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center' }}>
            <Icon name={icon} size={12} />
          </div>
          <span style={{ fontSize: 12.5, fontWeight: 700, color: '#0D0F1A' }}>{eyebrow}</span>
          <span style={{ fontSize: 11, color: '#9499BA' }}>· WPistic Platform</span>
        </div>
        <h1 style={{
          fontSize: 54, fontWeight: 800, letterSpacing: '-0.035em',
          color: '#0D0F1A', lineHeight: 1.08, margin: '20px 0 18px', textWrap: 'balance',
        }}>
          {title}
          {gradient && <> <span style={{
            background: '#00C04B',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>{gradient}</span></>}
        </h1>
        <p style={{ fontSize: 17, color: '#4B5263', lineHeight: 1.65, marginBottom: 30, maxWidth: 520 }}>{sub}</p>
        <div style={{ display: 'flex', gap: 10 }}>
          <Btn size="xl" onClick={() => onNav('register')} rightIcon="arrow">Start free</Btn>
          <Btn size="xl" variant="outline" onClick={() => onNav('platform-overview')}>Platform overview</Btn>
        </div>
      </div>
      <div>{mock}</div>
    </div>
  </section>
);

// ═════════════════════════════════════════════════════════════
// LICENSE MANAGER
// ═════════════════════════════════════════════════════════════
const LicensesPlatformPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <PlatformHero icon="key" eyebrow="License Manager" onNav={onNav}
      title="Every plugin license,"
      gradient="every customer site, in one place."
      sub="Issue and manage licenses across all 11 WPistic products. Activate, revoke, transfer, and enforce — without writing a line of code."
      mock={<LicenseManagerMock />} />

    <MktSection eyebrow="Built for license management at scale"
      title="Stop emailing license keys. Start managing relationships.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {[
          { icon: 'key',     title: 'Activations & domains',    desc: 'Per-plan domain limits, automatic enforcement, and one-click transfer between sites.' },
          { icon: 'refresh', title: 'Renewals & expiry',         desc: 'Auto-renew, dunning, grace periods, and 30/14/3-day expiry alerts in email + dashboard.' },
          { icon: 'users',   title: 'Customer-facing portal',    desc: 'A clean license portal where your customers manage their own activations and downloads.' },
          { icon: 'shield',  title: 'Anti-piracy enforcement',   desc: 'Domain checks, signature validation, and automatic deactivation on abuse signals.' },
          { icon: 'card',    title: 'Stripe-native billing',     desc: 'Subscriptions, one-time, lifetime, and upgrade-with-proration — all backed by Stripe.' },
          { icon: 'zap',     title: 'Webhook events',            desc: 'license.activated, license.expired, license.transferred — wire to anything.' },
        ].map(f => <FeatureGridCard key={f.title} {...f} />)}
      </div>
    </MktSection>

    <MktSection bg="#F8F9FF" eyebrow="Built for" title="Who runs on License Manager">
      <UseCaseRow cases={[
        { icon: 'cube', title: 'Plugin businesses', desc: 'Sell your own WordPress plugins with proper licensing infrastructure.', outcome: '+22% renewal rate' },
        { icon: 'users', title: 'Agencies', desc: 'Issue per-client licenses, enforce activation limits, manage churn.', outcome: '−6 hrs/week ops' },
        { icon: 'spark', title: 'SaaS founders', desc: 'White-label license layer for your own WordPress SaaS products.', outcome: 'Ship in days, not months' },
      ]} />
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="Run your licensing like a real product business."
      sub="Issue and enforce licenses for every plugin you sell — included in every WPistic plan." />
  </MarketingPage>
);

// ═════════════════════════════════════════════════════════════
// AI AGENTS
// ═════════════════════════════════════════════════════════════
const AgentsPlatformPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <PlatformHero icon="bot" eyebrow="AI Agents · WPAgentistic" onNav={onNav}
      title="Drop-in AI agents"
      gradient="for every part of your business."
      sub="A growing library of pre-built agents — sales, support, SEO, booking, ops — that plug into your WordPress site and start working today."
      mock={<AgentLibraryMock />} />

    <MktSection eyebrow="Agent categories" title="The library you can launch from today">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {[
          { cat: 'Sales', icon: 'card', tone: 'green', items: ['Sales Agent Pro','Cart Recovery','Lead Qualifier','Upsell Concierge'] },
          { cat: 'Support', icon: 'help', tone: 'purple', items: ['Tier 1 Support','Ticket Triage','Order Status','Refund Helper'] },
          { cat: 'SEO', icon: 'search', tone: 'purple', items: ['SEO Research','Meta Rewriter','Content Brief','Keyword Cluster'] },
          { cat: 'Booking', icon: 'calendar', tone: 'green', items: ['Booking Assistant','Reschedule Bot','Tour Concierge','No-show Reducer'], glyph: true },
          { cat: 'WooCommerce', icon: 'cube', tone: 'green', items: ['Reorder Nudge','Cross-sell Bot','Review Gatherer','VIP Notifier'] },
          { cat: 'Operations', icon: 'cog', tone: 'purple', items: ['Inbox Summarizer','Onboarding Bot','Churn Risk','Daily Standup'] },
        ].map(cat => {
          const c = cat.tone === 'green' ? { bg: '#E8FAF0', fg: '#00C04B' } : { bg: '#F3F1FE', fg: '#6C5CE7' };
          return (
            <Card key={cat.cat} padding={22} hoverable>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
                <div style={{ width: 38, height: 38, borderRadius: 11, background: c.bg, color: c.fg, display: 'grid', placeItems: 'center' }}>
                  {cat.glyph ? <ProductGlyph name={cat.icon} color={c.fg} bg="transparent" size={20} radius={0} /> : <Icon name={cat.icon} size={18} />}
                </div>
                <div style={{ fontSize: 17, fontWeight: 700, color: '#0D0F1A' }}>{cat.cat}</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {cat.items.map(a => (
                  <div key={a} style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12.5, color: '#4B5263' }}>
                    <Icon name="bot" size={11} color={c.fg} />{a}
                  </div>
                ))}
              </div>
            </Card>
          );
        })}
      </div>
    </MktSection>

    <MktSection bg="#F8F9FF" eyebrow="Custom agents" title="Train an agent on your own data, your own brand.">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, alignItems: 'center' }}>
        <div>
          <p style={{ fontSize: 16, color: '#4B5263', lineHeight: 1.7, marginBottom: 18 }}>
            The agent studio is a no-code builder where you give an agent a name, a personality, a knowledge base, and a set of tools. Then point it at WhatsApp, web chat, email, or your CRM — and it goes to work.
          </p>
          {['Train on URLs, docs, PDFs, and product catalogs',
            'Give the agent tools: create cart, refund, book, escalate',
            'Pick the channel: web, WhatsApp, email, internal Slack',
            'Set guardrails: tone, banned topics, confidence handoff'].map(b => (
            <div key={b} style={{ display: 'flex', alignItems: 'flex-start', gap: 9, fontSize: 14, marginBottom: 9, color: '#0D0F1A' }}>
              <Icon name="check" size={15} color="#00C04B" strokeWidth={2.5} style={{ marginTop: 3, flexShrink: 0 }} />{b}
            </div>
          ))}
          <Btn variant="primary" size="md" rightIcon="arrow" style={{ marginTop: 20 }} onClick={() => onNav('register')}>Build a custom agent</Btn>
        </div>
        <AgentBuilderMock />
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="Hire your first AI employee this week."
      sub="Pre-built agents for every department, or build your own in the no-code studio." />
  </MarketingPage>
);

// ═════════════════════════════════════════════════════════════
// AUTOMATIONS
// ═════════════════════════════════════════════════════════════
const AutomationsPlatformPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <PlatformHero icon="zap" eyebrow="Automations" onNav={onNav}
      title="When this happens,"
      gradient="that should happen."
      sub="A visual workflow builder that plugs into every plugin event — orders, bookings, members, licenses, conversations — and triggers actions across every channel."
      mock={<AutomationBuilderMock />} />

    <MktSection eyebrow="Trigger library" title="Every event in your stack is a trigger.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        {[
          { cat: 'WooCommerce', events: ['Order created','Cart abandoned','Refund issued','Stock low'], tone: 'purple' },
          { cat: 'Memberistic', events: ['Member joined','Subscription paused','Renewal failed','Churn risk'], tone: 'green' },
          { cat: 'Bookingistic', events: ['Booking made','Booking cancelled','24h before','No-show'], tone: 'purple' },
          { cat: 'License Manager', events: ['License activated','Expires in 14d','Domain limit hit','Refunded'], tone: 'green' },
          { cat: 'CRMistic', events: ['Tag added','Status changed','Stage moved','Note added'], tone: 'purple' },
          { cat: 'Chatbotistic', events: ['New conversation','AI handoff','Resolved','Negative sentiment'], tone: 'green' },
          { cat: 'Insightistic', events: ['Traffic spike','Conversion drop','Top page change','Anomaly'], tone: 'purple' },
          { cat: 'Custom', events: ['Webhook','Schedule (cron)','REST API','Form submit'], tone: 'green' },
        ].map(g => {
          const c = g.tone === 'green' ? { bg: '#E8FAF0', fg: '#00C04B' } : { bg: '#F3F1FE', fg: '#6C5CE7' };
          return (
            <Card key={g.cat} padding={18}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: c.fg, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 12 }}>{g.cat}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                {g.events.map(e => (
                  <code key={e} style={{
                    fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
                    color: '#4B5263', background: '#F8F9FF',
                    padding: '4px 8px', borderRadius: 6,
                    border: '1px solid #EDEFF8',
                  }}>{e.toLowerCase().replace(/\s/g, '_')}</code>
                ))}
              </div>
            </Card>
          );
        })}
      </div>
    </MktSection>

    <MktSection bg="#F8F9FF" eyebrow="Action library" title="Triggers fire actions across every channel.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {[
          { i: 'chat',  l: 'Send WhatsApp' },
          { i: 'inbox', l: 'Send email' },
          { i: 'help',  l: 'Create ticket' },
          { i: 'users', l: 'Assign to team' },
          { i: 'card',  l: 'Issue refund' },
          { i: 'spark', l: 'Run AI agent' },
          { i: 'zap',   l: 'Webhook call' },
          { i: 'cog',   l: 'Update CRM' },
        ].map(a => (
          <div key={a.l} style={{
            padding: '14px 18px', background: '#fff', borderRadius: 12,
            border: '1px solid #EDEFF8', display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <div style={{ width: 32, height: 32, borderRadius: 9, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center' }}>
              <Icon name={a.i} size={15} />
            </div>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#0D0F1A' }}>{a.l}</span>
          </div>
        ))}
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="Run your business on rails."
      sub="Build automations once. Watch them earn revenue forever." />
  </MarketingPage>
);

// ═════════════════════════════════════════════════════════════
// INBOX
// ═════════════════════════════════════════════════════════════
const InboxPlatformPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <PlatformHero icon="inbox" eyebrow="Unified Inbox" onNav={onNav}
      title="One inbox. Every channel."
      gradient="Every customer. Every plugin."
      sub="WhatsApp, web chat, email, and support tickets — landing on one screen with full context from every WPistic product."
      mock={<InboxPreviewMock />} />

    <MktSection eyebrow="What you get" title="Inbox that knows the customer before you reply.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {[
          { icon: 'chat',   title: 'Every channel, one screen', desc: 'WhatsApp Cloud API, web chat, email, support tickets, social DMs — unified.' },
          { icon: 'spark',  title: 'AI suggested replies',       desc: 'Pre-drafted replies based on conversation history and product knowledge — one click to send.' },
          { icon: 'users',  title: 'Customer profile inline',     desc: 'Orders, bookings, memberships, LTV, tags — all on the right side of every conversation.' },
          { icon: 'zap',    title: 'AI handles, humans escalate', desc: 'AI takes Tier 1, hands off cleanly when confidence drops or sentiment turns negative.' },
          { icon: 'cog',    title: 'Routing & SLAs',              desc: 'Round-robin, skill-based, VIP routing — with SLAs by channel, team, or topic.' },
          { icon: 'help',   title: 'Internal notes',              desc: 'Tag teammates, leave private notes, attach docs — never seen by the customer.' },
        ].map(f => <FeatureGridCard key={f.title} {...f} />)}
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="Close the tabs. Open the inbox."
      sub="One screen for every channel and every customer." />
  </MarketingPage>
);

// ═════════════════════════════════════════════════════════════
// ANALYTICS
// ═════════════════════════════════════════════════════════════
const AnalyticsPlatformPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <PlatformHero icon="chart" eyebrow="Analytics · Insightistic" onNav={onNav}
      title="One dashboard"
      gradient="for the whole business."
      sub="GA4, Search Console, WooCommerce revenue, AI usage, automation runs, and license growth — stitched into a single fast canvas."
      mock={<AnalyticsDashboardMock />} />

    <MktSection eyebrow="Built-in dashboards" title="The reports your team actually opens.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {[
          { name: 'Revenue', sub: 'WooCommerce + Memberistic', icon: 'card' },
          { name: 'Traffic', sub: 'GA4 + Search Console', icon: 'globe' },
          { name: 'SEO', sub: 'Clicks, impressions, position', icon: 'search' },
          { name: 'AI usage', sub: 'Conversations, handoffs, deflection', icon: 'bot' },
          { name: 'Automation runs', sub: 'Success rate, attributed revenue', icon: 'zap' },
          { name: 'License growth', sub: 'New, churned, MRR by product', icon: 'key' },
        ].map(d => (
          <Card key={d.name} padding={22} hoverable>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <div style={{ width: 38, height: 38, borderRadius: 11, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center' }}>
                <Icon name={d.icon} size={18} />
              </div>
              <div>
                <div style={{ fontSize: 14.5, fontWeight: 700, color: '#0D0F1A' }}>{d.name}</div>
                <div style={{ fontSize: 11.5, color: '#6B7280' }}>{d.sub}</div>
              </div>
            </div>
            <svg viewBox="0 0 200 50" preserveAspectRatio="none" style={{ width: '100%', height: 40 }}>
              <path d="M0,40 C20,32 40,28 60,24 C80,20 100,18 120,14 C140,10 160,7 180,4 C190,3 200,2 200,2"
                fill="none" stroke="#6C5CE7" strokeWidth="2" />
            </svg>
          </Card>
        ))}
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="See your whole business on one screen."
      sub="Insightistic stitches every data source into one fast dashboard." />
  </MarketingPage>
);

// ═════════════════════════════════════════════════════════════
// DEVELOPERS
// ═════════════════════════════════════════════════════════════
const DevelopersPlatformPage = ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <PlatformHero icon="code" eyebrow="Developers" onNav={onNav}
      title="A modern API"
      gradient="for the WordPressistic stack."
      sub="JSON over HTTPS. Bearer tokens. Idempotent writes. Webhooks for every event. OpenAPI spec on GitHub."
      mock={<CodeBlockMock />} />

    <MktSection eyebrow="What you get" title="REST API, webhooks, OAuth, and event log.">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
        {[
          { icon: 'code',    title: 'REST API',     desc: 'CRUD across sites, products, licenses, contacts, automations, conversations, and bookings. 50,000 req/day on Business.' },
          { icon: 'zap',     title: 'Webhooks',     desc: 'Signed, idempotent, retried for 24 hours. license.activated, order.created, booking.created, agent.handoff and more.' },
          { icon: 'shield',  title: 'OAuth 2.0',    desc: 'Build apps that act on behalf of users with scoped access tokens. Standard authorization-code flow.' },
          { icon: 'refresh', title: 'Event log',    desc: 'Every API call, webhook delivery, and OAuth grant — visible in your dashboard, exportable, queryable.' },
        ].map(f => <FeatureGridCard key={f.title} {...f} />)}
      </div>
    </MktSection>

    <MktSection bg="#0D0F1A" eyebrow="Sample webhook" title="Every important event, delivered to your server.">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        <pre style={{
          background: '#0a0c14', color: '#D4D6E0', padding: 24, borderRadius: 14,
          fontSize: 12.5, fontFamily: 'JetBrains Mono, monospace',
          lineHeight: 1.7, margin: 0, border: '1px solid #1E2130', overflow: 'auto',
        }}>
{`{
  "event": "order.created",
  "id": "evt_8H2K_pQ9rT4",
  "created": "2026-05-26T11:42:18Z",
  "site": "shopglow.com",
  "data": {
    "order_id": 4218,
    "customer": "sarah@aurora.co",
    "amount": 15800,
    "currency": "USD",
    "items": [
      { "product": "aurora-pendant", "qty": 2 }
    ],
    "source": "chatbotistic.whatsapp"
  }
}`}
        </pre>
        <div style={{ color: '#fff' }}>
          <SectionLabel light>Event coverage</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {['license.activated','license.expired','site.connected','order.created','order.refunded','booking.created','booking.cancelled','automation.completed','automation.failed','agent.handoff','member.joined','member.churned'].map(e => (
              <code key={e} style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#4ED48A', background: '#13161F', padding: '5px 10px', borderRadius: 6 }}>{e}</code>
            ))}
          </div>
        </div>
      </div>
    </MktSection>

    <MktFinalCTA onNav={onNav}
      title="Build on top of WPistic."
      sub="Open API docs, OpenAPI spec, and Postman collection — all yours from day one."
      primaryLabel="Read API docs" secondaryLabel="Get API key" secondaryTarget="register" />
  </MarketingPage>
);

// ═════════════════════════════════════════════════════════════
// ECOSYSTEM SUBPAGES (Plugins, AI, Ops, Integrations)
// ═════════════════════════════════════════════════════════════
const makeEcosystemPage = (cfg) => ({ onNav }) => (
  <MarketingPage onNav={onNav}>
    <MktHero
      eyebrow={cfg.eyebrow}
      title={cfg.title}
      gradient={cfg.gradient}
      sub={cfg.sub}
      ctas={[
        <Btn key="s" size="xl" onClick={() => onNav('register')} rightIcon="arrow">Start free</Btn>,
        <Btn key="e" size="xl" variant="outline" onClick={() => onNav('ecosystem-overview')}>Ecosystem overview</Btn>,
      ]} />
    <MktSection eyebrow={cfg.gridLabel} title={cfg.gridTitle}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {cfg.items.map(it => <FeatureGridCard key={it.title} {...it} />)}
      </div>
    </MktSection>
    <MktFinalCTA onNav={onNav} title={cfg.ctaTitle} sub={cfg.ctaSub} />
  </MarketingPage>
);

const PluginsEcosystemPage = makeEcosystemPage({
  eyebrow: 'WordPress Plugins',
  title: 'The plugin building blocks',
  gradient: 'of the ecosystem.',
  sub: 'Memberistic, Bookingistic, Postistic, Travelistic — the WordPress plugins that turn your site into a real business.',
  gridLabel: 'Core plugins',
  gridTitle: 'Drop-in plugins for every WordPress site',
  items: [
    { icon: 'members', title: 'Memberistic',  desc: 'Memberships, subscriptions, gated content.', glyph: true },
    { icon: 'calendar', title: 'Bookingistic', desc: 'Appointments, classes, tours, deposits.', glyph: true },
    { icon: 'spark', title: 'Postistic',     desc: 'AI post scheduling, blog automation, social.' },
    { icon: 'inbox', title: 'Travelistic',   desc: 'Tours, itineraries, group travel, vouchers.', tone: 'green' },
    { icon: 'shield', title: 'FFListic',      desc: 'ATF Form 4473 + firearms compliance for WP.', tone: 'green' },
    { icon: 'shield', title: 'Verifyistic',   desc: 'ID verification + KYC for WordPress forms.', tone: 'green' },
  ],
  ctaTitle: 'Six plugins. One workspace.',
  ctaSub: 'Install them all from the WPistic dashboard with one click.',
});

const AIEcosystemPage = makeEcosystemPage({
  eyebrow: 'AI & Automation Tools',
  title: 'Practical AI for',
  gradient: 'real businesses.',
  sub: 'AI agents, multi-channel chat, and automation engines that do real work — not demos. Built specifically for WordPress.',
  gridLabel: 'AI products',
  gridTitle: 'The AI layer of the ecosystem',
  items: [
    { icon: 'inbox', title: 'Chatbotistic',  desc: 'AI WhatsApp, web chat, multi-channel inbox.', tone: 'green' },
    { icon: 'bot',   title: 'WPAgentistic',  desc: 'Agent marketplace + custom agent studio.', tone: 'green' },
    { icon: 'zap',   title: 'Automations',   desc: 'Visual workflows across every plugin and channel.' },
    { icon: 'spark', title: 'Postistic AI',  desc: 'AI-generated headers, schedules, social posts.' },
    { icon: 'chart', title: 'Insightistic AI', desc: 'AI-suggested meta titles, content briefs, alerts.', tone: 'green' },
    { icon: 'help',  title: 'Support AI',    desc: 'Ticket triage, priority scoring, auto-replies.' },
  ],
  ctaTitle: 'AI that earns its seat at the table.',
  ctaSub: 'Practical agents and automations — no hype, no demos that fall apart.',
});

const OpsEcosystemPage = makeEcosystemPage({
  eyebrow: 'Business Operations',
  title: 'The operations layer',
  gradient: 'of your business.',
  sub: 'CRM, licensing, analytics, support, and billing — the back-office your WordPress business needs to scale beyond the founder.',
  gridLabel: 'Operations products',
  gridTitle: 'Run your business, not just your site',
  items: [
    { icon: 'users', title: 'CRMistic',     desc: 'Unified CRM that knows every customer signal.' },
    { icon: 'key',   title: 'Licenseistic', desc: 'License keys, activations, domain enforcement.', tone: 'green' },
    { icon: 'chart', title: 'Insightistic', desc: 'Unified analytics across every data source.' },
    { icon: 'help',  title: 'Support',      desc: 'Tickets, KB, escalation, AI triage built-in.', tone: 'green' },
    { icon: 'card',  title: 'Billing',      desc: 'Stripe-native subscriptions, invoices, dunning.' },
    { icon: 'cog',   title: 'Settings',     desc: 'Team, roles, security, SSO, white-label.', tone: 'green' },
  ],
  ctaTitle: 'A back-office that scales with you.',
  ctaSub: 'Every plugin shares the same CRM, billing, analytics, and support layer.',
});

const IntegrationsEcosystemPage = makeEcosystemPage({
  eyebrow: 'Integrations',
  title: 'WPistic plays well',
  gradient: 'with everything.',
  sub: 'Native connections to the platforms you already use — WhatsApp Cloud, Stripe, GA4, Search Console, Slack, and Zapier.',
  gridLabel: 'Native integrations',
  gridTitle: 'Built-in. No middleware.',
  items: [
    { icon: 'chat', title: 'WhatsApp Cloud API', desc: 'Official Meta integration. Verified business profile.', tone: 'green' },
    { icon: 'card', title: 'Stripe',             desc: 'Subscriptions, invoices, dunning, refunds.' },
    { icon: 'chart', title: 'Google Analytics 4', desc: 'Events, audiences, conversion tracking.' },
    { icon: 'search', title: 'Search Console',   desc: 'Clicks, impressions, keyword ranking history.', tone: 'green' },
    { icon: 'external', title: 'Slack',          desc: 'Alerts, DMs, conversation handoffs to channels.' },
    { icon: 'zap', title: 'Zapier',              desc: 'Connect to 6,000+ apps via Zaps.', tone: 'green' },
  ],
  ctaTitle: 'Connect what you already have.',
  ctaSub: 'Native integrations on day one. Webhooks and REST API for everything else.',
});

// ─── Mocks ───────────────────────────────────────────────────
const LicenseManagerMock = () => (
  <Card padding={20} style={{ maxWidth: 500, marginLeft: 'auto' }}>
    {[
      { p: 'Chatbotistic', k: 'CB-8H2K-PQ9R-T4MV', d: 'shopglow.com', s: 'Active',  e: 'Mar 18, 2027' },
      { p: 'Memberistic',  k: 'ME-4F2J-KK8V-R1PX', d: 'theclub.co',   s: 'Active',  e: 'Sep 2, 2026' },
      { p: 'Bookingistic', k: 'BK-9P4M-XT2Q-Y8WK', d: 'wanderly.travel', s: 'Expiring',  e: 'Jun 8, 2026' },
    ].map((l, i) => (
      <div key={i} style={{ padding: '12px 0', borderBottom: i < 2 ? '1px solid #F0F2FF' : 'none', display: 'flex', alignItems: 'center', gap: 10 }}>
        <Badge tone={l.s === 'Expiring' ? 'amber' : 'green'} dot>{l.s}</Badge>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>{l.p}</div>
          <code style={{ fontSize: 10.5, fontFamily: 'JetBrains Mono, monospace', color: '#6B7280' }}>{l.k}</code>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 11.5, fontWeight: 600, color: '#5649CC' }}>{l.d}</div>
          <div style={{ fontSize: 10, color: '#9499BA' }}>Renews {l.e}</div>
        </div>
      </div>
    ))}
  </Card>
);

const AgentLibraryMock = () => (
  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, maxWidth: 460, marginLeft: 'auto' }}>
    {[
      { n: 'Sales Pro', t: 'Sales', c: '+1,248 conv.', tone: 'green' },
      { n: 'Tier 1 Support', t: 'Support', c: '412 tickets', tone: 'purple' },
      { n: 'Booking Asst.', t: 'Booking', c: '287 bookings', tone: 'green' },
      { n: 'SEO Research', t: 'SEO', c: 'Setup needed', tone: 'purple' },
    ].map(a => {
      const c = a.tone === 'green' ? { bg: '#E8FAF0', fg: '#00C04B' } : { bg: '#F3F1FE', fg: '#6C5CE7' };
      return (
        <Card key={a.n} padding={16} hoverable>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: c.bg, color: c.fg, display: 'grid', placeItems: 'center', marginBottom: 10 }}>
            <Icon name="bot" size={18} />
          </div>
          <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{a.n}</div>
          <div style={{ fontSize: 11, color: '#9499BA', fontWeight: 600 }}>{a.t}</div>
          <div style={{ fontSize: 10.5, color: c.fg, fontWeight: 700, marginTop: 6 }}>{a.c}</div>
        </Card>
      );
    })}
  </div>
);

const AgentBuilderMock = () => (
  <Card padding={22}>
    <SectionLabel>Custom agent · Studio</SectionLabel>
    <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A', marginBottom: 12 }}>Aurora Sales Agent</div>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {[
        { l: 'Knowledge', v: 'Product catalog (487 SKUs), shipping FAQ, 12 docs' },
        { l: 'Tools', v: 'create_cart · apply_discount · check_order · handoff' },
        { l: 'Channels', v: 'WhatsApp · Web chat · Email' },
        { l: 'Guardrails', v: 'No medical advice, no price negotiation under $80' },
      ].map(f => (
        <div key={f.l} style={{ padding: 11, background: '#F8F9FF', borderRadius: 10 }}>
          <div style={{ fontSize: 10.5, fontWeight: 700, color: '#9499BA', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{f.l}</div>
          <div style={{ fontSize: 12.5, color: '#0D0F1A', marginTop: 3, lineHeight: 1.45 }}>{f.v}</div>
        </div>
      ))}
    </div>
  </Card>
);

const AutomationBuilderMock = () => (
  <Card padding={20} style={{ maxWidth: 460, marginLeft: 'auto' }}>
    <SectionLabel>Cart recovery automation</SectionLabel>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {[
        { type: 'trigger', icon: 'card',  l: 'Cart abandoned · 15 min' },
        { type: 'wait',    icon: 'refresh', l: 'Wait 15 minutes' },
        { type: 'cond',    icon: 'help', l: 'If cart value > $50' },
        { type: 'action',  icon: 'chat', l: 'Send WhatsApp recovery message' },
        { type: 'wait',    icon: 'refresh', l: 'Wait 24 hours' },
        { type: 'action',  icon: 'inbox', l: 'Send email with 10% discount' },
      ].map((s, i) => {
        const cmap = {
          trigger: { bg: '#F3F1FE', fg: '#6C5CE7', label: 'TRIGGER' },
          wait:    { bg: '#FEF3C7', fg: '#92400E', label: 'WAIT' },
          cond:    { bg: '#DBEAFE', fg: '#1E40AF', label: 'IF' },
          action:  { bg: '#E8FAF0', fg: '#00C04B', label: 'DO' },
        }[s.type];
        return (
          <React.Fragment key={i}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 12px', background: '#fff',
              border: '1.5px solid ' + cmap.bg, borderRadius: 11,
            }}>
              <div style={{ width: 26, height: 26, borderRadius: 7, background: cmap.bg, color: cmap.fg, display: 'grid', placeItems: 'center' }}>
                <Icon name={s.icon} size={13} />
              </div>
              <code style={{ fontSize: 9.5, fontWeight: 800, color: cmap.fg, letterSpacing: '0.08em' }}>{cmap.label}</code>
              <span style={{ fontSize: 12.5, color: '#0D0F1A', fontWeight: 600, flex: 1 }}>{s.l}</span>
            </div>
            {i < 5 && <div style={{ width: 1.5, height: 8, background: '#E5E7F2', marginLeft: 25 }} />}
          </React.Fragment>
        );
      })}
    </div>
  </Card>
);

const InboxPreviewMock = () => (
  <Card padding={20} style={{ maxWidth: 500, marginLeft: 'auto' }}>
    {[
      { ch: 'WhatsApp',  who: 'Sarah Lin',    msg: 'Add 2, please.', t: '2m', tone: 'green', unread: 2 },
      { ch: 'Website',   who: 'Marcus Reed',  msg: 'Ship to Canada by Friday?', t: '11m', tone: 'purple', unread: 1 },
      { ch: 'Email',     who: 'Daniel Hoff',  msg: 'One question about day 3...', t: '34m', tone: 'amber', unread: 0 },
      { ch: 'WhatsApp',  who: 'Priya Shah',   msg: 'Thanks! Renewed.', t: '1h', tone: 'green', unread: 0 },
    ].map((c, i) => {
      const tones = { green: '#00C04B', purple: '#6C5CE7', amber: '#F59E0B' };
      return (
        <div key={i} style={{
          padding: '12px 0', borderBottom: i < 3 ? '1px solid #F0F2FF' : 'none',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <AvatarCircle name={c.who} size={34} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5 }}>
              <span style={{ fontWeight: 700, color: '#0D0F1A' }}>{c.who}</span>
              <span style={{ width: 4, height: 4, borderRadius: 9999, background: '#D4D6E0' }} />
              <span style={{ fontSize: 10.5, fontWeight: 700, color: tones[c.tone] }}>{c.ch}</span>
            </div>
            <div style={{ fontSize: 12, color: c.unread ? '#0D0F1A' : '#6B7280', fontWeight: c.unread ? 600 : 400, marginTop: 2 }}>{c.msg}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 10, color: '#9499BA' }}>{c.t}</div>
            {c.unread > 0 && (
              <span style={{ fontSize: 9.5, fontWeight: 800, color: '#fff', background: '#6C5CE7', borderRadius: 9999, padding: '1px 6px', display: 'inline-block', marginTop: 3 }}>{c.unread}</span>
            )}
          </div>
        </div>
      );
    })}
  </Card>
);

const CodeBlockMock = () => (
  <div style={{
    background: '#0D0F1A', color: '#D4D6E0', borderRadius: 16,
    padding: 22, fontSize: 12, fontFamily: 'JetBrains Mono, monospace',
    lineHeight: 1.7, maxWidth: 460, marginLeft: 'auto',
    boxShadow: '0 24px 60px rgba(108,92,231,0.20)', border: '1px solid #1E2130',
  }}>
    <div style={{ color: '#9499BA' }}># Create an automation</div>
    <div style={{ color: '#4ED48A' }}>curl https://api.wpistic.com/v1/automations \</div>
    <div>  -H <span style={{ color: '#F59E0B' }}>"Authorization: Bearer $KEY"</span> \</div>
    <div>  -d <span style={{ color: '#F59E0B' }}>'{'{'}<br />
      &nbsp;&nbsp;&nbsp;&nbsp;"name": "Cart recovery",<br />
      &nbsp;&nbsp;&nbsp;&nbsp;"trigger": "cart.abandoned",<br />
      &nbsp;&nbsp;&nbsp;&nbsp;"action": "chat.whatsapp"<br />
      &nbsp;&nbsp;{'}'}'</span>
    </div>
    <div style={{ color: '#9499BA', marginTop: 14 }}># Response</div>
    <div style={{ color: '#D4D6E0' }}>{'{'} <span style={{ color: '#6C5CE7' }}>"id"</span>: "auto_8H2K",</div>
    <div>  <span style={{ color: '#6C5CE7' }}>"status"</span>: <span style={{ color: '#4ED48A' }}>"active"</span> {'}'}</div>
  </div>
);

Object.assign(window, {
  LicensesPlatformPage, AgentsPlatformPage, AutomationsPlatformPage,
  InboxPlatformPage, AnalyticsPlatformPage, DevelopersPlatformPage,
  PluginsEcosystemPage, AIEcosystemPage, OpsEcosystemPage, IntegrationsEcosystemPage,
});
