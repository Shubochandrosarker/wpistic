// product-pages.jsx — 5 product detail pages (Chatbotistic, Memberistic, Bookingistic, Insightistic, CRMistic)

// ─── Reusable product page sections ───────────────────────────
const ProductHero = ({ product: p, headline, sub, onNav, mock }) => (
  <section style={{
    position: 'relative', overflow: 'hidden',
    background: 'linear-gradient(155deg, #F3F1FE 0%, #EEF0FF 60%, #E8FAF0 130%)',
    padding: '70px 36px 80px',
  }}>
    <div style={{
      position: 'absolute', top: -120, right: -120, width: 500, height: 500,
      background: `radial-gradient(circle, ${p.color}33, transparent 65%)`,
    }} />
    <div style={{
      maxWidth: 1240, margin: '0 auto', position: 'relative',
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'center',
    }}>
      <div>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10, padding: '6px 12px 6px 6px', background: '#fff', borderRadius: 9999, border: '1px solid #EDEFF8', boxShadow: '0 4px 14px rgba(108,92,231,0.08)' }}>
          <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={28} radius={8} />
          <span style={{ fontSize: 12.5, fontWeight: 700, color: '#0D0F1A' }}>{p.name}</span>
          <span style={{ fontSize: 11, color: '#9499BA' }}>· WPistic suite</span>
        </div>
        <h1 style={{
          fontSize: 56, fontWeight: 800, letterSpacing: '-0.035em',
          color: '#0D0F1A', lineHeight: 1.08, margin: '20px 0 18px', textWrap: 'balance',
        }}>{headline}</h1>
        <p style={{ fontSize: 17.5, color: '#4B5263', lineHeight: 1.6, marginBottom: 30, maxWidth: 520 }}>{sub}</p>
        <div style={{ display: 'flex', gap: 10 }}>
          <Btn size="xl" onClick={() => onNav('register')} rightIcon="arrow">Start free</Btn>
          <Btn size="xl" variant="outline" leftIcon="download">Install plugin</Btn>
        </div>
        <div style={{ display: 'flex', gap: 18, marginTop: 22, fontSize: 13, color: '#6B7280', fontWeight: 500 }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Icon name="check" size={14} color="#00C04B" strokeWidth={2.5} /> 14-day trial
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Icon name="check" size={14} color="#00C04B" strokeWidth={2.5} /> WordPress-native
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Icon name="check" size={14} color="#00C04B" strokeWidth={2.5} /> Connects to all WPistic plugins
          </span>
        </div>
      </div>
      <div>{mock}</div>
    </div>
  </section>
);

const FeatureRowAlt = ({ items }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 80 }}>
    {items.map((it, i) => (
      <div key={i} style={{
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center',
        direction: i % 2 === 0 ? 'ltr' : 'rtl',
      }}>
        <div style={{ direction: 'ltr' }}>
          <Badge tone={i % 2 === 0 ? 'purple' : 'green'} dot>{it.eyebrow}</Badge>
          <h3 style={{ fontSize: 34, fontWeight: 800, letterSpacing: '-0.025em', color: '#0D0F1A', lineHeight: 1.2, margin: '14px 0 14px', textWrap: 'balance' }}>{it.title}</h3>
          <p style={{ fontSize: 15.5, color: '#4B5263', lineHeight: 1.7, margin: '0 0 18px' }}>{it.body}</p>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {it.bullets.map(b => (
              <li key={b} style={{ display: 'flex', alignItems: 'flex-start', gap: 9, fontSize: 14, color: '#0D0F1A', marginBottom: 9, lineHeight: 1.5 }}>
                <Icon name="check" size={15} color="#00C04B" strokeWidth={2.5} style={{ marginTop: 3, flexShrink: 0 }} />{b}
              </li>
            ))}
          </ul>
        </div>
        <div style={{ direction: 'ltr' }}>{it.mock}</div>
      </div>
    ))}
  </div>
);

const UseCaseRow = ({ cases }) => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
    {cases.map(c => (
      <Card key={c.title} padding={26} hoverable>
        <div style={{ width: 42, height: 42, borderRadius: 11, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center', marginBottom: 16 }}>
          <Icon name={c.icon} size={20} />
        </div>
        <div style={{ fontSize: 17, fontWeight: 700, color: '#0D0F1A' }}>{c.title}</div>
        <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: '8px 0 14px', minHeight: 60 }}>{c.desc}</p>
        <div style={{ fontSize: 12, color: '#00C04B', fontWeight: 700, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{c.outcome}</div>
      </Card>
    ))}
  </div>
);

const PricingTeaser = ({ onNav }) => (
  <MktSection eyebrow="Included in your plan" title="Every WPistic plan includes this product." sub="From Free tier all the way through Agency — pricing scales by usage, not by product.">
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, maxWidth: 980, margin: '0 auto' }}>
      {[
        { name: 'Starter', price: '$15', desc: '3 sites · 1,000 AI conversations', cta: 'Start trial', highlight: false },
        { name: 'Business', price: '$39', desc: '15 sites · 50,000 AI conversations · all products', cta: 'Start trial', highlight: true },
        { name: 'Agency', price: '$99', desc: 'Unlimited sites · 250,000 conversations · white-label', cta: 'Start trial', highlight: false },
      ].map(p => (
        <Card key={p.name} padding={26} hoverable style={{ background: p.highlight ? '#0D0F1A' : '#fff', color: p.highlight ? '#fff' : '#0D0F1A' }}>
          {p.highlight && <Badge tone="green" dot>Recommended</Badge>}
          <div style={{ fontSize: 17, fontWeight: 700, marginTop: p.highlight ? 12 : 0 }}>{p.name}</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 8 }}>
            <span style={{ fontSize: 32, fontWeight: 800, letterSpacing: '-0.025em' }}>{p.price}</span>
            <span style={{ fontSize: 13, color: p.highlight ? '#9499BA' : '#9499BA' }}>/ mo annual</span>
          </div>
          <p style={{ fontSize: 13, color: p.highlight ? '#D4D6E0' : '#4B5263', margin: '10px 0 18px', lineHeight: 1.5 }}>{p.desc}</p>
          <Btn variant={p.highlight ? 'green' : 'primary'} size="sm" style={{ width: '100%', justifyContent: 'center' }} onClick={() => onNav('register')}>{p.cta}</Btn>
        </Card>
      ))}
    </div>
    <div style={{ textAlign: 'center', marginTop: 24 }}>
      <Btn variant="ghost" size="sm" onClick={() => onNav('pricing')} rightIcon="arrow">See full pricing</Btn>
    </div>
  </MktSection>
);

// ═════════════════════════════════════════════════════════════
// CHATBOTISTIC
// ═════════════════════════════════════════════════════════════
const ChatbotisticPage = ({ onNav }) => {
  const p = PRODUCTS.find(p => p.id === 'chatbotistic');
  return (
    <MarketingPage onNav={onNav}>
      <ProductHero product={p} onNav={onNav}
        headline="The AI inbox that sells, supports, and recovers carts."
        sub="AI WhatsApp, website chat, and email — unified for WordPress and WooCommerce. Trained on your store, handed off to humans when it matters."
        mock={<ChatPreviewLarge />} />

      {/* Trust strip */}
      <section style={{ padding: '28px 36px', background: '#fff', borderTop: '1px solid #F0F2FF', borderBottom: '1px solid #F0F2FF' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'flex', justifyContent: 'space-around', alignItems: 'center', gap: 32, flexWrap: 'wrap' }}>
          {[
            { v: '12,847', l: 'Stores using Chatbotistic' },
            { v: '84%',    l: 'AI deflection rate' },
            { v: '8.4×',   l: 'Average ROI in first 90 days' },
            { v: '4.9 ★',  l: 'WordPress.org rating' },
          ].map(s => (
            <div key={s.l} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 26, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.025em' }}>{s.v}</div>
              <div style={{ fontSize: 11.5, color: '#6B7280', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 4 }}>{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Core features */}
      <MktSection eyebrow="Core features" title="One inbox. Every channel. Built for WordPress."
        sub="Chatbotistic plugs into your WordPress site in 60 seconds and unifies WhatsApp, web chat, and email into one screen.">
        <FeatureRowAlt items={[
          {
            eyebrow: 'WhatsApp automation',
            title: 'Sell on the channel your customers actually live on.',
            body: 'Official WhatsApp Cloud API integration — send broadcasts, automate replies, recover carts, and confirm orders without leaving WordPress.',
            bullets: ['Verified WhatsApp Business profile', 'Cart-recovery and abandoned checkout flows', 'AI agent answers product, shipping, return questions', 'Hand off to your team with full context'],
            mock: <WhatsAppMock />,
          },
          {
            eyebrow: 'Website chatbot',
            title: 'A web chat that knows your store, not just FAQs.',
            body: "It reads your WooCommerce catalog, blog posts, and shipping policies. It can also create carts, apply discounts, and check order status — not just chat.",
            bullets: ['Embeds anywhere with one line of code', 'Trained on your products, pages, and policies', 'Cart actions: add to cart, apply discount, checkout', 'Mobile-optimized, no popups, no slowdown'],
            mock: <WebChatMock />,
          },
          {
            eyebrow: 'WooCommerce inbox',
            title: 'WooCommerce orders, refunds, and tracking in one tap.',
            body: 'Every conversation is enriched with the customer\'s order history, cart contents, and recent visits — so AI and humans answer with full context.',
            bullets: ['Order tracking and ETA from inside the chat', 'Process refunds and reorders without leaving', 'Auto-tag conversations by order, product, or value', 'VIP detection and priority routing'],
            mock: <WooInboxMock />,
          },
          {
            eyebrow: 'AI handoff to humans',
            title: 'AI when it works. Humans when they matter.',
            body: 'When confidence drops, sentiment turns negative, or the customer asks for a person — the AI hands off cleanly with a full summary.',
            bullets: ['Confidence-based auto-handoff', 'Negative-sentiment escalation', 'Round-robin assignment by team or skill', 'Internal notes never seen by customer'],
            mock: <HandoffMock />,
          },
        ]} />
      </MktSection>

      {/* Use cases */}
      <MktSection bg="#F8F9FF" eyebrow="Built for" title="Who Chatbotistic is for"
        sub="WooCommerce stores, agencies, and service businesses use Chatbotistic to convert more conversations.">
        <UseCaseRow cases={[
          { icon: 'card', title: 'Recover abandoned carts', desc: 'AI follows up on WhatsApp with personalized offers and the exact cart URL.', outcome: '+18% recovered revenue' },
          { icon: 'help', title: 'Deflect repeat support', desc: 'Shipping, returns, and order-status questions get instant answers — 24/7.', outcome: '−72% support tickets' },
          { icon: 'spark', title: 'Pre-sales conversion', desc: 'Answers product, sizing, and stock questions on the page that converts.', outcome: '+34% conversion rate' },
        ]} />
      </MktSection>

      <PricingTeaser onNav={onNav} />

      <MktSection bg="#F8F9FF" narrow eyebrow="FAQ" title="Common questions about Chatbotistic">
        <FAQList items={[
          { q: 'Do I need WhatsApp Business API access?', a: 'No — we onboard you onto official Meta WhatsApp Cloud API as part of setup. Most accounts are verified within 24 hours.' },
          { q: 'Will the AI know my products?', a: 'Yes. Chatbotistic auto-syncs your WooCommerce catalog, blog posts, pages, and shipping policies. It re-trains automatically when you update content.' },
          { q: 'Can I use my own OpenAI or Anthropic key?', a: 'Yes, on Business and above. Bring your own key and pay only for our orchestration layer.' },
          { q: 'Does it slow down my site?', a: 'No. The widget is < 24 KB gzipped and loads after page interactive. WordPress hooks are async by default.' },
          { q: 'How is this different from Intercom or Drift?', a: 'Chatbotistic is built specifically for WordPress and WooCommerce. It reads your catalog, processes refunds, and shares contacts with the rest of the WPistic ecosystem.' },
        ]} />
      </MktSection>

      <MktFinalCTA onNav={onNav}
        title="Start converting more conversations today."
        sub="Install Chatbotistic on your WordPress site in under 5 minutes. Free tier includes 100 AI conversations a month." />
    </MarketingPage>
  );
};

// ═════════════════════════════════════════════════════════════
// MEMBERISTIC
// ═════════════════════════════════════════════════════════════
const MemberisticPage = ({ onNav }) => {
  const p = PRODUCTS.find(p => p.id === 'memberistic');
  return (
    <MarketingPage onNav={onNav}>
      <ProductHero product={p} onNav={onNav}
        headline="Memberships, subscriptions, and gated content for WordPress."
        sub="Build a real recurring revenue engine on top of your WordPress site — without stitching together five plugins."
        mock={<MembershipPlansMock />} />

      <section style={{ padding: '28px 36px', background: '#fff', borderTop: '1px solid #F0F2FF', borderBottom: '1px solid #F0F2FF' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'flex', justifyContent: 'space-around', alignItems: 'center', gap: 32, flexWrap: 'wrap' }}>
          {[
            { v: '4,200+', l: 'Active membership sites' },
            { v: '$28M', l: 'Recurring revenue processed' },
            { v: '94%', l: 'Renewal rate (vs 84% industry)' },
            { v: '4.8★', l: 'Customer rating' },
          ].map(s => (
            <div key={s.l} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 26, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.025em' }}>{s.v}</div>
              <div style={{ fontSize: 11.5, color: '#6B7280', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 4 }}>{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      <MktSection eyebrow="Core features" title="Everything you need to run a membership business.">
        <FeatureRowAlt items={[
          {
            eyebrow: 'Plans & subscriptions',
            title: 'Flexible plans, real-world pricing.',
            body: 'Monthly, annual, lifetime, free trial, paid trial, family, group, founding-member — Memberistic handles every model you can dream up.',
            bullets: ['Monthly / quarterly / annual / lifetime', 'Free and paid trials with auto-conversion', 'Family and group seats with admin roles', 'Tiered upgrade and downgrade with proration'],
            mock: <PlanCardsMock />,
          },
          {
            eyebrow: 'Subscription management',
            title: 'Pause, resume, upgrade, downgrade — without losing the customer.',
            body: 'Members manage their own subscriptions from a beautiful dashboard. You keep the relationship, not the support ticket.',
            bullets: ['Self-serve cancel with retention offers', 'Pause subscription (up to 90 days)', 'Failed payment dunning + smart retry', 'Cohort-aware churn risk scoring'],
            mock: <SubMgmtMock />,
          },
          {
            eyebrow: 'Protected content',
            title: 'Gate any post, page, course, or download.',
            body: 'Drag-and-drop content gating works with Gutenberg, Elementor, Bricks, and every page builder. Drip-release courses by day or by plan.',
            bullets: ['Gate posts, pages, custom post types, files', 'Drip-release content by date or sign-up cohort', 'Per-plan visibility (Bronze sees A, Gold sees A+B)', 'Sneak-peek preview for non-members'],
            mock: <GatedContentMock />,
          },
          {
            eyebrow: 'Member dashboard',
            title: 'A members area that doesn\'t look like a 2014 WordPress theme.',
            body: 'A clean, modern member portal where your community can update payment info, redeem benefits, manage family seats, and access content.',
            bullets: ['Beautiful default theme, fully customizable', 'Family seat invites and management', 'Benefit and perk redemption tracking', 'Activity history and member-only feed'],
            mock: <MemberDashMock />,
          },
        ]} />
      </MktSection>

      <MktSection bg="#F8F9FF" eyebrow="Built for" title="Who Memberistic is for">
        <UseCaseRow cases={[
          { icon: 'spark', title: 'Online communities', desc: 'Paid Discord-style communities with content, events, and member-only chat.', outcome: 'Drive 80%+ renewal' },
          { icon: 'cube', title: 'Course creators', desc: 'Drip-release courses with cohorts, certificates, and built-in community.', outcome: '3× student completion' },
          { icon: 'card', title: 'Premium publishers', desc: 'Paywalled articles, members-only podcast feeds, and bundle subscriptions.', outcome: '+22% paid conversion' },
        ]} />
      </MktSection>

      <PricingTeaser onNav={onNav} />
      <MktFinalCTA onNav={onNav}
        title="Turn your audience into recurring revenue."
        sub="Start your membership site today with Memberistic — included in every WPistic plan." />
    </MarketingPage>
  );
};

// ═════════════════════════════════════════════════════════════
// BOOKINGISTIC
// ═════════════════════════════════════════════════════════════
const BookingisticPage = ({ onNav }) => {
  const p = PRODUCTS.find(p => p.id === 'bookingistic');
  return (
    <MarketingPage onNav={onNav}>
      <ProductHero product={p} onNav={onNav}
        headline="Bookings, appointments, classes, and tours — all in WordPress."
        sub="A unified booking system for service businesses, travel operators, fitness studios, and consultants. With deposits, reminders, and AI-powered confirmations built in."
        mock={<BookingCalendarMock />} />

      <MktSection eyebrow="Core features" title="One booking engine, every use case.">
        <FeatureRowAlt items={[
          {
            eyebrow: 'Service bookings',
            title: 'Appointments that don\'t double-book.',
            body: 'Staff availability, working hours, buffers between appointments, blackout days, holiday rules — handled. Real-time sync with Google, Outlook, and Apple calendars.',
            bullets: ['Multi-staff scheduling with skills + availability', 'Auto buffers between appointments', 'Real-time Google / Outlook / iCal sync', 'Customer self-reschedule and cancel'],
            mock: <BookingTypeMock title="Service" />,
          },
          {
            eyebrow: 'Classes & events',
            title: 'Sell seats, manage capacity, prevent no-shows.',
            body: 'Group classes, workshops, retreats, and recurring sessions with waitlists, drop-in passes, and credit packages.',
            bullets: ['Group capacity with automatic waitlists', 'Drop-in vs membership pricing', 'Credit packs (10-class punch cards etc.)', 'Recurring class series with exceptions'],
            mock: <BookingTypeMock title="Class" />,
          },
          {
            eyebrow: 'Travel & tours',
            title: 'Multi-day, multi-leg itineraries with deposits.',
            body: 'Built for travel operators — multi-day tours, group sizes, optional add-ons, partial deposits, and per-traveler details.',
            bullets: ['Multi-day itineraries with daily activities', 'Per-traveler details and add-ons', 'Partial deposits + balance reminders', 'Voucher PDFs and Apple Wallet passes'],
            mock: <BookingTypeMock title="Tour" />,
          },
          {
            eyebrow: 'Automated reminders',
            title: 'Reminders, confirmations, and follow-ups — on autopilot.',
            body: 'Bookingistic talks to Chatbotistic and Memberistic so confirmations and reminders go out via WhatsApp, SMS, and email automatically.',
            bullets: ['Triggered confirmations on booking', '24-hour and 1-hour reminders, multi-channel', 'Post-appointment review requests', 'Win-back flows for lapsed customers'],
            mock: <BookingRemindersMock />,
          },
        ]} />
      </MktSection>

      <MktSection bg="#F8F9FF" eyebrow="Built for" title="Who Bookingistic is for">
        <UseCaseRow cases={[
          { icon: 'users', title: 'Service businesses', desc: 'Salons, clinics, consultants, coaches — anyone selling appointments.', outcome: '−38% no-shows' },
          { icon: 'spark', title: 'Studios & gyms', desc: 'Yoga, pilates, fitness classes with passes and recurring schedules.', outcome: '+24% class fill rate' },
          { icon: 'globe', title: 'Tour operators', desc: 'Travel tours, retreats, multi-day experiences with deposits and add-ons.', outcome: '+$148 avg booking value' },
        ]} />
      </MktSection>

      <PricingTeaser onNav={onNav} />
      <MktFinalCTA onNav={onNav}
        title="Stop juggling Calendly, Bookly, and a spreadsheet."
        sub="One booking engine for every type of business, native to WordPress." />
    </MarketingPage>
  );
};

// ═════════════════════════════════════════════════════════════
// INSIGHTISTIC
// ═════════════════════════════════════════════════════════════
const InsightisticPage = ({ onNav }) => {
  const p = PRODUCTS.find(p => p.id === 'insightistic');
  return (
    <MarketingPage onNav={onNav}>
      <ProductHero product={p} onNav={onNav}
        headline="One analytics dashboard for every site you run."
        sub="GA4, Google Search Console, WooCommerce, AI usage, and automation runs — stitched into one dashboard. No more eight browser tabs."
        mock={<AnalyticsDashboardMock />} />

      <MktSection eyebrow="Connected sources" title="Everything that matters to your business, on one canvas.">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 36 }}>
          {[
            { name: 'Google Analytics 4', icon: 'chart', desc: 'Traffic, events, conversions, audiences.' },
            { name: 'Google Search Console', icon: 'search', desc: 'Clicks, impressions, position, keywords.' },
            { name: 'WooCommerce', icon: 'cube', desc: 'Revenue, AOV, products, refunds, COGS.' },
            { name: 'WPistic events', icon: 'spark', desc: 'AI conversations, automation runs, license activations.' },
          ].map(s => (
            <Card key={s.name} padding={22} hoverable>
              <div style={{ width: 38, height: 38, borderRadius: 11, background: '#F3F1FE', color: '#6C5CE7', display: 'grid', placeItems: 'center', marginBottom: 14 }}>
                <Icon name={s.icon} size={18} />
              </div>
              <div style={{ fontSize: 14.5, fontWeight: 700, color: '#0D0F1A' }}>{s.name}</div>
              <p style={{ fontSize: 12.5, color: '#4B5263', lineHeight: 1.55, margin: '6px 0 0' }}>{s.desc}</p>
            </Card>
          ))}
        </div>
      </MktSection>

      <MktSection bg="#F8F9FF" eyebrow="Built-in reports" title="The reports your team actually opens.">
        <FeatureRowAlt items={[
          {
            eyebrow: 'Revenue reports',
            title: 'Revenue, AOV, and product performance in one view.',
            body: 'See which products drive revenue, which channels convert, and which days under-perform — without writing a single SQL query.',
            bullets: ['Top products by revenue, units, and margin', 'Channel attribution (search, social, direct, AI)', 'Cohort revenue and customer LTV', 'Refund and chargeback monitoring'],
            mock: <RevenueReportMock />,
          },
          {
            eyebrow: 'SEO + Search Console',
            title: 'Find the keywords almost converting.',
            body: 'Insightistic clusters Search Console keywords by intent, flags pages with high impressions but low CTR, and surfaces meta-title rewrites worth doing.',
            bullets: ['Keyword clusters by intent and product', 'High-impression / low-CTR opportunity list', 'AI-suggested meta title and description rewrites', 'Track ranking history and ranking changes'],
            mock: <SEOReportMock />,
          },
        ]} />
      </MktSection>

      <PricingTeaser onNav={onNav} />
      <MktFinalCTA onNav={onNav}
        title="Close the dashboard tabs. Open one."
        sub="Insightistic stitches every data source you care about into one fast, beautiful workspace." />
    </MarketingPage>
  );
};

// ═════════════════════════════════════════════════════════════
// CRMISTIC
// ═════════════════════════════════════════════════════════════
const CrmisticPage = ({ onNav }) => {
  const p = PRODUCTS.find(p => p.id === 'crmistic');
  return (
    <MarketingPage onNav={onNav}>
      <ProductHero product={p} onNav={onNav}
        headline="The CRM that actually knows your WordPress customers."
        sub="Every chat, booking, order, member, and page view — automatically attached to one contact. Pipeline, follow-ups, and automation included."
        mock={<CRMTimelineMock />} />

      <MktSection eyebrow="Core features" title="A real CRM, not a spreadsheet with rounded corners.">
        <FeatureRowAlt items={[
          {
            eyebrow: 'Unified contacts',
            title: 'One contact. Every signal. No duplicates.',
            body: 'Chatbotistic, Memberistic, Bookingistic, WooCommerce — every interaction lands on one contact card automatically. No CSV imports, no Zaps.',
            bullets: ['Auto-merge across email, phone, and WhatsApp', 'Custom fields with conditional visibility', 'Tag and segment by behavior and product', 'Visual pipeline and kanban'],
            mock: <ContactCardMock />,
          },
          {
            eyebrow: 'Customer timeline',
            title: 'See the whole story — in one scroll.',
            body: 'Every chat, page view, order, booking, and email — laid out on a beautiful timeline, in real time, with full context.',
            bullets: ['Cross-channel timeline (chat, email, web, order)', 'Internal notes and team @mentions', 'Calls and meeting notes inline', 'Filter timeline by source or date'],
            mock: <TimelineDetailMock />,
          },
          {
            eyebrow: 'Tasks & follow-ups',
            title: 'Don\'t forget the follow-up that closes the deal.',
            body: 'Auto-create tasks from automations, AI suggestions, or manually. Owner, due date, priority, reminders — the basics, but done well.',
            bullets: ['Auto-tasks from automations and AI', 'Owner, due date, priority, and reminders', 'Kanban board for sales pipelines', 'Email + Slack reminders for overdue tasks'],
            mock: <TasksMock />,
          },
        ]} />
      </MktSection>

      <MktSection bg="#F8F9FF" eyebrow="Built for" title="Who CRMistic is for">
        <UseCaseRow cases={[
          { icon: 'spark', title: 'Service businesses', desc: 'Track leads from form to first appointment to repeat customer.', outcome: '+28% lead-to-booking' },
          { icon: 'cube', title: 'Ecommerce', desc: 'VIP segmentation, win-back, and retention flows powered by purchase data.', outcome: '+41% repeat purchase' },
          { icon: 'users', title: 'Agencies', desc: 'Manage every client and every contact across every site, from one CRM.', outcome: '−4 hrs/week per client' },
        ]} />
      </MktSection>

      <PricingTeaser onNav={onNav} />
      <MktFinalCTA onNav={onNav}
        title="A CRM that fills itself in."
        sub="Stop copy-pasting from WooCommerce. Let CRMistic do the data entry." />
    </MarketingPage>
  );
};

// ─── Lightweight visual mocks (don't need to be perfect) ─────
const ChatPreviewLarge = () => (
  <div style={{
    background: '#fff', borderRadius: 22, padding: 22,
    boxShadow: '0 24px 70px rgba(108,92,231,0.22)', border: '1px solid #EDEFF8',
    maxWidth: 460, marginLeft: 'auto',
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingBottom: 14, borderBottom: '1px solid #F0F2FF', marginBottom: 14 }}>
      <div style={{ width: 36, height: 36, borderRadius: 9, background: 'linear-gradient(135deg, #25D366, #128C7E)', color: '#fff', display: 'grid', placeItems: 'center', fontSize: 14, fontWeight: 800 }}>W</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>WhatsApp · ShopGlow</div>
        <div style={{ fontSize: 11, color: '#00C04B', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <span style={{ width: 6, height: 6, background: '#00C04B', borderRadius: 9999 }} />AI online
        </div>
      </div>
      <Badge tone="purple">Cart $158</Badge>
    </div>
    <FakeChatPreview />
    <div style={{ marginTop: 16, padding: 12, background: 'linear-gradient(120deg, #F3F1FE, #E8FAF0)', borderRadius: 12, border: '1px solid #E9E6FD', display: 'flex', alignItems: 'flex-start', gap: 10 }}>
      <div style={{ width: 26, height: 26, borderRadius: 7, background: '#fff', color: '#6C5CE7', display: 'grid', placeItems: 'center' }}><Icon name="spark" size={13} /></div>
      <div style={{ flex: 1, fontSize: 12, color: '#0D0F1A' }}>
        <div style={{ fontWeight: 700, marginBottom: 2 }}>AI Sales Agent Pro</div>
        Converted from inquiry → $158 cart in 3 messages.
      </div>
    </div>
  </div>
);

const WhatsAppMock = () => (
  <Card padding={20} style={{ background: 'linear-gradient(165deg, #ECE5DD, #DCD5C9)' }}>
    {[
      { side: 'them', t: "Hi! Is the Aurora pendant in stock?", time: '11:38' },
      { side: 'us',   t: "Yes — 12 in stock. Free shipping over $80, delivered Wed–Fri.", time: '11:38' },
      { side: 'them', t: "Add one to my cart please.", time: '11:39' },
      { side: 'us',   t: "✓ Added. Cart total: $79. One more for free shipping? Want the matching wall sconce?", time: '11:39' },
    ].map((m, i) => (
      <div key={i} style={{
        display: 'flex', justifyContent: m.side === 'us' ? 'flex-end' : 'flex-start', marginBottom: 6,
      }}>
        <div style={{
          maxWidth: '75%', padding: '7px 11px', borderRadius: 8,
          background: m.side === 'us' ? '#DCF8C6' : '#fff',
          fontSize: 12, color: '#111', lineHeight: 1.45,
          boxShadow: '0 1px 0 rgba(0,0,0,0.04)',
        }}>{m.t}
          <div style={{ fontSize: 9, color: '#999', textAlign: 'right', marginTop: 2 }}>{m.time} ✓✓</div>
        </div>
      </div>
    ))}
  </Card>
);

const WebChatMock = () => (
  <div style={{ position: 'relative', height: 380 }}>
    <div style={{
      position: 'absolute', right: 0, bottom: 0, width: 340,
      background: '#fff', borderRadius: 20, overflow: 'hidden',
      boxShadow: '0 20px 50px rgba(108,92,231,0.20)', border: '1px solid #EDEFF8',
    }}>
      <div style={{
        padding: '14px 18px', background: 'linear-gradient(135deg, #6C5CE7, #5649CC)',
        color: '#fff',
      }}>
        <div style={{ fontSize: 14, fontWeight: 700 }}>ShopGlow Assistant</div>
        <div style={{ fontSize: 11, opacity: 0.85, display: 'inline-flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 6, height: 6, background: '#4ED48A', borderRadius: 9999 }} />Online · replies in seconds
        </div>
      </div>
      <div style={{ padding: '14px 18px', background: '#F8F9FF', minHeight: 240 }}>
        <div style={{ background: '#fff', padding: '10px 12px', borderRadius: 12, fontSize: 12.5, color: '#0D0F1A', marginBottom: 10, maxWidth: '85%' }}>
          Hi! I can help with products, orders, shipping, or returns. What are you looking for?
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
          {['Browse products', 'Track my order', 'Return policy'].map(c => (
            <span key={c} style={{ fontSize: 11.5, fontWeight: 600, color: '#5649CC', background: '#F3F1FE', padding: '6px 10px', borderRadius: 9999, cursor: 'pointer' }}>{c}</span>
          ))}
        </div>
      </div>
      <div style={{ padding: '10px 14px', borderTop: '1px solid #F0F2FF', display: 'flex', gap: 8, alignItems: 'center' }}>
        <input placeholder="Type a message…" style={{ flex: 1, border: 'none', outline: 'none', fontSize: 12.5, fontFamily: 'inherit' }} />
        <div style={{ width: 28, height: 28, borderRadius: 7, background: '#6C5CE7', color: '#fff', display: 'grid', placeItems: 'center' }}><Icon name="arrow" size={13} /></div>
      </div>
    </div>
  </div>
);

const WooInboxMock = () => (
  <Card padding={22}>
    <div style={{ display: 'flex', gap: 10, alignItems: 'center', paddingBottom: 14, borderBottom: '1px solid #F0F2FF', marginBottom: 14 }}>
      <AvatarCircle name="Sarah Lin" size={36} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>Sarah Lin</div>
        <div style={{ fontSize: 11.5, color: '#6B7280' }}>VIP · 11 orders · $2,840 LTV</div>
      </div>
      <Badge tone="green" dot>VIP</Badge>
    </div>
    <div style={{ marginBottom: 12 }}>
      <SectionLabel>Recent orders</SectionLabel>
      {[
        { id: '#4218', d: '$158 · Just now',  prod: 'Aurora pendant ×2' },
        { id: '#4096', d: '$284 · Apr 28',    prod: 'Velvet armchair' },
        { id: '#3940', d: '$96 · Apr 12',     prod: 'Marble side table' },
      ].map(o => (
        <div key={o.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #F8F9FF', fontSize: 12 }}>
          <div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', color: '#5649CC', fontWeight: 700 }}>{o.id}</div>
            <div style={{ color: '#6B7280', fontSize: 11 }}>{o.prod}</div>
          </div>
          <div style={{ color: '#0D0F1A', fontWeight: 600 }}>{o.d.split(' · ')[0]}</div>
        </div>
      ))}
    </div>
    <Btn variant="primary" size="sm" rightIcon="arrow" style={{ width: '100%', justifyContent: 'center' }}>Open in WooCommerce</Btn>
  </Card>
);

const HandoffMock = () => (
  <Card padding={22}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', borderRadius: 11, background: '#FEF3C7', border: '1px solid #FCD34D', marginBottom: 12 }}>
      <Icon name="warn" size={16} color="#92400E" />
      <div style={{ flex: 1, fontSize: 12.5, color: '#78350F' }}>
        <strong>AI confidence dropped to 64%</strong> · Customer asking about custom installation pricing.
      </div>
    </div>
    <div style={{ padding: 12, background: '#F3F1FE', borderRadius: 11, marginBottom: 12 }}>
      <SectionLabel>AI summary for handoff</SectionLabel>
      <div style={{ fontSize: 12.5, color: '#2E3245', lineHeight: 1.6 }}>
        Sarah (VIP, $2.8k LTV) wants Aurora pendants installed in NY. Needs quote for 4 lamps + installer recommendations.
      </div>
    </div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <AvatarCircle name="Marcus Reed" size={32} />
      <div style={{ flex: 1, fontSize: 12 }}>
        <div style={{ fontWeight: 700, color: '#0D0F1A' }}>Marcus Reed picked up</div>
        <div style={{ color: '#6B7280' }}>Typing reply…</div>
      </div>
      <Badge tone="green" dot>Live</Badge>
    </div>
  </Card>
);

const MembershipPlansMock = () => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, maxWidth: 500, marginLeft: 'auto' }}>
    {[
      { name: 'Bronze',  price: '$9',  feat: ['Articles','Community'], pop: false },
      { name: 'Gold',    price: '$29', feat: ['All Bronze','Courses','Weekly call'], pop: true },
      { name: 'Founder', price: '$99', feat: ['All Gold','1:1 mentor','Forum badge'], pop: false },
    ].map(p => (
      <div key={p.name} style={{
        background: p.pop ? '#0D0F1A' : '#fff', color: p.pop ? '#fff' : '#0D0F1A',
        borderRadius: 16, padding: 16, border: p.pop ? '1px solid #1E2130' : '1px solid #EDEFF8',
        boxShadow: p.pop ? '0 16px 40px rgba(108,92,231,0.25)' : '0 4px 14px rgba(108,92,231,0.06)',
        transform: p.pop ? 'translateY(-12px)' : 'none',
      }}>
        {p.pop && <Badge tone="green" dot>Popular</Badge>}
        <div style={{ fontSize: 14, fontWeight: 700, marginTop: p.pop ? 10 : 0 }}>{p.name}</div>
        <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-0.02em', marginTop: 6 }}>{p.price}<span style={{ fontSize: 11, color: '#9499BA' }}>/mo</span></div>
        <div style={{ marginTop: 10, paddingTop: 10, borderTop: p.pop ? '1px solid #1E2130' : '1px solid #F0F2FF' }}>
          {p.feat.map(f => (
            <div key={f} style={{ fontSize: 11, color: p.pop ? '#D4D6E0' : '#4B5263', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 5 }}>
              <Icon name="check" size={11} color={p.pop ? '#4ED48A' : '#00C04B'} strokeWidth={2.5} />{f}
            </div>
          ))}
        </div>
      </div>
    ))}
  </div>
);

const PlanCardsMock = () => (
  <Card padding={22}>
    <SectionLabel>Plan editor</SectionLabel>
    <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A', marginBottom: 14 }}>Gold annual + free trial</div>
    {[
      { l: 'Price',    v: '$290 / year' },
      { l: 'Trial',    v: '14 days free' },
      { l: 'Includes', v: 'Monthly call, courses, community' },
      { l: 'Renewal',  v: 'Auto · 7-day reminder' },
    ].map(r => (
      <div key={r.l} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #F0F2FF', fontSize: 12.5 }}>
        <span style={{ color: '#6B7280' }}>{r.l}</span>
        <span style={{ color: '#0D0F1A', fontWeight: 600 }}>{r.v}</span>
      </div>
    ))}
  </Card>
);

const SubMgmtMock = () => (
  <Card padding={22}>
    <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A', marginBottom: 4 }}>Priya Shah · Gold annual</div>
    <div style={{ fontSize: 12, color: '#6B7280', marginBottom: 16 }}>Renews Mar 18, 2027</div>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
      <Btn variant="border-card" size="sm">Pause</Btn>
      <Btn variant="border-card" size="sm">Upgrade</Btn>
      <Btn variant="border-card" size="sm">Switch plan</Btn>
      <Btn variant="ghost-gray" size="sm">Cancel</Btn>
    </div>
    <div style={{ marginTop: 14, padding: 12, background: '#FEF3C7', borderRadius: 10, fontSize: 12, color: '#78350F' }}>
      ⚠️ Last payment failed. Card ending 4242 — retry scheduled in 3 days.
    </div>
  </Card>
);

const GatedContentMock = () => (
  <Card padding={22}>
    {[
      { t: 'How to launch your community in 30 days', plan: 'All members', open: true },
      { t: 'Advanced retention playbook', plan: 'Gold +', open: false },
      { t: 'Founder Q&A: pricing your membership', plan: 'Founder only', open: false },
    ].map((c, i) => (
      <div key={i} style={{ padding: '12px 0', borderBottom: i < 2 ? '1px solid #F0F2FF' : 'none' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Icon name={c.open ? 'check' : 'shield'} size={16} color={c.open ? '#00C04B' : '#6C5CE7'} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: '#0D0F1A' }}>{c.t}</div>
            <div style={{ fontSize: 11, color: '#9499BA' }}>{c.plan}</div>
          </div>
        </div>
      </div>
    ))}
  </Card>
);

const MemberDashMock = () => (
  <Card padding={22}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingBottom: 12, borderBottom: '1px solid #F0F2FF', marginBottom: 14 }}>
      <AvatarCircle name="Priya Shah" size={40} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A' }}>Welcome, Priya</div>
        <div style={{ fontSize: 11.5, color: '#6B7280' }}>Gold member since Jun 2025</div>
      </div>
      <Badge tone="green" dot>284 days</Badge>
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 14 }}>
      {[
        { l: 'Courses', v: '4/12' },
        { l: 'Calls attended', v: '11' },
      ].map(s => (
        <div key={s.l} style={{ padding: 12, background: '#F8F9FF', borderRadius: 10 }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: '#0D0F1A' }}>{s.v}</div>
          <div style={{ fontSize: 10.5, color: '#9499BA', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{s.l}</div>
        </div>
      ))}
    </div>
    <Btn variant="ghost" size="sm" rightIcon="arrow">Continue: Module 5</Btn>
  </Card>
);

const BookingCalendarMock = () => (
  <Card padding={22} style={{ maxWidth: 460, marginLeft: 'auto' }}>
    <SectionLabel>Book a session · Yoga studio</SectionLabel>
    <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A', marginBottom: 14 }}>Vinyasa Flow · 60 min · $24</div>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 5, marginBottom: 14 }}>
      {['M','T','W','T','F','S','S'].map(d => (
        <div key={d+Math.random()} style={{ fontSize: 10, fontWeight: 700, color: '#9499BA', textAlign: 'center' }}>{d}</div>
      ))}
      {[24,25,26,27,28,29,30].map((d, i) => (
        <div key={d} style={{
          padding: '10px 0', borderRadius: 9, textAlign: 'center', fontSize: 13,
          fontWeight: i === 2 ? 800 : 600,
          background: i === 2 ? '#6C5CE7' : '#F8F9FF',
          color: i === 2 ? '#fff' : i === 5 ? '#9499BA' : '#0D0F1A',
          cursor: 'pointer',
        }}>{d}</div>
      ))}
    </div>
    <SectionLabel>Available · Wed May 26</SectionLabel>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
      {['7:00','8:30','10:00','17:30','19:00','20:00'].map((s, i) => (
        <div key={s} style={{
          padding: '8px 0', textAlign: 'center', fontSize: 12, fontWeight: 600,
          borderRadius: 9, border: i === 3 ? '1.5px solid #6C5CE7' : '1px solid #EDEFF8',
          background: i === 3 ? '#F3F1FE' : '#fff', color: i === 3 ? '#5649CC' : '#4B5263',
          cursor: 'pointer',
        }}>{s}</div>
      ))}
    </div>
    <Btn variant="primary" size="sm" rightIcon="arrow" style={{ width: '100%', justifyContent: 'center', marginTop: 14 }}>Book 17:30 — $24</Btn>
  </Card>
);

const BookingTypeMock = ({ title }) => (
  <Card padding={22}>
    <SectionLabel>{title} booking</SectionLabel>
    <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A', marginBottom: 12 }}>
      {title === 'Service' ? 'Hair color · Sarah · 90 min'
        : title === 'Class' ? 'Vinyasa flow · Group of 14'
        : 'Highland tour · 4 days, 6 people'}
    </div>
    {[
      ['Date',    title === 'Tour' ? 'Jun 12 – Jun 15' : 'Wed May 26 · 17:30'],
      ['Staff',   title === 'Service' ? 'Sarah Patel' : title === 'Class' ? 'Maya · Studio A' : '2 guides included'],
      ['Capacity', title === 'Service' ? '1 / 1 slot' : title === 'Class' ? '14 / 20 booked' : '6 / 8 spots'],
      ['Total',   title === 'Tour' ? '$1,290 · $300 deposit' : title === 'Class' ? '$24' : '$148'],
    ].map(r => (
      <div key={r[0]} style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: '1px solid #F0F2FF', fontSize: 12.5 }}>
        <span style={{ color: '#6B7280' }}>{r[0]}</span>
        <span style={{ color: '#0D0F1A', fontWeight: 600 }}>{r[1]}</span>
      </div>
    ))}
  </Card>
);

const BookingRemindersMock = () => (
  <Card padding={22}>
    <SectionLabel>Booking automation</SectionLabel>
    <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A', marginBottom: 14 }}>Highland tour · 4-day itinerary</div>
    {[
      { when: 'On booking',    ch: 'Email + WhatsApp', what: 'Booking confirmation + voucher', done: true },
      { when: '7 days before', ch: 'Email',            what: 'Itinerary + packing list', done: true },
      { when: '24 hrs before', ch: 'WhatsApp',         what: 'Reminder + pickup time', done: false },
      { when: 'Day of',        ch: 'SMS',              what: '30-min arrival check-in', done: false },
      { when: '3 days after',  ch: 'WhatsApp',         what: 'Review request + photo album', done: false },
    ].map((r, i) => (
      <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: i < 4 ? '1px solid #F0F2FF' : 'none' }}>
        <div style={{ width: 18, height: 18, borderRadius: 9999, background: r.done ? '#00C04B' : '#E5E7F2', color: '#fff', display: 'grid', placeItems: 'center' }}>
          {r.done && <Icon name="check" size={11} strokeWidth={3} />}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: '#0D0F1A' }}>{r.what}</div>
          <div style={{ fontSize: 11, color: '#9499BA' }}>{r.when} · {r.ch}</div>
        </div>
      </div>
    ))}
  </Card>
);

const AnalyticsDashboardMock = () => (
  <Card padding={20} style={{ maxWidth: 500, marginLeft: 'auto' }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
      <SectionLabel>Last 30 days</SectionLabel>
      <Badge tone="green" dot>+24%</Badge>
    </div>
    <div style={{ fontSize: 28, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.025em' }}>$48,902</div>
    <div style={{ fontSize: 12, color: '#6B7280', marginBottom: 14 }}>Revenue · all sites</div>
    <svg viewBox="0 0 400 100" preserveAspectRatio="none" style={{ width: '100%', height: 100 }}>
      <defs>
        <linearGradient id="adGrad" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="#6C5CE7" stopOpacity="0.30" />
          <stop offset="100%" stopColor="#6C5CE7" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d="M0,80 C40,70 80,55 120,52 C160,48 200,38 240,32 C280,26 320,20 360,12 C380,8 400,5 400,5 L400,100 L0,100 Z" fill="url(#adGrad)" />
      <path d="M0,80 C40,70 80,55 120,52 C160,48 200,38 240,32 C280,26 320,20 360,12 C380,8 400,5 400,5" fill="none" stroke="#6C5CE7" strokeWidth="2.5" />
    </svg>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 14 }}>
      {[
        { l: 'Visitors', v: '28.2k', t: '+18%' },
        { l: 'Conv.', v: '3.4%', t: '+0.6pt' },
        { l: 'AOV', v: '$96', t: '+4%' },
      ].map(s => (
        <div key={s.l} style={{ padding: 10, background: '#F8F9FF', borderRadius: 8 }}>
          <div style={{ fontSize: 10, color: '#9499BA', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{s.l}</div>
          <div style={{ fontSize: 15, fontWeight: 800, color: '#0D0F1A', marginTop: 2 }}>{s.v}</div>
          <div style={{ fontSize: 10, color: '#00C04B', fontWeight: 700 }}>↑ {s.t}</div>
        </div>
      ))}
    </div>
  </Card>
);

const RevenueReportMock = () => (
  <Card padding={22}>
    <SectionLabel>Top products this month</SectionLabel>
    {[
      { n: 'Aurora pendant',  r: '$8,420', p: 80 },
      { n: 'Velvet armchair', r: '$6,180', p: 60 },
      { n: 'Marble table',    r: '$3,470', p: 36 },
      { n: 'Linen throw',     r: '$1,890', p: 22 },
    ].map(p => (
      <div key={p.n} style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
          <span style={{ fontWeight: 600, color: '#0D0F1A' }}>{p.n}</span>
          <span style={{ color: '#6B7280' }}>{p.r}</span>
        </div>
        <div style={{ height: 6, background: '#F0F2FF', borderRadius: 9999, overflow: 'hidden' }}>
          <div style={{ width: p.p + '%', height: '100%', background: 'linear-gradient(90deg, #6C5CE7, #00C04B)' }} />
        </div>
      </div>
    ))}
  </Card>
);

const SEOReportMock = () => (
  <Card padding={22}>
    <SectionLabel>High impressions, low CTR</SectionLabel>
    <div style={{ fontSize: 11, color: '#6B7280', marginBottom: 12 }}>Rewrite candidates · 30 days</div>
    {[
      { kw: 'matte black pendant light', imp: '24k', ctr: '0.8%', rec: 'Rewrite title' },
      { kw: 'aurora lighting brand',     imp: '18k', ctr: '1.2%', rec: 'Add CTA' },
      { kw: 'wall sconce ideas',         imp: '12k', ctr: '0.6%', rec: 'Improve meta' },
    ].map((k, i) => (
      <div key={i} style={{ padding: '10px 0', borderBottom: i < 2 ? '1px solid #F0F2FF' : 'none' }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: '#0D0F1A' }}>{k.kw}</div>
        <div style={{ display: 'flex', gap: 14, fontSize: 11, color: '#6B7280', marginTop: 3 }}>
          <span>{k.imp} impr.</span><span>CTR {k.ctr}</span>
          <Badge tone="purple">{k.rec}</Badge>
        </div>
      </div>
    ))}
  </Card>
);

const CRMTimelineMock = () => (
  <Card padding={22} style={{ maxWidth: 480, marginLeft: 'auto' }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, paddingBottom: 14, borderBottom: '1px solid #F0F2FF', marginBottom: 16 }}>
      <AvatarCircle name="Sarah Lin" size={44} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>Sarah Lin</div>
        <div style={{ fontSize: 12, color: '#6B7280' }}>VIP · $2,840 LTV · 11 orders</div>
      </div>
      <Badge tone="green" dot>Customer</Badge>
    </div>
    <div style={{ position: 'relative', paddingLeft: 20 }}>
      <div style={{ position: 'absolute', left: 9, top: 6, bottom: 6, width: 1.5, background: '#E9E6FD' }} />
      {[
        { i: 'chat', t: 'WhatsApp · Asked about Aurora lamp', d: '2 min ago' },
        { i: 'cube', t: 'Order #4218 · $158', d: '4 min ago' },
        { i: 'spark', t: 'AI upsell accepted', d: '6 min ago' },
        { i: 'globe', t: 'Visited /aurora-pendant', d: '20 min ago' },
      ].map((e, i) => (
        <div key={i} style={{ position: 'relative', paddingBottom: 14 }}>
          <div style={{ position: 'absolute', left: -20, top: 0, width: 19, height: 19, borderRadius: 9999, background: '#fff', border: '2px solid #6C5CE7', color: '#6C5CE7', display: 'grid', placeItems: 'center' }}>
            <Icon name={e.i} size={9} />
          </div>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: '#0D0F1A' }}>{e.t}</div>
          <div style={{ fontSize: 11, color: '#9499BA' }}>{e.d}</div>
        </div>
      ))}
    </div>
  </Card>
);

const ContactCardMock = () => (
  <Card padding={22}>
    <div style={{ display: 'flex', gap: 12, marginBottom: 14 }}>
      <AvatarCircle name="Sarah Lin" size={48} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>Sarah Lin</div>
        <div style={{ fontSize: 12, color: '#6B7280' }}>sarah@aurora.co · +1 845 322 1199</div>
        <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
          <Badge tone="green" dot>VIP</Badge>
          <Badge tone="purple">Customer</Badge>
        </div>
      </div>
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
      {[['LTV','$2,840'],['Orders','11'],['Source','Chatbotistic'],['Last seen','2 min']].map(r => (
        <div key={r[0]} style={{ padding: 10, background: '#F8F9FF', borderRadius: 9 }}>
          <div style={{ fontSize: 10, color: '#9499BA', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{r[0]}</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A', marginTop: 2 }}>{r[1]}</div>
        </div>
      ))}
    </div>
  </Card>
);

const TimelineDetailMock = () => (
  <Card padding={22}>
    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
      <SectionLabel>Activity timeline · Daniel Hoff</SectionLabel>
      <Badge tone="amber" dot>Booked</Badge>
    </div>
    <div style={{ position: 'relative', paddingLeft: 20 }}>
      <div style={{ position: 'absolute', left: 9, top: 6, bottom: 6, width: 1.5, background: '#E9E6FD' }} />
      {[
        { i: 'inbox', tone: '#6C5CE7', t: 'Email reply: "Looks great. One question..."', d: '34 min ago' },
        { i: 'cube',  tone: '#00C04B', t: 'Booking #B-2918 — Highland 4-day tour, $1,290', d: '1 hr ago' },
        { i: 'chat',  tone: '#6C5CE7', t: 'AI handled 4 pre-sales questions', d: '2 hr ago' },
        { i: 'globe', tone: '#9499BA', t: 'Visited /tours/highland · 5 pages, 3m', d: '3 hr ago' },
      ].map((e, i) => (
        <div key={i} style={{ position: 'relative', paddingBottom: 14 }}>
          <div style={{ position: 'absolute', left: -20, top: 0, width: 19, height: 19, borderRadius: 9999, background: '#fff', border: '2px solid ' + e.tone, color: e.tone, display: 'grid', placeItems: 'center' }}>
            <Icon name={e.i} size={9} />
          </div>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: '#0D0F1A' }}>{e.t}</div>
          <div style={{ fontSize: 11, color: '#9499BA' }}>{e.d}</div>
        </div>
      ))}
    </div>
  </Card>
);

const TasksMock = () => (
  <Card padding={22}>
    <SectionLabel>Your tasks today</SectionLabel>
    {[
      { t: 'Call Daniel Hoff re: day 3 hike route', due: 'Today 14:30', p: 'High', done: false },
      { t: 'Send custom quote to Aurora Studio', due: 'Today 17:00', p: 'High', done: false },
      { t: 'Follow up: Sarah Lin VIP renewal', due: 'Tomorrow', p: 'Medium', done: false },
      { t: 'Welcome call: 4 new Gold members', due: 'Thu', p: 'Low', done: false },
    ].map((t, i) => (
      <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: i < 3 ? '1px solid #F0F2FF' : 'none' }}>
        <div style={{ width: 18, height: 18, borderRadius: 5, border: '1.5px solid #D4D6E0', flexShrink: 0 }} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: '#0D0F1A' }}>{t.t}</div>
          <div style={{ fontSize: 11, color: '#9499BA' }}>{t.due}</div>
        </div>
        <Badge tone={t.p === 'High' ? 'red' : t.p === 'Medium' ? 'amber' : 'gray'}>{t.p}</Badge>
      </div>
    ))}
  </Card>
);

Object.assign(window, {
  ChatbotisticPage, MemberisticPage, BookingisticPage, InsightisticPage, CrmisticPage,
  ProductHero, FeatureRowAlt, UseCaseRow, PricingTeaser,
});
