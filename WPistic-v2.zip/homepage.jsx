// homepage.jsx — Marketing homepage for WPistic

const HOMEPAGE_NAV = ['Products', 'Solutions', 'Pricing', 'Developers', 'Docs'];

const HomeNav = ({ onNav, onEnterApp }) => (
  <header style={{
    position: 'sticky', top: 0, zIndex: 100,
    background: 'rgba(255,255,255,0.92)',
    backdropFilter: 'blur(14px)',
    borderBottom: '1px solid #EDEFF8',
  }}>
    <div style={{
      maxWidth: 1240, margin: '0 auto', height: 68,
      padding: '0 36px',
      display: 'flex', alignItems: 'center', gap: 40,
    }}>
      <Logo size={28} />
      <nav style={{ display: 'flex', gap: 28, flex: 1 }}>
        {HOMEPAGE_NAV.map(l => (
          <a key={l} href="#" onClick={e => e.preventDefault()} style={{
            fontSize: 14, fontWeight: 500, color: '#4B5263',
            textDecoration: 'none',
          }}>{l}</a>
        ))}
      </nav>
      <Btn variant="ghost" size="sm" onClick={onEnterApp}>Sign in</Btn>
      <Btn size="sm" onClick={onEnterApp} rightIcon="arrow">Start Free</Btn>
    </div>
  </header>
);

// Hero with embedded dashboard preview
const Hero = ({ onEnterApp }) => (
  <section style={{
    position: 'relative', overflow: 'hidden',
    background: 'linear-gradient(155deg, #F3F1FE 0%, #EEF0FF 55%, #E8FAF0 130%)',
    padding: '80px 36px 100px',
  }}>
    {/* Ambient glows */}
    <div style={{
      position: 'absolute', top: -100, right: -100, width: 500, height: 500,
      background: 'radial-gradient(circle, rgba(108,92,231,0.20), transparent 65%)',
      pointerEvents: 'none',
    }} />
    <div style={{
      position: 'absolute', bottom: -200, left: -200, width: 600, height: 600,
      background: 'radial-gradient(circle, rgba(0,192,75,0.12), transparent 65%)',
      pointerEvents: 'none',
    }} />

    <div style={{ maxWidth: 1240, margin: '0 auto', position: 'relative' }}>
      {/* Top strip */}
      <div style={{ textAlign: 'center', marginBottom: 28 }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 9,
          background: 'rgba(255,255,255,0.7)',
          border: '1px solid rgba(108,92,231,0.18)',
          borderRadius: 9999, padding: '6px 16px',
          fontSize: 12.5, fontWeight: 600, color: '#5649CC',
          boxShadow: '0 4px 16px rgba(108,92,231,0.06)',
        }}>
          <span style={{ width: 6, height: 6, background: '#00C04B', borderRadius: 9999, animation: 'pulse-dot 1.8s ease-in-out infinite' }} />
          <span>WPAgentistic Beta is live</span>
          <span style={{ color: '#9499BA', margin: '0 4px' }}>·</span>
          <a href="#" onClick={e => e.preventDefault()} style={{ color: '#6C5CE7', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            Join waitlist <Icon name="arrow" size={12} />
          </a>
        </div>
      </div>

      <h1 style={{
        fontSize: 72, fontWeight: 800,
        letterSpacing: '-0.038em', lineHeight: 1.04,
        color: '#0D0F1A', textAlign: 'center',
        margin: 0, maxWidth: 980, marginLeft: 'auto', marginRight: 'auto',
      }}>
        Run your WordPress business stack from{' '}
        <span style={{
          background: '#00C04B',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
        }}>one AI SaaS hub</span>.
      </h1>

      <p style={{
        fontSize: 19, lineHeight: 1.6, color: '#4B5263',
        maxWidth: 720, margin: '24px auto 0',
        textAlign: 'center',
      }}>
        WPistic connects your plugins, licenses, websites, AI agents,
        automations, analytics, billing, and support into one unified
        dashboard built for WordPress-powered businesses.
      </p>

      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginTop: 36 }}>
        <Btn size="xl" onClick={onEnterApp} rightIcon="arrow">Start Free</Btn>
        <Btn size="xl" variant="outline">Explore Ecosystem</Btn>
      </div>

      <div style={{
        display: 'flex', gap: 24, justifyContent: 'center',
        marginTop: 22, fontSize: 13, color: '#6B7280', fontWeight: 500,
      }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <Icon name="check" size={14} color="#00C04B" strokeWidth={2.5} /> Free tier — no credit card
        </span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <Icon name="check" size={14} color="#00C04B" strokeWidth={2.5} /> 11 plugins included
        </span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <Icon name="check" size={14} color="#00C04B" strokeWidth={2.5} /> WordPress-native
        </span>
      </div>

      {/* Dashboard preview mock */}
      <div style={{ marginTop: 70, position: 'relative' }}>
        <HeroDashboardPreview onEnterApp={onEnterApp} />
      </div>
    </div>
  </section>
);

// Stylized dashboard preview - shows the sidebar + tiles + active products
const HeroDashboardPreview = () => (
  <div style={{
    position: 'relative',
    borderRadius: 22,
    overflow: 'hidden',
    background: '#0D0F1A',
    border: '1px solid #1E2130',
    boxShadow: '0 40px 100px rgba(108,92,231,0.30), 0 20px 60px rgba(13,15,26,0.20)',
    transform: 'perspective(1800px) rotateX(2deg)',
  }}>
    {/* Window chrome */}
    <div style={{
      height: 38, background: '#080A12',
      display: 'flex', alignItems: 'center', padding: '0 16px',
      borderBottom: '1px solid #1E2130',
    }}>
      <div style={{ display: 'flex', gap: 7 }}>
        <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#FF5F57' }} />
        <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#FEBC2E' }} />
        <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#28C840' }} />
      </div>
      <div style={{
        margin: '0 auto', fontSize: 11.5, color: '#6B7280', fontFamily: 'JetBrains Mono, monospace',
      }}>app.wpistic.com/dashboard</div>
    </div>

    {/* Body */}
    <div style={{ display: 'flex', height: 480, background: '#0D0F1A' }}>
      {/* Mini sidebar */}
      <div style={{
        width: 200, background: '#080A12', borderRight: '1px solid #1E2130',
        padding: 14, display: 'flex', flexDirection: 'column', gap: 4,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 8px 14px' }}>
          <img src="assets/logo-green.png" style={{ width: 22, height: 22 }} />
          <span style={{ fontSize: 13, fontWeight: 800, color: '#fff' }}>WPistic</span>
        </div>
        {[
          { icon: 'dashboard', label: 'Dashboard', active: true },
          { icon: 'cube', label: 'Products' },
          { icon: 'key', label: 'Licenses' },
          { icon: 'globe', label: 'Websites' },
          { icon: 'bot', label: 'AI Agents' },
          { icon: 'zap', label: 'Automations' },
          { icon: 'users', label: 'CRM' },
          { icon: 'chart', label: 'Analytics' },
        ].map((it, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 9,
            padding: '7px 8px', borderRadius: 7,
            fontSize: 11.5, fontWeight: 500,
            color: it.active ? '#fff' : '#9499BA',
            background: it.active ? '#6C5CE7' : 'transparent',
          }}>
            <Icon name={it.icon} size={13} color={it.active ? '#fff' : '#6B7280'} />
            <span>{it.label}</span>
          </div>
        ))}
      </div>

      {/* Main */}
      <div style={{ flex: 1, padding: 20, overflow: 'hidden' }}>
        {/* Header row */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>Good morning, Shuvo</div>
            <div style={{ fontSize: 11, color: '#9499BA', marginTop: 2 }}>5 sites · 12 licenses · 1,248 AI conversations</div>
          </div>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            background: 'rgba(0,192,75,0.12)', border: '1px solid rgba(0,192,75,0.30)',
            borderRadius: 9999, padding: '4px 11px', fontSize: 10.5, fontWeight: 700, color: '#4ED48A',
            letterSpacing: '0.05em', textTransform: 'uppercase',
          }}>
            <span style={{ width: 5, height: 5, background: '#00C04B', borderRadius: 9999 }} /> All systems normal
          </div>
        </div>

        {/* Stat row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: 16 }}>
          {[
            { label: 'Active products', value: '8', delta: '+2', tone: '#6C5CE7' },
            { label: 'Connected sites', value: '5', delta: '+1', tone: '#00C04B' },
            { label: 'Automations', value: '24', delta: '+12', tone: '#6C5CE7' },
            { label: 'AI conversations', value: '1.2k', delta: '+318', tone: '#00C04B' },
          ].map(s => (
            <div key={s.label} style={{
              background: '#13161F', border: '1px solid #1E2130', borderRadius: 11, padding: 12,
            }}>
              <div style={{ fontSize: 9.5, color: '#9499BA', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 6 }}>
                {s.label}
              </div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 7 }}>
                <span style={{ fontSize: 22, fontWeight: 800, color: '#fff', letterSpacing: '-0.02em' }}>{s.value}</span>
                <span style={{ fontSize: 10.5, fontWeight: 700, color: s.tone }}>{s.delta}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Two-column row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 10 }}>
          {/* Sparkline panel */}
          <div style={{
            background: '#13161F', border: '1px solid #1E2130', borderRadius: 11, padding: 14, height: 200, position: 'relative', overflow: 'hidden',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: '#fff' }}>Automation runs</div>
              <div style={{ fontSize: 10, color: '#9499BA' }}>Last 30 days</div>
            </div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#fff', letterSpacing: '-0.02em' }}>2,847</div>
            <svg viewBox="0 0 320 110" style={{ position: 'absolute', bottom: 0, left: 0, right: 0, width: '100%' }}>
              <defs>
                <linearGradient id="heroGrad" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#6C5CE7" stopOpacity="0.45" />
                  <stop offset="100%" stopColor="#6C5CE7" stopOpacity="0" />
                </linearGradient>
              </defs>
              <path d="M0,80 C30,70 50,40 80,45 C110,50 130,75 160,60 C190,45 210,20 240,28 C270,36 290,60 320,30 L320,110 L0,110 Z"
                fill="url(#heroGrad)" />
              <path d="M0,80 C30,70 50,40 80,45 C110,50 130,75 160,60 C190,45 210,20 240,28 C270,36 290,60 320,30"
                fill="none" stroke="#6C5CE7" strokeWidth="2" />
            </svg>
          </div>

          {/* Active products mini */}
          <div style={{
            background: '#13161F', border: '1px solid #1E2130', borderRadius: 11, padding: 14, height: 200,
          }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: '#fff', marginBottom: 10 }}>
              Active products
            </div>
            {PRODUCTS.slice(0, 4).map(p => (
              <div key={p.id} style={{
                display: 'flex', alignItems: 'center', gap: 9,
                padding: '5px 0',
              }}>
                <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={22} radius={7} />
                <span style={{ flex: 1, fontSize: 11, color: '#fff', fontWeight: 600 }}>{p.name}</span>
                <span style={{ fontSize: 9.5, fontWeight: 700, color: '#4ED48A', letterSpacing: '0.05em', textTransform: 'uppercase' }}>● Active</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>

    {/* Floating chips */}
    <div style={{
      position: 'absolute', top: 90, right: -22, padding: '10px 14px',
      background: 'rgba(255,255,255,0.97)', borderRadius: 12,
      boxShadow: '0 14px 40px rgba(108,92,231,0.25)',
      display: 'flex', alignItems: 'center', gap: 9,
      animation: 'float-soft 4.5s ease-in-out infinite',
    }}>
      <div style={{ width: 30, height: 30, borderRadius: 8, background: '#E8FAF0', display: 'grid', placeItems: 'center', color: '#00C04B' }}>
        <Icon name="zap" size={15} />
      </div>
      <div>
        <div style={{ fontSize: 11.5, fontWeight: 700, color: '#0D0F1A' }}>Automation completed</div>
        <div style={{ fontSize: 10.5, color: '#6B7280' }}>Order #4218 → WhatsApp</div>
      </div>
    </div>

    <div style={{
      position: 'absolute', bottom: 70, left: -22, padding: '10px 14px',
      background: 'rgba(255,255,255,0.97)', borderRadius: 12,
      boxShadow: '0 14px 40px rgba(108,92,231,0.25)',
      display: 'flex', alignItems: 'center', gap: 9,
      animation: 'float-soft 5s ease-in-out infinite 0.6s',
    }}>
      <div style={{ width: 30, height: 30, borderRadius: 8, background: '#E9E6FD', display: 'grid', placeItems: 'center', color: '#6C5CE7' }}>
        <Icon name="bot" size={15} />
      </div>
      <div>
        <div style={{ fontSize: 11.5, fontWeight: 700, color: '#0D0F1A' }}>New conversation</div>
        <div style={{ fontSize: 10.5, color: '#6B7280' }}>Sales Agent on shopglow.com</div>
      </div>
    </div>
  </div>
);

// Trust strip
const TrustStrip = () => (
  <section style={{
    background: '#fff', padding: '32px 36px',
    borderTop: '1px solid #EDEFF8', borderBottom: '1px solid #EDEFF8',
  }}>
    <div style={{
      maxWidth: 1240, margin: '0 auto', textAlign: 'center',
      fontSize: 13, fontWeight: 600, color: '#6B7280',
      letterSpacing: '0.04em',
    }}>
      One account. One dashboard. Every WordPress business tool connected.
    </div>
  </section>
);

// Ecosystem product grid
const EcosystemGrid = ({ onEnterApp }) => (
  <section style={{ background: '#F0F2FF', padding: '100px 36px' }}>
    <div style={{ maxWidth: 1240, margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: 56 }}>
        <SectionLabel style={{ marginBottom: 14 }}>The Ecosystem</SectionLabel>
        <h2 style={{
          fontSize: 48, fontWeight: 800, letterSpacing: '-0.035em',
          color: '#0D0F1A', lineHeight: 1.1, margin: 0,
        }}>
          Eleven products.{' '}
          <span style={{ color: '#00C04B' }}>One unified</span>{' '}
          <span style={{ color: '#00C04B' }}>operating system.</span>
        </h2>
        <p style={{
          fontSize: 17, color: '#4B5263', maxWidth: 640, margin: '18px auto 0',
          lineHeight: 1.65,
        }}>
          Every WordPressistic product plugs into WPistic — share licenses,
          AI usage, contacts, and analytics across your whole stack.
        </p>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: 18,
      }}>
        {PRODUCTS.map(p => (
          <Card key={p.id} hoverable padding={24}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16 }}>
              <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={48} radius={14} />
              <Badge tone={STATUS_TONE[p.status]} dot>{p.status}</Badge>
            </div>
            <div style={{ fontSize: 17, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.02em' }}>
              {p.name}
            </div>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: '#6C5CE7', marginTop: 3, marginBottom: 8 }}>
              {p.tagline}
            </div>
            <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: 0, minHeight: 56 }}>
              {p.desc}
            </p>
            <div style={{ marginTop: 18, paddingTop: 14, borderTop: '1px solid #F0F2FF', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 11.5, color: '#6B7280', fontWeight: 600 }}>{p.category}</span>
              <a href="#" onClick={(e) => { e.preventDefault(); onEnterApp(); }} style={{
                fontSize: 13, fontWeight: 700, color: '#6C5CE7', textDecoration: 'none',
                display: 'inline-flex', alignItems: 'center', gap: 5,
              }}>
                {p.status === 'Coming Soon' ? 'Get notified' : p.status === 'Beta' ? 'Join beta' : 'Manage'}
                <Icon name="arrow" size={13} />
              </a>
            </div>
          </Card>
        ))}
      </div>
    </div>
  </section>
);

// Core platform modules — 9 cards
const PLATFORM_MODULES = [
  { icon: 'key', title: 'License Manager', desc: 'Issue, activate, and revoke plugin licenses with domain enforcement.', tone: 'purple' },
  { icon: 'globe', title: 'Connected Websites', desc: 'Sync plugin status, versions, and health from every WordPress site you own.', tone: 'green' },
  { icon: 'bot', title: 'AI Agents', desc: 'Drop-in support, sales, and booking agents — configured once, used everywhere.', tone: 'purple' },
  { icon: 'zap', title: 'Automation Builder', desc: 'Build “if-this-then-that” workflows across WooCommerce, bookings, and CRM.', tone: 'green' },
  { icon: 'users', title: 'CRM', desc: 'Unified contacts, members, customers, and leads across every WPistic product.', tone: 'purple' },
  { icon: 'inbox', title: 'Inbox', desc: 'WhatsApp, email, SMS, website chat, and tickets — one threaded view.', tone: 'green' },
  { icon: 'chart', title: 'Analytics', desc: 'Revenue, traffic, conversions, and AI usage in one unified dashboard.', tone: 'purple' },
  { icon: 'card', title: 'Billing', desc: 'Plans, invoices, payment methods, and team seats in one place.', tone: 'green' },
  { icon: 'help', title: 'Support', desc: 'AI-assisted tickets, product docs, video tutorials, and roadmap voting.', tone: 'purple' },
];

const Modules = () => (
  <section style={{ background: '#fff', padding: '100px 36px', borderTop: '1px solid #EDEFF8' }}>
    <div style={{ maxWidth: 1240, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 48, gap: 40 }}>
        <div style={{ maxWidth: 580 }}>
          <SectionLabel>Core platform</SectionLabel>
          <h2 style={{ fontSize: 44, fontWeight: 800, letterSpacing: '-0.035em', color: '#0D0F1A', lineHeight: 1.1, margin: 0 }}>
            Nine modules that work the same way{' '}
            <span style={{ color: '#00C04B' }}>everywhere</span>.
          </h2>
        </div>
        <p style={{
          fontSize: 15.5, color: '#4B5263', lineHeight: 1.7, maxWidth: 380, margin: 0,
        }}>
          Every plugin you install adds to the same dashboard. No more tab-hopping
          between five admin panels — manage your business as one system.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {PLATFORM_MODULES.map((m, i) => {
          const c = m.tone === 'purple'
            ? { bg: '#F3F1FE', fg: '#6C5CE7' }
            : { bg: '#E8FAF0', fg: '#00C04B' };
          return (
            <div key={i} style={{
              background: '#F8F9FF',
              border: '1px solid #EDEFF8',
              borderRadius: 16, padding: 24,
              transition: 'all 0.2s',
            }}
              onMouseEnter={e => { e.currentTarget.style.background = '#fff'; e.currentTarget.style.borderColor = '#E9E6FD'; e.currentTarget.style.boxShadow = '0 12px 32px rgba(108,92,231,0.10)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = '#F8F9FF'; e.currentTarget.style.borderColor = '#EDEFF8'; e.currentTarget.style.boxShadow = 'none'; }}>
              <div style={{
                width: 38, height: 38, borderRadius: 11,
                background: c.bg, color: c.fg,
                display: 'grid', placeItems: 'center', marginBottom: 14,
              }}>
                <Icon name={m.icon} size={18} />
              </div>
              <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A', marginBottom: 6 }}>{m.title}</div>
              <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.65, margin: 0 }}>{m.desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  </section>
);

// How it works
const HowItWorks = () => (
  <section style={{ background: '#F8F9FF', padding: '100px 36px' }}>
    <div style={{ maxWidth: 1240, margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: 56 }}>
        <SectionLabel>How it works</SectionLabel>
        <h2 style={{ fontSize: 44, fontWeight: 800, letterSpacing: '-0.035em', color: '#0D0F1A', lineHeight: 1.1, margin: 0 }}>
          Live in <span style={{ color: '#00C04B' }}>under 5 minutes</span>.
        </h2>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 0, position: 'relative' }}>
        {[
          { n: '01', title: 'Create account', desc: 'Sign up with email — no credit card required.' },
          { n: '02', title: 'Connect site', desc: 'One-click WordPress plugin installs WPistic.' },
          { n: '03', title: 'Activate products', desc: 'Pick plugins and license them per domain.' },
          { n: '04', title: 'Launch agents', desc: 'Turn on AI agents and automation flows.' },
          { n: '05', title: 'Track growth', desc: 'Watch every metric in one connected dashboard.' },
        ].map((s, i, a) => (
          <div key={s.n} style={{ padding: '0 14px', position: 'relative' }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12,
              background: '#fff', border: '1px solid #E9E6FD',
              boxShadow: '0 4px 14px rgba(108,92,231,0.10)',
              display: 'grid', placeItems: 'center',
              fontSize: 13, fontWeight: 800, color: '#6C5CE7',
              letterSpacing: '0.04em', marginBottom: 16,
            }}>{s.n}</div>
            <div style={{ fontSize: 17, fontWeight: 700, color: '#0D0F1A', marginBottom: 6 }}>{s.title}</div>
            <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: 0 }}>{s.desc}</p>
            {i < a.length - 1 && (
              <div style={{
                position: 'absolute', top: 22, right: -10, width: 20, color: '#D4CCFB',
              }}>
                <Icon name="arrow" size={20} />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  </section>
);

// Featured Chatbotistic
const Featured = ({ onEnterApp }) => (
  <section style={{ background: '#fff', padding: '100px 36px' }}>
    <div style={{ maxWidth: 1240, margin: '0 auto' }}>
      <div style={{
        background: 'linear-gradient(135deg, #0D0F1A, #1A1659)',
        borderRadius: 28, padding: '56px 56px',
        position: 'relative', overflow: 'hidden',
        display: 'grid', gridTemplateColumns: '1.05fr 1fr', gap: 60, alignItems: 'center',
      }}>
        <div style={{
          position: 'absolute', top: -100, right: -100, width: 460, height: 460,
          background: 'radial-gradient(circle, rgba(0,192,75,0.22), transparent 65%)',
        }} />
        <div style={{ position: 'relative' }}>
          <Badge tone="green" dot>Flagship product</Badge>
          <h2 style={{ fontSize: 44, fontWeight: 800, letterSpacing: '-0.035em', color: '#fff', lineHeight: 1.08, margin: '18px 0 18px' }}>
            Chatbotistic — AI sales,<br />
            on every channel.
          </h2>
          <p style={{ fontSize: 16, color: '#9499BA', lineHeight: 1.7, margin: '0 0 28px', maxWidth: 480 }}>
            WhatsApp, website chat, Instagram, and Messenger — answered by one AI
            that knows your WooCommerce catalog, bookings, and members. Handover
            to humans when it matters.
          </p>
          <div style={{ display: 'flex', gap: 24, marginBottom: 30 }}>
            {[
              { v: '1,248', l: 'Conversations / mo' },
              { v: '94%', l: 'Auto-resolved' },
              { v: '3.2x', l: 'Lead capture' },
            ].map(s => (
              <div key={s.l}>
                <div style={{ fontSize: 28, fontWeight: 800, color: '#00C04B', letterSpacing: '-0.02em' }}>{s.v}</div>
                <div style={{ fontSize: 11.5, color: '#9499BA', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', marginTop: 4 }}>{s.l}</div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <Btn variant="green" size="lg" onClick={onEnterApp} rightIcon="arrow">Manage Chatbotistic</Btn>
            <Btn variant="dark-outline" size="lg">View live demo</Btn>
          </div>
        </div>

        {/* Chat preview */}
        <div style={{
          background: '#13161F',
          border: '1px solid #1E2130',
          borderRadius: 18, padding: 18,
          boxShadow: '0 30px 80px rgba(0,0,0,0.40)',
          position: 'relative',
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10,
            paddingBottom: 14, borderBottom: '1px solid #1E2130',
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10, background: '#E9E6FD', color: '#6C5CE7',
              display: 'grid', placeItems: 'center',
            }}>
              <Icon name="bot" size={18} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>Sales Agent</div>
              <div style={{ fontSize: 10.5, color: '#9499BA', display: 'flex', alignItems: 'center', gap: 5 }}>
                <span style={{ width: 5, height: 5, background: '#00C04B', borderRadius: 9999 }} /> Online · WhatsApp
              </div>
            </div>
            <Badge tone="purple" dot>AI</Badge>
          </div>

          <div style={{ paddingTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <ChatBubble side="them">Hi! Do you have the Aurora pendant lamp in matte black?</ChatBubble>
            <ChatBubble side="bot">Yes — we have 12 in stock. Free shipping over $80, delivered in 2–4 days. Want me to add it to your cart?</ChatBubble>
            <ChatBubble side="them">Add 2, please.</ChatBubble>
            <ChatBubble side="bot">Done. Checkout for $158.00 → <span style={{ color: '#4ED48A', fontWeight: 700 }}>tap to pay</span></ChatBubble>
            <div style={{
              padding: '8px 12px', borderRadius: 10, background: 'rgba(0,192,75,0.10)',
              border: '1px solid rgba(0,192,75,0.25)', fontSize: 11, color: '#4ED48A',
              display: 'flex', alignItems: 'center', gap: 7,
            }}>
              <Icon name="check" size={13} strokeWidth={2.5} />
              Order #4218 created · $158.00 · Logged to CRMistic
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const ChatBubble = ({ side, children }) => (
  <div style={{ display: 'flex', justifyContent: side === 'them' ? 'flex-start' : 'flex-end' }}>
    <div style={{
      maxWidth: '78%', fontSize: 12.5, lineHeight: 1.55,
      padding: '9px 13px', borderRadius: 14,
      background: side === 'them' ? '#1E2130' : '#6C5CE7',
      color: side === 'them' ? '#D4D6E0' : '#fff',
      borderBottomLeftRadius: side === 'them' ? 4 : 14,
      borderBottomRightRadius: side === 'bot' ? 4 : 14,
    }}>{children}</div>
  </div>
);

// Solutions
const Solutions = () => {
  const sols = [
    { icon: 'card', title: 'WooCommerce stores', desc: 'AI sales agents, automated cart recovery, and member discounts.' },
    { icon: 'users', title: 'Agencies', desc: 'Manage 50+ client sites, licenses, and AI usage from one screen.' },
    { icon: 'calendar', glyph: true, title: 'Booking businesses', desc: 'Calendars, reminders, and AI booking assistants in one stack.' },
    { icon: 'members', glyph: true, title: 'Membership sites', desc: 'Recurring revenue, churn detection, and retention automations.' },
    { icon: 'globe', title: 'Local businesses', desc: 'WhatsApp leads, reviews, and SEO insights in one local stack.' },
    { icon: 'cube', title: 'Product creators', desc: 'Issue and revoke your own plugin licenses with Licenseistic.' },
  ];
  return (
    <section style={{ background: '#F8F9FF', padding: '100px 36px' }}>
      <div style={{ maxWidth: 1240, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <SectionLabel>Solutions</SectionLabel>
          <h2 style={{ fontSize: 44, fontWeight: 800, letterSpacing: '-0.035em', color: '#0D0F1A', lineHeight: 1.1, margin: 0 }}>
            Built for <span style={{ color: '#00C04B' }}>WordPress businesses</span> of every shape.
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {sols.map((s, i) => (
            <Card key={i} hoverable padding={26}>
              <div style={{
                width: 42, height: 42, borderRadius: 12, marginBottom: 16,
                background: i % 2 === 0 ? '#F3F1FE' : '#E8FAF0',
                color: i % 2 === 0 ? '#6C5CE7' : '#00C04B',
                display: 'grid', placeItems: 'center',
              }}>
                {s.glyph
                  ? <ProductGlyph name={s.icon} color={i % 2 === 0 ? '#6C5CE7' : '#00C04B'} bg="transparent" size={32} radius={0} />
                  : <Icon name={s.icon} size={19} />}
              </div>
              <div style={{ fontSize: 17, fontWeight: 700, color: '#0D0F1A', marginBottom: 6 }}>{s.title}</div>
              <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.65, margin: 0 }}>{s.desc}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

// Pricing
const PRICING_PLANS = [
  { name: 'Free', price: '$0', cadence: '/mo',
    desc: 'For trying WPistic on a single site.',
    cta: 'Start free',
    features: ['1 connected site', '2 products active', '100 AI conversations', 'Community support'] },
  { name: 'Starter', price: '$19', cadence: '/mo',
    desc: 'For small WordPress businesses.',
    cta: 'Choose Starter',
    features: ['3 connected sites', '5 products active', '1,000 AI conversations', 'Email support', 'Automation builder'] },
  { name: 'Pro', price: '$49', cadence: '/mo', popular: true,
    desc: 'For growing stores & service businesses.',
    cta: 'Choose Pro',
    features: ['5 connected sites', 'All products active', '10,000 AI conversations', 'Priority support', 'CRM + Inbox + Analytics'] },
  { name: 'Business', price: '$129', cadence: '/mo',
    desc: 'For multi-site operators and teams.',
    cta: 'Choose Business',
    features: ['15 connected sites', '5 team seats', '50,000 AI conversations', 'Live chat support', 'Roles & permissions'] },
  { name: 'Agency', price: '$299', cadence: '/mo',
    desc: 'For agencies managing client sites.',
    cta: 'Choose Agency',
    features: ['Unlimited sites', '15 team seats', '250,000 AI conversations', 'Dedicated CSM', 'White-label dashboard'] },
];

const Pricing = ({ onEnterApp }) => (
  <section style={{ background: '#fff', padding: '100px 36px' }}>
    <div style={{ maxWidth: 1240, margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: 56 }}>
        <SectionLabel>Pricing</SectionLabel>
        <h2 style={{ fontSize: 44, fontWeight: 800, letterSpacing: '-0.035em', color: '#0D0F1A', lineHeight: 1.1, margin: 0 }}>
          Transparent plans. <span style={{ color: '#00C04B' }}>No surprises.</span>
        </h2>
        <p style={{ fontSize: 16, color: '#4B5263', marginTop: 16 }}>
          Start free, upgrade as you grow. Annual billing saves 20%.
        </p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14 }}>
        {PRICING_PLANS.map(p => (
          <div key={p.name} style={{
            background: p.popular ? '#0D0F1A' : '#fff',
            border: p.popular ? '1px solid #1E2130' : '1px solid #EDEFF8',
            borderRadius: 20, padding: 26,
            color: p.popular ? '#fff' : '#0D0F1A',
            boxShadow: p.popular ? '0 24px 60px rgba(108,92,231,0.30)' : '0 2px 12px rgba(108,92,231,0.05)',
            position: 'relative',
            transform: p.popular ? 'translateY(-8px)' : 'none',
          }}>
            {p.popular && (
              <div style={{
                position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)',
                background: '#00C04B', color: '#fff', borderRadius: 9999,
                padding: '4px 12px', fontSize: 10.5, fontWeight: 800,
                letterSpacing: '0.08em', textTransform: 'uppercase',
              }}>Most popular</div>
            )}
            <div style={{ fontSize: 14, fontWeight: 700, color: p.popular ? '#9499BA' : '#6C5CE7', letterSpacing: '0.04em' }}>
              {p.name}
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 10, marginBottom: 6 }}>
              <span style={{ fontSize: 36, fontWeight: 800, letterSpacing: '-0.025em' }}>{p.price}</span>
              <span style={{ fontSize: 13, color: p.popular ? '#9499BA' : '#9499BA' }}>{p.cadence}</span>
            </div>
            <div style={{ fontSize: 13, color: p.popular ? '#9499BA' : '#6B7280', lineHeight: 1.55, marginBottom: 18, minHeight: 40 }}>
              {p.desc}
            </div>
            <Btn
              variant={p.popular ? 'white' : 'border-card'}
              size="md"
              onClick={onEnterApp}
              style={{ width: '100%', justifyContent: 'center' }}>{p.cta}</Btn>
            <div style={{ marginTop: 22, paddingTop: 18, borderTop: p.popular ? '1px solid #1E2130' : '1px solid #F0F2FF' }}>
              {p.features.map(f => (
                <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5, marginBottom: 9, color: p.popular ? '#D4D6E0' : '#2E3245' }}>
                  <Icon name="check" size={14} color={p.popular ? '#4ED48A' : '#00C04B'} strokeWidth={2.5} />
                  {f}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// Final CTA
const FinalCTA = ({ onEnterApp }) => (
  <section style={{
    background: '#0D0F1A', padding: '100px 36px',
    position: 'relative', overflow: 'hidden', textAlign: 'center',
  }}>
    <div style={{
      position: 'absolute', inset: 0,
      background: 'radial-gradient(ellipse 60% 80% at 50% 110%, rgba(108,92,231,0.30) 0%, transparent 70%), radial-gradient(ellipse 60% 50% at 10% 0%, rgba(0,192,75,0.16) 0%, transparent 60%)',
      pointerEvents: 'none',
    }} />
    <div style={{ maxWidth: 720, margin: '0 auto', position: 'relative' }}>
      <Badge tone="green" dot>Free tier, no credit card</Badge>
      <h2 style={{
        fontSize: 56, fontWeight: 800, letterSpacing: '-0.038em',
        color: '#fff', lineHeight: 1.08, margin: '20px 0 16px',
      }}>
        Build your{' '}
        <span style={{
          background: '#00C04B',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
        }}>connected</span>{' '}
        WordPress business system.
      </h2>
      <p style={{ fontSize: 17, color: '#9499BA', lineHeight: 1.7, margin: '0 auto 32px', maxWidth: 540 }}>
        Eleven products. One dashboard. Every WordPress business operation managed
        as a single connected stack.
      </p>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
        <Btn variant="primary" size="xl" onClick={onEnterApp} rightIcon="arrow">Start Free</Btn>
        <Btn variant="dark-outline" size="xl">View Products</Btn>
      </div>
    </div>
  </section>
);

const HomeFooter = () => (
  <footer style={{ background: '#080A12', padding: '56px 36px 28px' }}>
    <div style={{ maxWidth: 1240, margin: '0 auto' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.8fr 1fr 1fr 1fr 1fr', gap: 36, marginBottom: 40 }}>
        <div>
          <Logo variant="green" size={28} dark />
          <p style={{ fontSize: 13, color: '#6B7280', lineHeight: 1.75, maxWidth: 260, marginTop: 16 }}>
            The AI SaaS hub for managing WordPress business tools, licenses, and automations from one unified dashboard.
          </p>
          <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
            {['𝕏', 'in', 'fb', 'yt'].map(s => (
              <div key={s} style={{
                width: 34, height: 34, borderRadius: 9, background: '#13161F',
                border: '1px solid #1E2130', display: 'grid', placeItems: 'center',
                color: '#6B7280', fontSize: 12,
              }}>{s}</div>
            ))}
          </div>
        </div>
        {[
          { title: 'Product', links: ['Ecosystem', 'Chatbotistic', 'Memberistic', 'Bookingistic', 'Insightistic', 'CRMistic'] },
          { title: 'Platform', links: ['License Manager', 'AI Agents', 'Automations', 'Inbox', 'Analytics', 'Developers'] },
          { title: 'Company', links: ['About', 'Blog', 'Affiliate', 'Press', 'Contact'] },
          { title: 'Legal', links: ['Privacy', 'Terms', 'Refunds', 'Security', 'Status'] },
        ].map(col => (
          <div key={col.title}>
            <div style={{
              fontSize: 11, fontWeight: 700, letterSpacing: '0.12em',
              textTransform: 'uppercase', color: '#fff', marginBottom: 18,
            }}>{col.title}</div>
            {col.links.map(l => (
              <a key={l} href="#" onClick={e => e.preventDefault()} style={{
                display: 'block', fontSize: 13, color: '#6B7280',
                textDecoration: 'none', marginBottom: 10, fontWeight: 500,
              }}>{l}</a>
            ))}
          </div>
        ))}
      </div>
      <div style={{ borderTop: '1px solid #13161F', paddingTop: 22, display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10, fontSize: 12, color: '#4B5263' }}>
        <span>© 2026 WPistic — part of the WordPressistic ecosystem.</span>
        <span>hello@wpistic.com</span>
      </div>
    </div>
  </footer>
);

const Homepage = ({ onEnterApp, onNav }) => {
  const go = onNav || (() => onEnterApp());
  return (
    <div className="scroll" style={{ height: '100%', overflowY: 'auto', background: '#fff' }}>
      <MarketingNav onNav={go} />
      <Hero onEnterApp={() => go('register')} />
      <TrustStrip />
      <EcosystemGrid onEnterApp={() => go('register')} />
      <Modules />
      <HowItWorks />
      <Featured onEnterApp={() => go('register')} />
      <Solutions />
      <Pricing onEnterApp={() => go('register')} />
      <FinalCTA onEnterApp={() => go('register')} />
      <MarketingFooter onNav={go} />
    </div>
  );
};

Object.assign(window, { Homepage });
