// websites.jsx — Connected websites manager

const SITES = [
  { name: 'ShopGlow',         domain: 'shopglow.com',       wp: '6.5.3', php: '8.2', woo: '8.9.1',
    status: 'Healthy', plugins: ['chatbotistic','crmistic','insightistic','postistic','licenseistic','memberistic'],
    lastSync: '2 min ago',  conversions: 287, revenue: '$28.4k', visitors: '14.2k' },
  { name: 'The Club',         domain: 'theclub.co',         wp: '6.5.3', php: '8.1', woo: '—',
    status: 'Healthy', plugins: ['memberistic','crmistic','postistic'],
    lastSync: '11 min ago', conversions: 64,  revenue: '$6.1k',  visitors: '3.8k' },
  { name: 'Wanderly Travel',  domain: 'wanderly.travel',    wp: '6.4.2', php: '8.0', woo: '8.7.0',
    status: 'Update', plugins: ['bookingistic','chatbotistic','travelistic','insightistic'],
    lastSync: '32 min ago', conversions: 142, revenue: '$11.9k', visitors: '8.1k' },
  { name: 'Local Cafe',       domain: 'localcafe.com',      wp: '6.5.3', php: '8.2', woo: '—',
    status: 'Healthy', plugins: ['chatbotistic','bookingistic'],
    lastSync: '1 hr ago',   conversions: 38,  revenue: '$2.4k',  visitors: '1.9k' },
  { name: 'Agency Tools',     domain: 'agency-tools.io',    wp: '6.5.1', php: '8.2', woo: '—',
    status: 'Failed', plugins: [],
    lastSync: '3 hr ago',   conversions: 0,   revenue: '—',      visitors: '—' },
];

const SITE_STATUS = {
  Healthy: { color: '#00C04B', bg: '#E8FAF0', label: 'Healthy', icon: 'check' },
  Update:  { color: '#92400E', bg: '#FEF3C7', label: 'Plugin Updates', icon: 'warn' },
  Failed:  { color: '#991B1B', bg: '#FEE2E2', label: 'Sync Failed', icon: 'warn' },
};

const WebsitesPage = () => {
  const [view, setView] = React.useState('grid');
  const totalSites = SITES.length;
  const healthy = SITES.filter(s => s.status === 'Healthy').length;
  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      <PageHeader
        eyebrow="Connected Websites"
        title="Websites"
        subtitle={`${totalSites} connected · ${healthy} healthy · WordPress + WooCommerce`}
        actions={
          <>
            <Btn variant="border-card" size="md" leftIcon="refresh">Sync all</Btn>
            <Btn variant="primary" size="md" leftIcon="plus">Connect site</Btn>
          </>
        } />

      {/* Stat row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14, marginBottom: 22 }}>
        <MiniStat label="Connected" value="5" icon="globe" iconBg="#F3F1FE" iconColor="#6C5CE7" />
        <MiniStat label="Healthy" value="3" icon="check" iconBg="#E8FAF0" iconColor="#00C04B" />
        <MiniStat label="Need attention" value="2" icon="warn" iconBg="#FEF3C7" iconColor="#92400E" />
        <MiniStat label="Total visitors / mo" value="28.0k" icon="chart" iconBg="#E8FAF0" iconColor="#00C04B" />
      </div>

      {/* Toolbar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16, gap: 12, flexWrap: 'wrap' }}>
        <TextInput placeholder="Search sites…" icon="search" size="sm" style={{ width: 300 }} />
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="border-card" size="sm" leftIcon="filter">Filter</Btn>
          <div style={{ display: 'inline-flex', background: '#fff', border: '1px solid #EDEFF8', borderRadius: 9999, padding: 3 }}>
            {['grid','list'].map(v => (
              <button key={v} onClick={() => setView(v)} style={{
                fontFamily: 'inherit', fontSize: 12, fontWeight: 600,
                padding: '6px 14px', borderRadius: 9999,
                background: view===v ? '#F3F1FE' : 'transparent',
                color: view===v ? '#6C5CE7' : '#6B7280',
                border: 'none', cursor: 'pointer', textTransform: 'capitalize',
              }}>{v}</button>
            ))}
          </div>
        </div>
      </div>

      {view === 'grid' ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
          {SITES.map(s => <SiteCard key={s.domain} site={s} />)}
          <AddSiteCard />
        </div>
      ) : (
        <Card padding={0}>
          <table className="wpt">
            <thead>
              <tr>
                <th style={{ paddingLeft: 22 }}>Site</th>
                <th>Status</th>
                <th>Plugins</th>
                <th>WP / PHP</th>
                <th>Visitors</th>
                <th>Last sync</th>
                <th style={{ paddingRight: 22 }}></th>
              </tr>
            </thead>
            <tbody>
              {SITES.map(s => {
                const t = SITE_STATUS[s.status];
                return (
                  <tr key={s.domain}>
                    <td style={{ paddingLeft: 22 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <SiteFavicon domain={s.domain} />
                        <div>
                          <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{s.name}</div>
                          <div style={{ fontSize: 12, color: '#6B7280' }}>{s.domain}</div>
                        </div>
                      </div>
                    </td>
                    <td><Badge tone={s.status==='Healthy'?'green':s.status==='Update'?'amber':'red'} dot>{t.label}</Badge></td>
                    <td><PluginStack plugins={s.plugins} max={5} /></td>
                    <td style={{ fontSize: 12.5, color: '#4B5263' }}>WP {s.wp} · PHP {s.php}</td>
                    <td style={{ fontSize: 13, fontWeight: 600, color: '#0D0F1A' }}>{s.visitors}</td>
                    <td style={{ fontSize: 12, color: '#9499BA' }}>{s.lastSync}</td>
                    <td style={{ paddingRight: 22, textAlign: 'right' }}>
                      <Btn variant="ghost" size="xs" rightIcon="arrow">Open</Btn>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
};

const SiteFavicon = ({ domain }) => {
  const letter = (domain || 'W').charAt(0).toUpperCase();
  const hues = ['#6C5CE7','#00C04B','#1A1659','#5649CC','#007C2F'];
  const c = hues[domain.charCodeAt(0) % hues.length];
  return (
    <div style={{
      width: 36, height: 36, borderRadius: 9,
      background: c, color: '#fff', fontWeight: 800, fontSize: 14,
      display: 'grid', placeItems: 'center', letterSpacing: '-0.02em',
      flexShrink: 0,
    }}>{letter}</div>
  );
};

const SiteCard = ({ site: s }) => {
  const t = SITE_STATUS[s.status];
  const products = s.plugins.map(id => PRODUCTS.find(p => p.id === id)).filter(Boolean);
  return (
    <Card padding={22} hoverable>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
        <SiteFavicon domain={s.domain} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>{s.name}</div>
          <div style={{ fontSize: 12.5, color: '#6B7280', display: 'flex', alignItems: 'center', gap: 6 }}>
            {s.domain} <Icon name="external" size={10} color="#9499BA" />
          </div>
        </div>
        <Badge tone={s.status==='Healthy'?'green':s.status==='Update'?'amber':'red'} dot>{t.label}</Badge>
      </div>

      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0,
        background: '#F8F9FF', borderRadius: 12, padding: '14px 4px', marginBottom: 16,
        border: '1px solid #EDEFF8',
      }}>
        <MicroStat v={s.visitors} l="Visitors" />
        <MicroStat v={s.conversions} l="Conversions" />
        <MicroStat v={s.revenue} l="Revenue (mo)" />
        <MicroStat v={products.length} l="Plugins" />
      </div>

      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#9499BA', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>
          Installed WPistic products
        </div>
        {products.length === 0 ? (
          <div style={{ fontSize: 12.5, color: '#9499BA', fontStyle: 'italic' }}>No products detected — sync failed.</div>
        ) : (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {products.slice(0,6).map(p => (
              <div key={p.id} style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                padding: '5px 9px 5px 6px',
                background: '#fff', border: '1px solid #EDEFF8', borderRadius: 9999,
                fontSize: 11.5, fontWeight: 600, color: '#2E3245',
              }}>
                <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={18} radius={5} />
                {p.name}
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        paddingTop: 14, borderTop: '1px solid #F0F2FF',
      }}>
        <div style={{ fontSize: 11.5, color: '#9499BA' }}>
          WP {s.wp} · PHP {s.php} {s.woo !== '—' && `· Woo ${s.woo}`} · Synced {s.lastSync}
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <Btn variant="ghost-gray" size="xs" leftIcon="refresh">Sync</Btn>
          <Btn variant="ghost" size="xs" rightIcon="arrow">Open</Btn>
        </div>
      </div>
    </Card>
  );
};

const MicroStat = ({ v, l }) => (
  <div style={{ textAlign: 'center', padding: '0 6px', borderRight: '1px solid #EDEFF8' }}>
    <div style={{ fontSize: 16, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>{v}</div>
    <div style={{ fontSize: 10, fontWeight: 700, color: '#9499BA', letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 2 }}>{l}</div>
  </div>
);

const PluginStack = ({ plugins, max = 4 }) => {
  const ps = plugins.map(id => PRODUCTS.find(p => p.id === id)).filter(Boolean);
  const visible = ps.slice(0, max);
  const extra = ps.length - visible.length;
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center' }}>
      {visible.map((p, i) => (
        <div key={p.id} style={{ marginLeft: i === 0 ? 0 : -8, position: 'relative' }} title={p.name}>
          <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={26} radius={8} />
        </div>
      ))}
      {extra > 0 && (
        <div style={{
          marginLeft: -8, width: 26, height: 26, borderRadius: 8,
          background: '#F0F2FF', color: '#4B5263', fontSize: 10, fontWeight: 700,
          display: 'grid', placeItems: 'center', border: '2px solid #fff',
        }}>+{extra}</div>
      )}
      {ps.length === 0 && <span style={{ fontSize: 12, color: '#9499BA' }}>—</span>}
    </div>
  );
};

const AddSiteCard = () => (
  <div style={{
    border: '2px dashed #D4CCFB', borderRadius: 20,
    background: 'rgba(243,241,254,0.4)',
    padding: 30,
    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    minHeight: 320, gap: 12, textAlign: 'center',
  }}>
    <div style={{
      width: 56, height: 56, borderRadius: 16,
      background: '#F3F1FE', color: '#6C5CE7',
      display: 'grid', placeItems: 'center',
    }}>
      <Icon name="plus" size={26} strokeWidth={2.2} />
    </div>
    <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>Connect a WordPress site</div>
    <p style={{ fontSize: 13, color: '#6B7280', margin: 0, maxWidth: 280, lineHeight: 1.55 }}>
      Install the WPistic Connect plugin or paste a site URL. We'll sync plugins, licenses, and health in seconds.
    </p>
    <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
      <Btn variant="primary" size="sm" leftIcon="plus">Connect site</Btn>
      <Btn variant="border-card" size="sm">Install via plugin</Btn>
    </div>
  </div>
);

// ─────────────────────────────────────────────────────────────
// Shared page bits
// ─────────────────────────────────────────────────────────────
const PageHeader = ({ eyebrow, title, subtitle, actions }) => (
  <div style={{
    display: 'flex', justifyContent: 'space-between',
    alignItems: 'flex-end', marginBottom: 22, gap: 24, flexWrap: 'wrap',
  }}>
    <div>
      {eyebrow && <SectionLabel style={{ marginBottom: 8 }}>{eyebrow}</SectionLabel>}
      <h1 style={{ fontSize: 30, fontWeight: 800, letterSpacing: '-0.025em', color: '#0D0F1A', lineHeight: 1.15, margin: 0 }}>
        {title}
      </h1>
      {subtitle && <p style={{ fontSize: 14.5, color: '#6B7280', margin: '6px 0 0', lineHeight: 1.5 }}>{subtitle}</p>}
    </div>
    {actions && <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>{actions}</div>}
  </div>
);

const MiniStat = ({ label, value, icon, iconBg, iconColor, sub }) => (
  <Card padding={20}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
      <div>
        <div style={{ fontSize: 11.5, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#6B7280' }}>{label}</div>
        <div style={{ fontSize: 28, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.025em', marginTop: 6 }}>{value}</div>
        {sub && <div style={{ fontSize: 11.5, color: '#9499BA', marginTop: 4 }}>{sub}</div>}
      </div>
      <div style={{
        width: 36, height: 36, borderRadius: 10,
        background: iconBg, color: iconColor,
        display: 'grid', placeItems: 'center',
      }}>
        <Icon name={icon} size={17} />
      </div>
    </div>
  </Card>
);

Object.assign(window, { WebsitesPage, PageHeader, MiniStat, SiteFavicon });
