// dashboard.jsx — Dashboard Home

// ─── Onboarding checklist (new) ──────────────────────────────
const ONBOARDING_STEPS = [
  { id: 'account',   label: 'Create account',         desc: 'Welcome to WPistic.',                                done: true },
  { id: 'plan',      label: 'Choose plan',            desc: 'Business · annual',                                   done: true },
  { id: 'site',      label: 'Connect your first website', desc: 'Install Connector or paste a URL.',               done: true },
  { id: 'connector', label: 'Install WPistic Connector', desc: 'WP plugin syncs licenses + analytics.',             done: false },
  { id: 'license',   label: 'Activate first license', desc: 'Pick a product, activate on a site.',                 done: false },
  { id: 'auto',      label: 'Launch first automation', desc: 'Try cart-recovery in under 5 minutes.',              done: false },
];

const OnboardingChecklist = ({ onDismiss }) => {
  const done = ONBOARDING_STEPS.filter(s => s.done).length;
  const total = ONBOARDING_STEPS.length;
  const pct = (done / total) * 100;
  return (
    <Card padding={0} style={{ overflow: 'hidden', marginBottom: 20,
      background: 'linear-gradient(135deg, #1A1659 0%, #0D0F1A 100%)',
      color: '#fff', border: 'none', position: 'relative',
    }}>
      <div style={{
        position: 'absolute', top: -80, right: -80, width: 320, height: 320,
        background: 'radial-gradient(circle, rgba(0,192,75,0.30), transparent 65%)',
      }} />
      <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '1.3fr 1.7fr', gap: 0 }}>
        {/* Left: progress */}
        <div style={{ padding: '24px 28px', borderRight: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <Badge tone="green" dot>Setup · {done}/{total}</Badge>
            <button onClick={onDismiss} style={{ background: 'transparent', border: 'none', color: '#6B7280', cursor: 'pointer', fontSize: 11, fontFamily: 'inherit', textDecoration: 'underline' }}>
              Dismiss
            </button>
          </div>
          <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-0.02em', marginTop: 12, lineHeight: 1.25 }}>
            Complete your workspace.
          </div>
          <p style={{ fontSize: 13, color: '#9499BA', lineHeight: 1.6, margin: '6px 0 18px' }}>
            Three steps to go before WPistic is humming in the background.
          </p>
          <div style={{ height: 6, background: 'rgba(255,255,255,0.10)', borderRadius: 9999, overflow: 'hidden', marginBottom: 8 }}>
            <div style={{ width: pct + '%', height: '100%', background: 'linear-gradient(90deg, #6C5CE7, #00C04B)', borderRadius: 9999, transition: 'width 0.4s' }} />
          </div>
          <div style={{ fontSize: 11.5, color: '#9499BA' }}>{Math.round(pct)}% done · ~3 minutes left</div>

          <div style={{ marginTop: 22 }}>
            <Btn variant="green" size="sm" rightIcon="arrow">Continue setup</Btn>
          </div>
        </div>

        {/* Right: steps */}
        <div style={{ padding: '24px 28px' }}>
          {ONBOARDING_STEPS.map((s, i) => (
            <div key={s.id} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '8px 0', borderBottom: i < ONBOARDING_STEPS.length - 1 ? '1px solid rgba(255,255,255,0.06)' : 'none',
              opacity: s.done ? 0.6 : 1,
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: 9999, flexShrink: 0,
                background: s.done ? '#00C04B' : 'transparent',
                border: s.done ? 'none' : '1.5px solid #4B5263',
                color: '#fff', display: 'grid', placeItems: 'center',
              }}>{s.done && <Icon name="check" size={12} strokeWidth={3} />}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: '#fff', textDecoration: s.done ? 'line-through' : 'none' }}>{s.label}</div>
                <div style={{ fontSize: 11.5, color: '#9499BA', marginTop: 1 }}>{s.desc}</div>
              </div>
              {!s.done && (
                <Btn variant="dark-outline" size="xs" rightIcon="arrow">Do it</Btn>
              )}
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
};

Object.assign(window, { OnboardingChecklist });


// ─────────────────────────────────────────────────────────────
// Stat card with sparkline
// ─────────────────────────────────────────────────────────────
const StatCard = ({ label, value, delta, deltaTone, icon, iconBg, iconColor, sparklinePath, sparklineColor }) => (
  <Card padding={22} hoverable style={{ position: 'relative', overflow: 'hidden' }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
      <div style={{
        width: 36, height: 36, borderRadius: 10,
        background: iconBg, color: iconColor,
        display: 'grid', placeItems: 'center',
      }}>
        <Icon name={icon} size={17} />
      </div>
      {delta && (
        <span style={{
          fontSize: 11.5, fontWeight: 700,
          color: deltaTone === 'down' ? '#EF4444' : '#00C04B',
          background: deltaTone === 'down' ? '#FEE2E2' : '#E8FAF0',
          padding: '3px 9px', borderRadius: 9999,
        }}>
          {deltaTone === 'down' ? '↓' : '↑'} {delta}
        </span>
      )}
    </div>
    <div style={{
      fontSize: 11.5, fontWeight: 700, letterSpacing: '0.08em',
      textTransform: 'uppercase', color: '#6B7280',
    }}>{label}</div>
    <div style={{
      fontSize: 30, fontWeight: 800, color: '#0D0F1A',
      letterSpacing: '-0.025em', marginTop: 6, lineHeight: 1,
    }}>{value}</div>
    {sparklinePath && (
      <svg viewBox="0 0 200 36" preserveAspectRatio="none"
        style={{ position: 'absolute', bottom: 14, right: 14, width: 90, height: 28, opacity: 0.85 }}>
        <path d={sparklinePath} fill="none" stroke={sparklineColor || '#6C5CE7'} strokeWidth="1.8" />
      </svg>
    )}
  </Card>
);

// ─────────────────────────────────────────────────────────────
// Activity list item
// ─────────────────────────────────────────────────────────────
const ActivityRow = ({ icon, iconColor, iconBg, title, meta, time }) => (
  <div style={{
    display: 'flex', alignItems: 'flex-start', gap: 12,
    padding: '12px 0', borderBottom: '1px solid #F0F2FF',
  }}>
    <div style={{
      width: 32, height: 32, borderRadius: 9,
      background: iconBg, color: iconColor,
      display: 'grid', placeItems: 'center', flexShrink: 0,
    }}>
      <Icon name={icon} size={14} />
    </div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13.5, fontWeight: 600, color: '#0D0F1A', lineHeight: 1.35 }}>{title}</div>
      <div style={{ fontSize: 12, color: '#6B7280', marginTop: 2 }}>{meta}</div>
    </div>
    <div style={{ fontSize: 11.5, color: '#9499BA', fontWeight: 500, whiteSpace: 'nowrap' }}>{time}</div>
  </div>
);

// ─────────────────────────────────────────────────────────────
// Site health card row
// ─────────────────────────────────────────────────────────────
const SiteHealthRow = ({ name, domain, status, plugins, lastSync, wpVersion }) => {
  const tones = {
    'Connected': { color: '#00C04B', bg: '#E8FAF0', label: 'Healthy' },
    'Plugin Outdated': { color: '#F59E0B', bg: '#FEF3C7', label: 'Update' },
    'Sync Failed': { color: '#EF4444', bg: '#FEE2E2', label: 'Failed' },
  };
  const t = tones[status] || tones['Connected'];
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14,
      padding: '14px 16px', borderRadius: 12,
      background: '#F8F9FF', border: '1px solid #EDEFF8',
      transition: 'background 0.15s',
    }}
      onMouseEnter={e => { e.currentTarget.style.background = '#fff'; e.currentTarget.style.borderColor = '#E9E6FD'; }}
      onMouseLeave={e => { e.currentTarget.style.background = '#F8F9FF'; e.currentTarget.style.borderColor = '#EDEFF8'; }}>
      <div style={{
        width: 36, height: 36, borderRadius: 10,
        background: t.bg, color: t.color,
        display: 'grid', placeItems: 'center', flexShrink: 0,
      }}>
        <Icon name="globe" size={17} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{name}</div>
        <div style={{ fontSize: 12, color: '#6B7280', marginTop: 1 }}>{domain} · WP {wpVersion} · {plugins} plugins</div>
      </div>
      <div style={{ fontSize: 11, color: '#9499BA', fontWeight: 500 }}>{lastSync}</div>
      <span style={{
        fontSize: 10.5, fontWeight: 700, letterSpacing: '0.05em',
        textTransform: 'uppercase', color: t.color, background: t.bg,
        padding: '4px 10px', borderRadius: 9999,
      }}>{t.label}</span>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// Dashboard Home
// ─────────────────────────────────────────────────────────────
const DashboardHome = () => {
  const [showOnboarding, setShowOnboarding] = React.useState(true);
  return (
  <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
    {/* Welcome row */}
    <div style={{
      display: 'flex', justifyContent: 'space-between',
      alignItems: 'flex-end', marginBottom: 24, gap: 24, flexWrap: 'wrap',
    }}>
      <div>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <span style={{ fontSize: 12.5, fontWeight: 700, color: '#6C5CE7', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            Tuesday, May 26
          </span>
          <Badge tone="green" dot>All systems normal</Badge>
        </div>
        <h1 style={{
          fontSize: 30, fontWeight: 800, letterSpacing: '-0.025em',
          color: '#0D0F1A', lineHeight: 1.15, margin: 0,
        }}>
          Good morning, Shuvo.
        </h1>
        <p style={{ fontSize: 14.5, color: '#6B7280', margin: '6px 0 0', lineHeight: 1.5 }}>
          Your WordPress business stack is running smoothly. 5 sites synced, 24 automations completed this week.
        </p>
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <Btn variant="border-card" size="md" leftIcon="refresh">Sync all</Btn>
        <Btn variant="border-card" size="md" leftIcon="download">Plugins</Btn>
        <Btn variant="primary" size="md" leftIcon="plus">Connect site</Btn>
      </div>
    </div>

    {/* Stats row */}
    {showOnboarding && <OnboardingChecklist onDismiss={() => setShowOnboarding(false)} />}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 14 }}>
      <StatCard label="Active products" value="8" delta="2 new" icon="cube"
        iconBg="#F3F1FE" iconColor="#6C5CE7"
        sparklineColor="#6C5CE7"
        sparklinePath="M0,28 L25,24 L50,22 L75,18 L100,14 L125,12 L150,16 L175,10 L200,6" />
      <StatCard label="Active licenses" value="12" delta="+3" icon="key"
        iconBg="#E8FAF0" iconColor="#00C04B"
        sparklineColor="#00C04B"
        sparklinePath="M0,30 L25,26 L50,28 L75,20 L100,22 L125,16 L150,12 L175,14 L200,8" />
      <StatCard label="Connected sites" value="5" delta="+1" icon="globe"
        iconBg="#F3F1FE" iconColor="#6C5CE7"
        sparklineColor="#6C5CE7"
        sparklinePath="M0,24 L25,26 L50,20 L75,22 L100,18 L125,14 L150,16 L175,10 L200,12" />
      <StatCard label="AI conversations" value="1,248" delta="+318" icon="bot"
        iconBg="#E8FAF0" iconColor="#00C04B"
        sparklineColor="#00C04B"
        sparklinePath="M0,32 L25,28 L50,22 L75,24 L100,16 L125,18 L150,10 L175,8 L200,4" />
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 32 }}>
      <StatCard label="Automation runs (mo)" value="2,847" delta="+512" icon="zap"
        iconBg="#F3F1FE" iconColor="#6C5CE7"
        sparklineColor="#6C5CE7"
        sparklinePath="M0,30 L25,26 L50,18 L75,22 L100,14 L125,10 L150,12 L175,6 L200,4" />
      <StatCard label="Open tickets" value="2" delta="1 priority" deltaTone="down" icon="help"
        iconBg="#FEF3C7" iconColor="#92400E" />
      <StatCard label="Monthly usage" value="74%" icon="chart"
        iconBg="#E8FAF0" iconColor="#00C04B"
        sparklineColor="#00C04B"
        sparklinePath="M0,30 L25,26 L50,22 L75,18 L100,14 L125,10 L150,8 L175,6 L200,4" />
      <StatCard label="Account plan" value="Business" icon="shield"
        iconBg="#F3F1FE" iconColor="#6C5CE7" />
    </div>

    {/* Quick actions */}
    <Card padding={20} style={{ marginBottom: 28 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: 11.5, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#6C5CE7' }}>
            Quick actions
          </div>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A', marginTop: 4 }}>What would you like to do today?</div>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
        {[
          { icon: 'globe', label: 'Connect website', tone: 'purple' },
          { icon: 'download', label: 'Download plugin', tone: 'green' },
          { icon: 'zap', label: 'Create automation', tone: 'purple' },
          { icon: 'bot', label: 'Launch AI agent', tone: 'green' },
          { icon: 'help', label: 'Open support ticket', tone: 'purple' },
        ].map((a, i) => {
          const c = a.tone === 'purple' ? { bg: '#F3F1FE', fg: '#6C5CE7' } : { bg: '#E8FAF0', fg: '#00C04B' };
          return (
            <button key={i} style={{
              border: '1px solid #EDEFF8', background: '#fff', borderRadius: 14,
              padding: '16px 14px', cursor: 'pointer', textAlign: 'left',
              transition: 'all 0.15s', display: 'flex', flexDirection: 'column', gap: 10,
              fontFamily: 'inherit',
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = '#D4CCFB'; e.currentTarget.style.boxShadow = '0 8px 24px rgba(108,92,231,0.10)'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = '#EDEFF8'; e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.transform = 'none'; }}>
              <div style={{
                width: 34, height: 34, borderRadius: 10,
                background: c.bg, color: c.fg,
                display: 'grid', placeItems: 'center',
              }}>
                <Icon name={a.icon} size={16} />
              </div>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: '#0D0F1A' }}>{a.label}</div>
            </button>
          );
        })}
      </div>
    </Card>

    {/* Two-column main */}
    <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 16, marginBottom: 16 }}>
      {/* Connected sites */}
      <Card padding={22}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>Connected websites</div>
            <div style={{ fontSize: 12.5, color: '#6B7280', marginTop: 2 }}>5 sites synced · WordPress + WooCommerce</div>
          </div>
          <Btn variant="ghost-gray" size="sm" rightIcon="arrow">View all</Btn>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <SiteHealthRow name="ShopGlow" domain="shopglow.com" status="Connected" plugins="6" lastSync="2 min ago" wpVersion="6.5.3" />
          <SiteHealthRow name="The Club" domain="theclub.co" status="Connected" plugins="3" lastSync="11 min ago" wpVersion="6.5.3" />
          <SiteHealthRow name="Wanderly Travel" domain="wanderly.travel" status="Plugin Outdated" plugins="4" lastSync="32 min ago" wpVersion="6.4.2" />
          <SiteHealthRow name="Local Cafe" domain="localcafe.com" status="Connected" plugins="2" lastSync="1 hr ago" wpVersion="6.5.3" />
          <SiteHealthRow name="Agency Tools" domain="agency-tools.io" status="Sync Failed" plugins="—" lastSync="3 hr ago" wpVersion="6.5.1" />
        </div>
      </Card>

      {/* License health */}
      <Card padding={22}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>License health</div>
            <div style={{ fontSize: 12.5, color: '#6B7280', marginTop: 2 }}>12 licenses · 3 need attention</div>
          </div>
          <Btn variant="ghost-gray" size="sm" rightIcon="arrow">Manage</Btn>
        </div>

        {/* Big donut */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 24, marginBottom: 18 }}>
          <Donut value={10} total={12} />
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
              <span style={{ width: 8, height: 8, borderRadius: 9999, background: '#00C04B' }} />
              <span style={{ fontSize: 13, color: '#2E3245', fontWeight: 600, flex: 1 }}>Active</span>
              <span style={{ fontSize: 14, fontWeight: 800, color: '#0D0F1A' }}>10</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
              <span style={{ width: 8, height: 8, borderRadius: 9999, background: '#F59E0B' }} />
              <span style={{ fontSize: 13, color: '#2E3245', fontWeight: 600, flex: 1 }}>Expiring soon</span>
              <span style={{ fontSize: 14, fontWeight: 800, color: '#0D0F1A' }}>1</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ width: 8, height: 8, borderRadius: 9999, background: '#EF4444' }} />
              <span style={{ fontSize: 13, color: '#2E3245', fontWeight: 600, flex: 1 }}>Needs update</span>
              <span style={{ fontSize: 14, fontWeight: 800, color: '#0D0F1A' }}>2</span>
            </div>
          </div>
        </div>

        <div style={{
          padding: '12px 14px', background: '#FEF3C7',
          border: '1px solid #FCD34D', borderRadius: 12,
          display: 'flex', alignItems: 'flex-start', gap: 10,
        }}>
          <Icon name="warn" size={16} color="#92400E" />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#92400E' }}>Bookingistic Pro expires in 14 days</div>
            <div style={{ fontSize: 12, color: '#92400E', marginTop: 2, opacity: 0.85 }}>
              Renew now to avoid service interruption on wanderly.travel.
            </div>
          </div>
          <Btn variant="primary" size="xs">Renew</Btn>
        </div>
      </Card>
    </div>

    {/* Bottom row */}
    <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr', gap: 16 }}>
      {/* AI usage / Conversations chart */}
      <Card padding={22}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>AI conversations</div>
            <div style={{ fontSize: 12.5, color: '#6B7280', marginTop: 2 }}>Last 14 days · Chatbotistic + WPAgentistic</div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['7D', '14D', '30D'].map((p, i) => (
              <button key={p} style={{
                fontFamily: 'inherit', fontSize: 11.5, fontWeight: 600,
                padding: '5px 10px', borderRadius: 7,
                background: i === 1 ? '#F3F1FE' : 'transparent',
                color: i === 1 ? '#6C5CE7' : '#6B7280',
                border: 'none', cursor: 'pointer',
              }}>{p}</button>
            ))}
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 18 }}>
          <span style={{ fontSize: 32, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.025em' }}>1,248</span>
          <Badge tone="green" dot>+34% vs prev</Badge>
        </div>

        <ChartArea />

        <div style={{
          display: 'flex', justifyContent: 'space-between', marginTop: 10,
          fontSize: 10.5, color: '#9499BA', fontWeight: 500,
        }}>
          {['May 13', 'May 15', 'May 17', 'May 19', 'May 21', 'May 23', 'May 25'].map(d => <span key={d}>{d}</span>)}
        </div>
      </Card>

      {/* AI recommendations */}
      <Card padding={22} style={{
        background: 'linear-gradient(160deg, #1A1659, #0D0F1A)',
        color: '#fff', border: 'none', position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -60, right: -60, width: 220, height: 220,
          background: 'radial-gradient(circle, rgba(0,192,75,0.25), transparent 65%)',
        }} />
        <div style={{ position: 'relative' }}>
          <Badge tone="green" dot>AI Recommendation</Badge>
          <div style={{ fontSize: 17, fontWeight: 700, marginTop: 14, lineHeight: 1.35, letterSpacing: '-0.01em' }}>
            Connect Chatbotistic with WooCommerce on ShopGlow
          </div>
          <p style={{ fontSize: 13, color: '#9499BA', lineHeight: 1.6, marginTop: 10, marginBottom: 0 }}>
            Your store has 218 order questions/week. An AI agent could resolve
            ~84% automatically and capture lost sales overnight.
          </p>
          <div style={{
            marginTop: 16, padding: '10px 12px',
            background: 'rgba(0,192,75,0.10)', border: '1px solid rgba(0,192,75,0.25)',
            borderRadius: 10, fontSize: 12.5, color: '#4ED48A',
            display: 'flex', alignItems: 'center', gap: 7,
          }}>
            <Icon name="spark" size={13} /> Projected: +$1,840 / mo
          </div>
          <Btn variant="white" size="sm" style={{ marginTop: 16, width: '100%', justifyContent: 'center' }} rightIcon="arrow">
            Set up agent
          </Btn>
        </div>
      </Card>

      {/* Recent activity */}
      <Card padding={22}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>Recent activity</div>
          <a href="#" onClick={e => e.preventDefault()} style={{ fontSize: 12, color: '#6C5CE7', textDecoration: 'none', fontWeight: 600 }}>View log</a>
        </div>
        <div>
          <ActivityRow icon="check" iconBg="#E8FAF0" iconColor="#00C04B"
            title="Memberistic license activated"
            meta="theclub.co · 1 / 1 seat used" time="2m" />
          <ActivityRow icon="download" iconBg="#F3F1FE" iconColor="#6C5CE7"
            title="Postistic v1.8.2 downloaded"
            meta="By Shuvo Roy" time="14m" />
          <ActivityRow icon="globe" iconBg="#E8FAF0" iconColor="#00C04B"
            title="Local Cafe site connected"
            meta="WordPress 6.5.3 · 2 plugins detected" time="1h" />
          <ActivityRow icon="zap" iconBg="#F3F1FE" iconColor="#6C5CE7"
            title="Abandoned cart automation ran"
            meta="42 carts · 11 recovered · $612 revenue" time="3h" />
          <ActivityRow icon="help" iconBg="#FEF3C7" iconColor="#92400E"
            title="Support ticket #1182 updated"
            meta="Reply from Sarah · Bookingistic" time="5h" />
        </div>
      </Card>
    </div>
  </div>
  );
};

// Donut
const Donut = ({ value, total }) => {
  const pct = value / total;
  const r = 36, c = 2 * Math.PI * r;
  return (
    <svg width={104} height={104} viewBox="0 0 100 100">
      <circle cx="50" cy="50" r={r} fill="none" stroke="#F0F2FF" strokeWidth="11" />
      {/* expiring soon - amber */}
      <circle cx="50" cy="50" r={r} fill="none" stroke="#F59E0B" strokeWidth="11"
        strokeDasharray={`${c / 12} ${c}`} strokeDashoffset={`-${(c * 10) / 12}`}
        transform="rotate(-90 50 50)" strokeLinecap="butt" />
      {/* needs update - red */}
      <circle cx="50" cy="50" r={r} fill="none" stroke="#EF4444" strokeWidth="11"
        strokeDasharray={`${(c * 2) / 12} ${c}`} strokeDashoffset={`-${(c * 11) / 12}`}
        transform="rotate(-90 50 50)" strokeLinecap="butt" />
      {/* active - green */}
      <circle cx="50" cy="50" r={r} fill="none" stroke="#00C04B" strokeWidth="11"
        strokeDasharray={`${(c * value) / total} ${c}`} transform="rotate(-90 50 50)" strokeLinecap="butt" />
      <text x="50" y="48" textAnchor="middle" fontSize="22" fontWeight="800" fill="#0D0F1A" style={{ letterSpacing: '-0.02em' }}>
        {Math.round(pct * 100)}%
      </text>
      <text x="50" y="64" textAnchor="middle" fontSize="9" fontWeight="700" fill="#6B7280" style={{ letterSpacing: '0.08em', textTransform: 'uppercase' }}>
        ACTIVE
      </text>
    </svg>
  );
};

// Chart - area
const ChartArea = () => (
  <svg viewBox="0 0 600 160" preserveAspectRatio="none" style={{ width: '100%', height: 160 }}>
    <defs>
      <linearGradient id="caGrad" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0%" stopColor="#6C5CE7" stopOpacity="0.30" />
        <stop offset="100%" stopColor="#6C5CE7" stopOpacity="0" />
      </linearGradient>
      <linearGradient id="caGrad2" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0%" stopColor="#00C04B" stopOpacity="0.22" />
        <stop offset="100%" stopColor="#00C04B" stopOpacity="0" />
      </linearGradient>
    </defs>
    {/* horizontal grid */}
    {[40, 80, 120].map(y => (
      <line key={y} x1="0" x2="600" y1={y} y2={y} stroke="#F0F2FF" strokeWidth="1" />
    ))}

    {/* purple area - main */}
    <path d="M0,120 C50,110 100,90 150,85 C200,80 240,95 280,75 C320,55 360,70 400,50 C440,30 480,40 520,25 C560,10 580,20 600,15 L600,160 L0,160 Z"
      fill="url(#caGrad)" />
    <path d="M0,120 C50,110 100,90 150,85 C200,80 240,95 280,75 C320,55 360,70 400,50 C440,30 480,40 520,25 C560,10 580,20 600,15"
      fill="none" stroke="#6C5CE7" strokeWidth="2.2" />

    {/* green area - secondary (AI agents) */}
    <path d="M0,140 C50,135 100,125 150,128 C200,131 240,118 280,115 C320,112 360,100 400,98 C440,96 480,85 520,80 C560,75 580,72 600,68 L600,160 L0,160 Z"
      fill="url(#caGrad2)" />
    <path d="M0,140 C50,135 100,125 150,128 C200,131 240,118 280,115 C320,112 360,100 400,98 C440,96 480,85 520,80 C560,75 580,72 600,68"
      fill="none" stroke="#00C04B" strokeWidth="2" strokeDasharray="3 4" />
  </svg>
);

Object.assign(window, { DashboardHome });
