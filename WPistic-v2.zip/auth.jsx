// auth.jsx — Login, register, forgot, workspace setup

const AuthShell = ({ children, onEnterApp, onHome }) => (
  <div className="scroll" style={{
    height: '100%', overflowY: 'auto',
    display: 'grid', gridTemplateColumns: '1fr 1.1fr',
    background: '#fff',
  }}>
    {/* Form side */}
    <div style={{ padding: '40px 56px', display: 'flex', flexDirection: 'column', minHeight: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 60 }}>
        <div style={{ cursor: 'pointer' }} onClick={onHome}><Logo size={28} /></div>
        <div style={{ fontSize: 13, color: '#6B7280' }}>Need help? <a href="#" onClick={e => e.preventDefault()} style={{ color: '#6C5CE7', textDecoration: 'none', fontWeight: 600 }}>Contact us</a></div>
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center' }}>
        <div style={{ width: '100%', maxWidth: 420, margin: '0 auto' }}>
          {children}
        </div>
      </div>
      <div style={{ fontSize: 11.5, color: '#9499BA', textAlign: 'center', marginTop: 40 }}>
        © 2026 WPistic · part of the WordPressistic ecosystem · <a href="#" onClick={e => e.preventDefault()} style={{ color: '#9499BA' }}>Terms</a> · <a href="#" onClick={e => e.preventDefault()} style={{ color: '#9499BA' }}>Privacy</a>
      </div>
    </div>

    {/* Showcase side */}
    <AuthShowcase />
  </div>
);

const AuthShowcase = () => (
  <div style={{
    background: 'linear-gradient(155deg, #1A1659 0%, #0D0F1A 60%, #0D0F1A 100%)',
    color: '#fff', position: 'relative', overflow: 'hidden',
    display: 'flex', flexDirection: 'column', justifyContent: 'center',
    padding: '56px 56px',
  }}>
    <div style={{
      position: 'absolute', top: -100, right: -150, width: 500, height: 500,
      background: 'radial-gradient(circle, rgba(108,92,231,0.45), transparent 65%)',
    }} />
    <div style={{
      position: 'absolute', bottom: -200, left: -150, width: 600, height: 600,
      background: 'radial-gradient(circle, rgba(0,192,75,0.20), transparent 65%)',
    }} />
    <div style={{ position: 'relative', maxWidth: 540 }}>
      <Badge tone="green" dot>Built for WordPress businesses</Badge>
      <div style={{
        fontSize: 44, fontWeight: 800, letterSpacing: '-0.035em',
        lineHeight: 1.1, marginTop: 18,
      }}>
        Eleven products. <br />
        <span style={{
          background: '#00C04B',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
        }}>One connected dashboard.</span>
      </div>
      <p style={{ fontSize: 16, color: '#9499BA', lineHeight: 1.6, marginTop: 20 }}>
        WPistic unifies your plugins, licenses, automations, AI agents, CRM,
        and analytics across every WordPress site you manage.
      </p>

      {/* Stats */}
      <div style={{ display: 'flex', gap: 36, marginTop: 36, paddingTop: 28, borderTop: '1px solid rgba(255,255,255,0.10)' }}>
        {[
          { v: '2,400+', l: 'Active workspaces' },
          { v: '11', l: 'Products in the suite' },
          { v: '4.9★', l: 'Customer rating' },
        ].map(s => (
          <div key={s.l}>
            <div style={{ fontSize: 26, fontWeight: 800, color: '#fff', letterSpacing: '-0.02em' }}>{s.v}</div>
            <div style={{ fontSize: 11, color: '#9499BA', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 4 }}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* Floating proof */}
      <div style={{
        marginTop: 40, padding: 18, borderRadius: 16,
        background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)',
        backdropFilter: 'blur(10px)',
      }}>
        <div style={{ fontSize: 14, color: '#fff', lineHeight: 1.6, marginBottom: 14 }}>
          "WPistic replaced four browser tabs and two spreadsheets — and our AI agents pay for the entire stack from week one."
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <AvatarCircle name="Marcus Reed" size={36} />
          <div>
            <div style={{ fontSize: 13, fontWeight: 700 }}>Marcus Reed</div>
            <div style={{ fontSize: 11.5, color: '#9499BA' }}>Founder · ByteFoundry Agency</div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const AuthInput = ({ label, type = 'text', placeholder, value, hint, right }) => (
  <label style={{ display: 'block', marginBottom: 16 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
      <span style={{ fontSize: 12.5, fontWeight: 700, color: '#0D0F1A' }}>{label}</span>
      {right}
    </div>
    <input type={type} defaultValue={value} placeholder={placeholder} style={{
      width: '100%', padding: '12px 16px',
      borderRadius: 12, border: '1.5px solid #E8EAFF',
      background: '#fff', fontSize: 14, color: '#0D0F1A', fontFamily: 'inherit',
      outline: 'none', transition: 'border-color 0.15s, box-shadow 0.15s',
    }} onFocus={e => { e.target.style.borderColor = '#6C5CE7'; e.target.style.boxShadow = '0 0 0 4px rgba(108,92,231,0.10)'; }}
       onBlur={e => { e.target.style.borderColor = '#E8EAFF'; e.target.style.boxShadow = 'none'; }} />
    {hint && <div style={{ fontSize: 11.5, color: '#9499BA', marginTop: 5 }}>{hint}</div>}
  </label>
);

const SSORow = () => (
  <div>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 18 }}>
      {[{n:'Google',l:'G'}, {n:'GitHub',l:'GH'}, {n:'Microsoft',l:'M'}].map(s => (
        <button key={s.n} style={{
          fontFamily: 'inherit', padding: '11px 12px',
          background: '#fff', border: '1.5px solid #E8EAFF', borderRadius: 12,
          color: '#0D0F1A', fontSize: 13, fontWeight: 600,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          cursor: 'pointer',
        }}>
          <span style={{
            width: 20, height: 20, borderRadius: 5,
            background: '#F0F2FF', color: '#5649CC',
            display: 'grid', placeItems: 'center', fontSize: 10, fontWeight: 800,
          }}>{s.l}</span>
          {s.n}
        </button>
      ))}
    </div>
    <div style={{ position: 'relative', textAlign: 'center', marginBottom: 18 }}>
      <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: 1, background: '#EDEFF8' }} />
      <span style={{ position: 'relative', background: '#fff', padding: '0 12px', fontSize: 11.5, color: '#9499BA', fontWeight: 600 }}>
        OR CONTINUE WITH EMAIL
      </span>
    </div>
  </div>
);

const LoginPage = ({ onEnterApp, onHome, onSwitch }) => (
  <AuthShell onEnterApp={onEnterApp} onHome={onHome}>
    <Badge tone="purple" dot>Sign in</Badge>
    <h1 style={{ fontSize: 30, fontWeight: 800, letterSpacing: '-0.025em', color: '#0D0F1A', margin: '14px 0 6px' }}>
      Welcome back.
    </h1>
    <p style={{ fontSize: 14, color: '#6B7280', margin: '0 0 28px', lineHeight: 1.6 }}>
      Sign in to manage your WordPress business stack.
    </p>

    <SSORow />

    <AuthInput label="Work email" type="email" placeholder="you@company.com" />
    <AuthInput label="Password" type="password" placeholder="••••••••••"
      right={<a href="#" onClick={e => { e.preventDefault(); onSwitch('forgot'); }} style={{ fontSize: 12, color: '#6C5CE7', textDecoration: 'none', fontWeight: 600 }}>Forgot?</a>} />

    <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: '#4B5263', marginBottom: 24, cursor: 'pointer' }}>
      <input type="checkbox" defaultChecked style={{ accentColor: '#6C5CE7' }} />
      Keep me signed in for 30 days
    </label>

    <Btn variant="primary" size="lg" onClick={onEnterApp} style={{ width: '100%', justifyContent: 'center' }} rightIcon="arrow">
      Sign in to WPistic
    </Btn>

    <div style={{ textAlign: 'center', marginTop: 24, fontSize: 13, color: '#6B7280' }}>
      New to WPistic?{' '}
      <a href="#" onClick={e => { e.preventDefault(); onSwitch('register'); }} style={{ color: '#6C5CE7', fontWeight: 600, textDecoration: 'none' }}>Create an account</a>
    </div>
  </AuthShell>
);

const RegisterPage = ({ onEnterApp, onHome, onSwitch }) => (
  <AuthShell onEnterApp={onEnterApp} onHome={onHome}>
    <Badge tone="green" dot>Free · No credit card</Badge>
    <h1 style={{ fontSize: 30, fontWeight: 800, letterSpacing: '-0.025em', color: '#0D0F1A', margin: '14px 0 6px' }}>
      Create your workspace.
    </h1>
    <p style={{ fontSize: 14, color: '#6B7280', margin: '0 0 28px', lineHeight: 1.6 }}>
      11 products. 1 dashboard. Connect your first site in under 5 minutes.
    </p>

    <SSORow />

    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
      <AuthInput label="Full name" placeholder="Jane Doe" />
      <AuthInput label="Work email" type="email" placeholder="jane@company.com" />
    </div>
    <AuthInput label="Workspace name" placeholder="Jane's Studio" hint="You can change this later." />
    <AuthInput label="Password" type="password" placeholder="Min. 8 characters" hint="At least one number and one symbol." />

    <label style={{ display: 'flex', alignItems: 'flex-start', gap: 8, fontSize: 12.5, color: '#4B5263', marginBottom: 22, cursor: 'pointer', lineHeight: 1.55 }}>
      <input type="checkbox" defaultChecked style={{ accentColor: '#6C5CE7', marginTop: 3 }} />
      <span>I agree to the <a href="#" onClick={e => e.preventDefault()} style={{ color: '#6C5CE7' }}>Terms</a> and <a href="#" onClick={e => e.preventDefault()} style={{ color: '#6C5CE7' }}>Privacy Policy</a>.</span>
    </label>

    <Btn variant="primary" size="lg" onClick={onEnterApp} style={{ width: '100%', justifyContent: 'center' }} rightIcon="arrow">
      Create workspace · Start free
    </Btn>

    <div style={{ textAlign: 'center', marginTop: 24, fontSize: 13, color: '#6B7280' }}>
      Already have an account?{' '}
      <a href="#" onClick={e => { e.preventDefault(); onSwitch('login'); }} style={{ color: '#6C5CE7', fontWeight: 600, textDecoration: 'none' }}>Sign in</a>
    </div>
  </AuthShell>
);

const ForgotPage = ({ onEnterApp, onHome, onSwitch }) => (
  <AuthShell onEnterApp={onEnterApp} onHome={onHome}>
    <div style={{
      width: 56, height: 56, borderRadius: 16,
      background: '#F3F1FE', color: '#6C5CE7',
      display: 'grid', placeItems: 'center', marginBottom: 18,
    }}>
      <Icon name="key" size={26} />
    </div>
    <h1 style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-0.025em', color: '#0D0F1A', margin: '0 0 8px' }}>
      Reset your password.
    </h1>
    <p style={{ fontSize: 14, color: '#6B7280', margin: '0 0 28px', lineHeight: 1.6 }}>
      Enter your work email and we'll send you a magic link to reset your password and sign in.
    </p>
    <AuthInput label="Work email" type="email" placeholder="you@company.com" />
    <Btn variant="primary" size="lg" onClick={onEnterApp} style={{ width: '100%', justifyContent: 'center' }} rightIcon="arrow">
      Send reset link
    </Btn>
    <div style={{ textAlign: 'center', marginTop: 24, fontSize: 13, color: '#6B7280' }}>
      Remembered it?{' '}
      <a href="#" onClick={e => { e.preventDefault(); onSwitch('login'); }} style={{ color: '#6C5CE7', fontWeight: 600, textDecoration: 'none' }}>Back to sign in</a>
    </div>
  </AuthShell>
);

const WorkspaceSetupPage = ({ onEnterApp, onHome }) => (
  <AuthShell onEnterApp={onEnterApp} onHome={onHome}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 20 }}>
      <StepDot active />
      <StepLine />
      <StepDot active />
      <StepLine />
      <StepDot />
    </div>
    <Badge tone="purple" dot>Step 2 of 3 · Workspace setup</Badge>
    <h1 style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-0.025em', color: '#0D0F1A', margin: '14px 0 6px' }}>
      Tell us about your business.
    </h1>
    <p style={{ fontSize: 14, color: '#6B7280', margin: '0 0 28px', lineHeight: 1.6 }}>
      We'll suggest the right products, automations, and AI agents to start with.
    </p>

    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 12.5, fontWeight: 700, color: '#0D0F1A', marginBottom: 10 }}>What best describes you?</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        {[
          { icon: 'cube', label: 'WooCommerce store', sub: 'Sell products', active: true },
          { icon: 'users', label: 'Agency', sub: 'Manage client sites' },
          { icon: 'members', label: 'Membership', sub: 'Recurring members', glyph: true },
          { icon: 'calendar', label: 'Bookings', sub: 'Appointments / tours', glyph: true },
        ].map(o => (
          <button key={o.label} style={{
            fontFamily: 'inherit', textAlign: 'left',
            padding: 14, borderRadius: 12,
            border: o.active ? '2px solid #6C5CE7' : '1.5px solid #E8EAFF',
            background: o.active ? '#F3F1FE' : '#fff',
            display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer',
          }}>
            <div style={{ width: 32, height: 32, borderRadius: 9, background: o.active?'#fff':'#F0F2FF', color: '#6C5CE7', display: 'grid', placeItems: 'center' }}>
              {o.glyph
                ? <ProductGlyph name={o.icon} color="#6C5CE7" bg="transparent" size={20} radius={0} />
                : <Icon name={o.icon} size={16} />}
            </div>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{o.label}</div>
              <div style={{ fontSize: 11.5, color: '#6B7280' }}>{o.sub}</div>
            </div>
          </button>
        ))}
      </div>
    </div>

    <AuthInput label="Your WordPress site URL" placeholder="https://yourstore.com" hint="We'll auto-detect your version and connect." />
    <AuthInput label="Number of sites you manage" placeholder="1–3 sites" />

    <div style={{ display: 'flex', gap: 8 }}>
      <Btn variant="ghost-gray" size="lg" style={{ flex: 1, justifyContent: 'center' }}>Back</Btn>
      <Btn variant="primary" size="lg" onClick={onEnterApp} style={{ flex: 2, justifyContent: 'center' }} rightIcon="arrow">Continue</Btn>
    </div>
  </AuthShell>
);

const StepDot = ({ active }) => (
  <div style={{
    width: 9, height: 9, borderRadius: 9999,
    background: active ? '#6C5CE7' : '#E5E7F2',
  }} />
);
const StepLine = () => <div style={{ flex: 1, maxWidth: 40, height: 2, background: '#E5E7F2' }} />;

Object.assign(window, { LoginPage, RegisterPage, ForgotPage, WorkspaceSetupPage });
