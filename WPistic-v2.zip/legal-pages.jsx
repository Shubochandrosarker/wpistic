// legal-pages.jsx — Privacy, Terms, Refunds, Security

const LEGAL_PAGES = {
  privacy: {
    badge: 'Privacy Policy',
    title: 'Your data, your business, your control.',
    updated: 'May 1, 2026',
    sub: 'How WPistic collects, uses, stores, and shares the data you and your customers entrust to us.',
    sections: [
      { id: 'overview', title: 'Overview', body: [
        "WPistic Inc. ('WPistic', 'we', 'us') provides a SaaS hub for managing WordPress plugins, licenses, AI agents, automations, and customer operations.",
        "This policy describes what data we collect from you and your customers, how we use it, who we share it with, and the rights you have.",
        "We never sell personal data. We never train shared AI models on your customer conversations without your written consent. We never lock your data inside our platform — export is always one click away.",
      ]},
      { id: 'what', title: 'What we collect', body: [
        "Account data: name, email, workspace name, company, billing details.",
        "Site connection data: URL, WordPress version, PHP version, installed WPistic plugins and their versions.",
        "Customer data (controlled by you): contacts, conversations, orders, bookings, and member records synced from your connected sites.",
        "Usage data: feature interactions, performance metrics, and error reports — used to make WPistic faster and more reliable.",
      ]},
      { id: 'why', title: 'Why we collect it', body: [
        "To deliver the service: run automations, sync sites, send messages, and process payments.",
        "To improve the product: aggregate, anonymized usage telemetry informs roadmap decisions.",
        "To keep you secure: detect abuse, prevent fraud, and meet legal obligations.",
        "We will never use your business data to train shared foundation models. Optional per-workspace AI training is opt-in and isolated.",
      ]},
      { id: 'shared', title: 'Who we share it with', body: [
        "Subprocessors: AWS, Stripe, OpenAI/Anthropic (optional), Twilio, Postmark — listed in full at wpistic.com/subprocessors.",
        "Legal authorities: only when compelled by valid legal process, and we will notify you unless legally prohibited.",
        "Acquirers: in the event of a merger or acquisition, your data transfers under the terms of this policy.",
      ]},
      { id: 'rights', title: 'Your rights', body: [
        "Access: download a full copy of your data at any time.",
        "Deletion: request permanent deletion — completed within 30 days.",
        "Correction: edit account and workspace data inline.",
        "Portability: export everything as CSV + JSON.",
        "EU/UK residents have additional rights under GDPR; California residents under CCPA. Contact privacy@wpistic.com to exercise them.",
      ]},
      { id: 'retention', title: 'How long we keep it', body: [
        "Active workspaces: data is retained as long as your account is active.",
        "Deleted accounts: 30-day soft-delete window, then permanent deletion within 90 days from backups.",
        "Legal/billing records: kept for 7 years per US tax law.",
      ]},
      { id: 'transfers', title: 'International transfers', body: [
        "Data is stored in AWS US-East by default. Agency and Enterprise plans can request EU or Asia-Pacific data residency.",
        "Cross-border transfers use Standard Contractual Clauses (SCCs) where applicable.",
      ]},
      { id: 'changes', title: 'Changes to this policy', body: [
        "We'll email account owners at least 30 days before any material change takes effect.",
      ]},
      { id: 'contact', title: 'Contact', body: [
        "Privacy questions: privacy@wpistic.com. Data Protection Officer: dpo@wpistic.com.",
        "Mailing address: WPistic Inc., 447 Broadway, 2nd Floor, New York, NY 10013, USA.",
      ]},
    ],
  },
  terms: {
    badge: 'Terms of Service',
    title: 'The rules of the road.',
    updated: 'May 1, 2026',
    sub: 'The agreement between you and WPistic when you use our platform, plugins, and APIs.',
    sections: [
      { id: 'accept', title: '1. Acceptance', body: [
        "By signing up for a WPistic workspace, downloading a plugin, or using our API, you agree to these terms and our Privacy Policy.",
        "If you're entering this agreement on behalf of a company, you confirm you have authority to bind that company.",
      ]},
      { id: 'service', title: '2. Description of service', body: [
        "WPistic provides a SaaS hub for managing WordPress plugins, licenses, AI agents, automations, CRM, inbox, and analytics.",
        "We provide the platform; you provide the WordPress sites, the customer relationships, and the content.",
      ]},
      { id: 'plans', title: '3. Plans, billing, and renewals', body: [
        "Free plans are free forever within stated limits. Paid plans auto-renew monthly or annually unless canceled.",
        "Annual plans are non-refundable after 14 days; monthly plans are non-refundable after the start of each billing cycle. See Refund Policy.",
        "Usage above plan limits is billed at published overage rates or paused until the next cycle, at your choice.",
      ]},
      { id: 'data', title: '4. Your data', body: [
        "You own everything you put into WPistic: contacts, content, conversations, and configurations.",
        "We process this data on your behalf as a data processor under our Privacy Policy.",
        "On termination, you have 60 days to export everything before permanent deletion.",
      ]},
      { id: 'acceptable', title: '5. Acceptable use', body: [
        "No spam, no abuse, no illegal content, no scraping, no reverse-engineering, no security probes without authorization, no impersonation of WPistic.",
        "AI agents and automations may not be used to mass-message non-consenting recipients or run prohibited industries (see full list at wpistic.com/aup).",
      ]},
      { id: 'ip', title: '6. Intellectual property', body: [
        "WPistic owns the platform, our plugins\' code, and our trademarks. You get a license to use them under these terms.",
        "Customer logos and content you put on your sites remain yours.",
      ]},
      { id: 'warranty', title: '7. Warranty and liability', body: [
        "WPistic is provided 'as is'. We aim for 99.9% uptime on Business and Agency plans and publish status at status.wpistic.com.",
        "Our total liability for any claim is capped at the fees you paid us in the prior 12 months.",
      ]},
      { id: 'term', title: '8. Term and termination', body: [
        "Either party may terminate at any time. We may suspend accounts for serious AUP violations, with notice where possible.",
      ]},
      { id: 'changes', title: '9. Changes to these terms', body: [
        "We'll email at least 30 days before any material change. Continued use after the effective date constitutes acceptance.",
      ]},
      { id: 'law', title: '10. Governing law', body: [
        "These terms are governed by the laws of New York, USA. Disputes go to arbitration in New York unless prohibited by your local law.",
      ]},
    ],
  },
  refunds: {
    badge: 'Refund Policy',
    title: 'Clear refunds, no fine print.',
    updated: 'May 1, 2026',
    sub: 'When you can get a refund, how long it takes, and what we ask in return.',
    sections: [
      { id: 'window', title: 'The 14-day no-questions window', body: [
        "Any new annual plan can be refunded in full within 14 days of purchase, no questions asked.",
        "New monthly plans can be refunded within 7 days of the initial purchase.",
        "After these windows, paid plans are non-refundable, but you can cancel anytime to prevent future charges.",
      ]},
      { id: 'how', title: 'How to request a refund', body: [
        "Email billing@wpistic.com from the workspace owner email. Include the workspace name and the invoice number.",
        "We process refunds within 3 business days. The amount returns to your original payment method within 5–10 business days, depending on your bank.",
      ]},
      { id: 'exclusions', title: "What's not refundable", body: [
        "Add-ons (AI conversation packs, extra sites, extra seats) once activated.",
        "Custom enterprise contracts are governed by their own MSA.",
        "Affiliate commission payouts (these belong to the affiliate, not WPistic).",
      ]},
      { id: 'switch', title: 'Switching plans', body: [
        "Upgrades are pro-rated automatically.",
        "Downgrades take effect at the next billing cycle; we don't refund the difference for the current cycle.",
      ]},
      { id: 'usage', title: 'Heavy usage', body: [
        "If you used more than the stated free tier (e.g. 5,000+ AI conversations on a refunded plan), we reserve the right to deduct prorated overage from the refund.",
      ]},
      { id: 'questions', title: 'Questions', body: [
        "billing@wpistic.com — we're real humans and reply within one business day.",
      ]},
    ],
  },
  security: {
    badge: 'Security',
    title: 'Security is the product.',
    updated: 'May 1, 2026',
    sub: 'How we protect your data, the standards we hold ourselves to, and how to report a vulnerability.',
    sections: [
      { id: 'principles', title: 'Our principles', body: [
        "Security is not a feature you turn on — it's how we build software.",
        "We treat your customer data the way we'd want our own treated: encrypted, least-privileged, logged, and never sold.",
      ]},
      { id: 'compliance', title: 'Compliance', body: [
        "SOC 2 Type I: completed Mar 2026. SOC 2 Type II: in progress, expected Q1 2027.",
        "GDPR: compliant. DPA available on Agency and Enterprise plans.",
        "HIPAA: BAA available on Enterprise plans for qualifying use cases.",
        "PCI: payment data never touches our servers — handled entirely by Stripe.",
      ]},
      { id: 'encryption', title: 'Encryption', body: [
        "All data is encrypted at rest with AES-256.",
        "All traffic is encrypted in transit with TLS 1.2+.",
        "Sensitive fields (API keys, OAuth tokens) are encrypted with per-workspace envelope keys via AWS KMS.",
      ]},
      { id: 'access', title: 'Access controls', body: [
        "All employee access requires SSO + hardware-key MFA.",
        "Production access is least-privilege, time-bounded, and logged.",
        "Two-person approval for any production data access.",
      ]},
      { id: 'monitoring', title: 'Monitoring & incident response', body: [
        "24/7 monitoring with on-call rotation across three time zones.",
        "Incident response runbooks tested quarterly.",
        "Customer notification within 72 hours of any confirmed breach affecting their data.",
      ]},
      { id: 'backups', title: 'Backups & disaster recovery', body: [
        "Continuous backups with point-in-time recovery for 30 days.",
        "Cross-region replication. Quarterly disaster-recovery exercises.",
        "RTO: 4 hours. RPO: 15 minutes.",
      ]},
      { id: 'reporting', title: 'Report a vulnerability', body: [
        "security@wpistic.com — encrypted via PGP key at wpistic.com/security.pgp.",
        "We run a private bug bounty on HackerOne. Email security@ for an invite.",
        "We commit to a response within 24 hours and a fix timeline within 5 business days for confirmed issues.",
      ]},
    ],
  },
};

const LegalPage = ({ slug, onNav }) => {
  const p = LEGAL_PAGES[slug];
  const [activeId, setActiveId] = React.useState(p.sections[0].id);
  if (!p) return null;
  return (
    <MarketingPage onNav={onNav}>
      <section style={{
        background: 'linear-gradient(155deg, #F3F1FE 0%, #EEF0FF 60%, #fff 130%)',
        padding: '56px 36px 32px',
      }}>
        <div style={{ maxWidth: 1180, margin: '0 auto' }}>
          <Badge tone="purple" dot>{p.badge}</Badge>
          <h1 style={{ fontSize: 44, fontWeight: 800, letterSpacing: '-0.03em', color: '#0D0F1A', lineHeight: 1.1, margin: '16px 0 12px', maxWidth: 760, textWrap: 'balance' }}>
            {p.title}
          </h1>
          <p style={{ fontSize: 16, color: '#4B5263', maxWidth: 700, lineHeight: 1.6, margin: 0 }}>{p.sub}</p>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 18, fontSize: 12.5, color: '#6B7280' }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
              <Icon name="refresh" size={14} color="#6C5CE7" /> Last updated <strong style={{ color: '#0D0F1A' }}>{p.updated}</strong>
            </span>
            <span style={{ width: 4, height: 4, borderRadius: 9999, background: '#D4D6E0' }} />
            <a onClick={() => onNav('contact')} style={{ color: '#6C5CE7', cursor: 'pointer', fontWeight: 700 }}>Email legal@wpistic.com</a>
          </div>
        </div>
      </section>

      <section style={{ padding: '40px 36px 80px', background: '#fff' }}>
        <div style={{
          maxWidth: 1180, margin: '0 auto',
          display: 'grid', gridTemplateColumns: '220px 1fr', gap: 48,
          alignItems: 'flex-start',
        }}>
          {/* Sticky TOC */}
          <aside style={{ position: 'sticky', top: 84 }}>
            <div style={{
              fontSize: 11, fontWeight: 700, color: '#9499BA',
              letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 14,
              paddingLeft: 14,
            }}>On this page</div>
            {p.sections.map(s => (
              <a key={s.id} onClick={() => { setActiveId(s.id); document.getElementById(s.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}
                style={{
                  display: 'block', padding: '8px 14px', fontSize: 13,
                  color: activeId === s.id ? '#5649CC' : '#4B5263',
                  background: activeId === s.id ? '#F3F1FE' : 'transparent',
                  fontWeight: activeId === s.id ? 700 : 500,
                  borderRadius: 8, textDecoration: 'none',
                  borderLeft: activeId === s.id ? '2px solid #6C5CE7' : '2px solid transparent',
                  cursor: 'pointer',
                  lineHeight: 1.4,
                }}>{s.title}</a>
            ))}

            <Card padding={20} style={{ marginTop: 32 }}>
              <SectionLabel>Need help?</SectionLabel>
              <p style={{ fontSize: 12.5, color: '#4B5263', lineHeight: 1.6, margin: '0 0 12px' }}>
                Questions about this policy? We respond to legal questions within one business day.
              </p>
              <Btn variant="primary" size="sm" rightIcon="arrow" style={{ width: '100%', justifyContent: 'center' }}
                onClick={() => onNav('contact')}>Contact legal</Btn>
            </Card>
          </aside>

          {/* Content */}
          <Card padding={48}>
            {p.sections.map(s => (
              <section key={s.id} id={s.id} style={{ marginBottom: 36, scrollMarginTop: 84 }}>
                <h2 style={{
                  fontSize: 22, fontWeight: 800, letterSpacing: '-0.02em',
                  color: '#0D0F1A', margin: '0 0 14px',
                  paddingBottom: 10, borderBottom: '1px solid #F0F2FF',
                }}>{s.title}</h2>
                {s.body.map((b, i) => (
                  <p key={i} style={{
                    fontSize: 14.5, color: '#2E3245', lineHeight: 1.85, margin: '0 0 12px',
                    textWrap: 'pretty',
                  }}>{b}</p>
                ))}
              </section>
            ))}

            <div style={{
              marginTop: 28, padding: 20,
              background: 'linear-gradient(120deg, #F3F1FE, #E8FAF0)',
              borderRadius: 14, border: '1px solid #E9E6FD',
              display: 'flex', alignItems: 'center', gap: 14,
            }}>
              <div style={{ width: 40, height: 40, borderRadius: 11, background: '#fff', color: '#6C5CE7', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                <Icon name="shield" size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A' }}>
                  {slug === 'security' ? 'Report a vulnerability' : 'Questions about this document?'}
                </div>
                <div style={{ fontSize: 12.5, color: '#4B5263', marginTop: 2 }}>
                  {slug === 'security' ? 'security@wpistic.com · PGP encrypted at wpistic.com/security.pgp' : 'legal@wpistic.com — real humans, one business day.'}
                </div>
              </div>
              <Btn variant="primary" size="sm" onClick={() => onNav('contact')}>Email us</Btn>
            </div>
          </Card>
        </div>
      </section>
    </MarketingPage>
  );
};

const PrivacyPage  = ({ onNav }) => <LegalPage slug="privacy"  onNav={onNav} />;
const TermsPage    = ({ onNav }) => <LegalPage slug="terms"    onNav={onNav} />;
const RefundsPage  = ({ onNav }) => <LegalPage slug="refunds"  onNav={onNav} />;
const SecurityPage = ({ onNav }) => <LegalPage slug="security" onNav={onNav} />;

Object.assign(window, { PrivacyPage, TermsPage, RefundsPage, SecurityPage });
