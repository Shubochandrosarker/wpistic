// analytics.jsx — Insightistic-powered unified analytics

const AnalyticsPage = () => {
  const [range, setRange] = React.useState('30D');
  const [site, setSite] = React.useState('All sites');

  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      <PageHeader
        eyebrow="Insightistic"
        title="Analytics"
        subtitle="Traffic, search, sales, AI usage, and growth across every connected WordPress site."
        actions={
          <>
            <SelectChip value={site} onChange={setSite}
              options={['All sites','shopglow.com','theclub.co','wanderly.travel','localcafe.com']} icon="globe" />
            <div style={{ display: 'inline-flex', background: '#fff', border: '1px solid #EDEFF8', borderRadius: 9999, padding: 3 }}>
              {['7D','30D','90D','YTD'].map(r => (
                <button key={r} onClick={() => setRange(r)} style={{
                  fontFamily: 'inherit', fontSize: 12, fontWeight: 600,
                  padding: '7px 12px', borderRadius: 9999,
                  background: range===r ? '#0D0F1A' : 'transparent',
                  color: range===r ? '#fff' : '#6B7280',
                  border: 'none', cursor: 'pointer',
                }}>{r}</button>
              ))}
            </div>
            <Btn variant="border-card" size="md" leftIcon="download">Export</Btn>
          </>
        } />

      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14, marginBottom: 18 }}>
        <KPI label="Visitors" v="28,247" d="+18%" tone="green" />
        <KPI label="Revenue" v="$48,902" d="+24%" tone="green" />
        <KPI label="AOV" v="$96.40" d="+4%" tone="green" />
        <KPI label="Conversion" v="3.4%" d="+0.6pt" tone="green" />
        <KPI label="AI deflection" v="84%" d="+9%" tone="green" />
      </div>

      {/* Main chart row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 16, marginBottom: 16 }}>
        <Card padding={24}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>Revenue & visitors</div>
              <div style={{ fontSize: 12, color: '#6B7280', marginTop: 2 }}>Daily — Last 30 days</div>
            </div>
            <div style={{ display: 'flex', gap: 14 }}>
              <Legend dot="#6C5CE7" label="Revenue" />
              <Legend dot="#00C04B" label="Visitors" />
            </div>
          </div>
          <BigChart />
        </Card>

        <Card padding={24}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>Traffic sources</div>
            <Btn variant="ghost-gray" size="xs">Details</Btn>
          </div>
          {[
            { name: 'Organic search',  pct: 42, c: '#6C5CE7', v: '11,864' },
            { name: 'Direct',          pct: 24, c: '#00C04B', v: '6,779' },
            { name: 'WhatsApp / chat', pct: 16, c: '#5649CC', v: '4,520' },
            { name: 'Social',          pct: 11, c: '#1A1659', v: '3,107' },
            { name: 'Email',           pct: 7,  c: '#F59E0B', v: '1,977' },
          ].map(s => (
            <div key={s.name} style={{ marginBottom: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: '#0D0F1A', fontWeight: 600, marginBottom: 5 }}>
                <span>{s.name}</span>
                <span style={{ color: '#6B7280' }}>{s.v} · {s.pct}%</span>
              </div>
              <div style={{ height: 6, background: '#F0F2FF', borderRadius: 9999, overflow: 'hidden' }}>
                <div style={{ width: s.pct + '%', height: '100%', background: s.c, borderRadius: 9999 }} />
              </div>
            </div>
          ))}
        </Card>
      </div>

      {/* 3-column row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16, marginBottom: 16 }}>
        <Card padding={22}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A', marginBottom: 4 }}>Search Console</div>
          <div style={{ fontSize: 11.5, color: '#6B7280', marginBottom: 14 }}>Clicks & impressions · 30d</div>
          <div style={{ display: 'flex', gap: 16, marginBottom: 14 }}>
            <div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>14.2k</div>
              <div style={{ fontSize: 11, color: '#9499BA', fontWeight: 600 }}>Clicks · +21%</div>
            </div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>328k</div>
              <div style={{ fontSize: 11, color: '#9499BA', fontWeight: 600 }}>Impressions · +14%</div>
            </div>
          </div>
          <SmallArea color="#6C5CE7" />
          <div style={{ marginTop: 12, fontSize: 11, color: '#6B7280' }}>Top: <strong style={{ color: '#0D0F1A' }}>aurora pendant lamp</strong></div>
        </Card>

        <Card padding={22}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A', marginBottom: 4 }}>WooCommerce revenue</div>
          <div style={{ fontSize: 11.5, color: '#6B7280', marginBottom: 14 }}>By product category</div>
          <BarChart data={[
            { l: 'Lighting',    v: 38, c: '#6C5CE7' },
            { l: 'Furniture',   v: 26, c: '#5649CC' },
            { l: 'Decor',       v: 18, c: '#00C04B' },
            { l: 'Outdoor',     v: 12, c: '#F59E0B' },
            { l: 'Accessories', v: 6,  c: '#9499BA' },
          ]} />
        </Card>

        <Card padding={22} dark>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginBottom: 4 }}>AI usage</div>
          <div style={{ fontSize: 11.5, color: '#9499BA', marginBottom: 14 }}>Chatbotistic + WPAgentistic</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 18 }}>
            <span style={{ fontSize: 30, fontWeight: 800, color: '#fff', letterSpacing: '-0.025em' }}>1.2k</span>
            <span style={{ fontSize: 12, color: '#4ED48A', fontWeight: 700 }}>+34%</span>
          </div>
          {[
            { l: 'Sales Agent Pro',   v: 624, pct: 50 },
            { l: 'Support Tier 1',    v: 412, pct: 33 },
            { l: 'Booking Assistant', v: 212, pct: 17 },
          ].map(a => (
            <div key={a.l} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5, color: '#9499BA', marginBottom: 4 }}>
                <span>{a.l}</span><span style={{ color: '#fff', fontWeight: 700 }}>{a.v}</span>
              </div>
              <div style={{ height: 4, background: '#1E2130', borderRadius: 9999, overflow: 'hidden' }}>
                <div style={{ width: a.pct + '%', height: '100%', background: '#00C04B' }} />
              </div>
            </div>
          ))}
        </Card>
      </div>

      {/* Bottom row — top pages + funnel */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>
        <Card padding={0}>
          <div style={{ padding: '18px 22px', borderBottom: '1px solid #F0F2FF', display: 'flex', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>Top pages</div>
              <div style={{ fontSize: 11.5, color: '#6B7280', marginTop: 2 }}>By revenue, last 30 days</div>
            </div>
            <Btn variant="ghost-gray" size="xs">All pages</Btn>
          </div>
          <table className="wpt">
            <thead>
              <tr>
                <th style={{ paddingLeft: 22 }}>Page</th>
                <th>Visitors</th>
                <th>Conv.</th>
                <th>Revenue</th>
                <th style={{ paddingRight: 22 }}>Trend</th>
              </tr>
            </thead>
            <tbody>
              {[
                { p: '/products/aurora-pendant',     v: '4,218', c: '6.4%', r: '$8,420', t: 'up' },
                { p: '/products/velvet-armchair',    v: '3,640', c: '4.2%', r: '$6,180', t: 'up' },
                { p: '/collections/lighting',        v: '2,847', c: '3.1%', r: '$4,920', t: 'up' },
                { p: '/products/marble-side-table',  v: '2,210', c: '2.8%', r: '$3,470', t: 'down' },
                { p: '/journal/lighting-guide',      v: '1,984', c: '1.2%', r: '$1,260', t: 'up' },
              ].map((row, i) => (
                <tr key={i}>
                  <td style={{ paddingLeft: 22, fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#0D0F1A', fontWeight: 600 }}>{row.p}</td>
                  <td style={{ fontSize: 13, fontWeight: 600, color: '#0D0F1A' }}>{row.v}</td>
                  <td style={{ fontSize: 12.5, color: '#6B7280' }}>{row.c}</td>
                  <td style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>{row.r}</td>
                  <td style={{ paddingRight: 22 }}>
                    <MiniSpark up={row.t === 'up'} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card padding={22}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>Conversion funnel</div>
              <div style={{ fontSize: 11.5, color: '#6B7280', marginTop: 2 }}>shopglow.com</div>
            </div>
          </div>
          {[
            { l: 'Visited site',    v: 28247, pct: 100, c: '#6C5CE7' },
            { l: 'Viewed product',  v: 14620, pct: 52,  c: '#5649CC' },
            { l: 'Added to cart',   v: 4218,  pct: 15,  c: '#00C04B' },
            { l: 'Checkout',        v: 2126,  pct: 7.5, c: '#007C2F' },
            { l: 'Purchased',       v: 968,   pct: 3.4, c: '#1A1659' },
          ].map((f, i) => (
            <div key={f.l} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 6 }}>
                <span style={{ color: '#0D0F1A', fontWeight: 600 }}>{f.l}</span>
                <span style={{ color: '#6B7280' }}>{fmt(f.v)} · {f.pct}%</span>
              </div>
              <div style={{
                height: 26, background: '#F0F2FF', borderRadius: 8,
                overflow: 'hidden', position: 'relative',
              }}>
                <div style={{
                  width: f.pct + '%', height: '100%',
                  background: f.c,
                  borderRadius: 8, transition: 'width 0.3s',
                }} />
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
};

const KPI = ({ label, v, d, tone }) => (
  <Card padding={20}>
    <div style={{ fontSize: 11.5, fontWeight: 700, color: '#6B7280', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{label}</div>
    <div style={{ fontSize: 26, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.025em', margin: '6px 0 4px' }}>{v}</div>
    <div style={{ fontSize: 11.5, fontWeight: 700, color: tone === 'green' ? '#00C04B' : '#EF4444' }}>↑ {d}</div>
  </Card>
);

const Legend = ({ dot, label }) => (
  <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, color: '#6B7280', fontWeight: 600 }}>
    <span style={{ width: 8, height: 8, borderRadius: 9999, background: dot }} />
    {label}
  </div>
);

const SelectChip = ({ value, onChange, options, icon }) => {
  const [open, setOpen] = React.useState(false);
  return (
    <div style={{ position: 'relative' }}>
      <button onClick={() => setOpen(!open)} style={{
        display: 'inline-flex', alignItems: 'center', gap: 8,
        padding: '9px 14px', borderRadius: 9999,
        background: '#fff', border: '1px solid #EDEFF8',
        fontSize: 13, fontWeight: 600, color: '#0D0F1A',
        cursor: 'pointer', fontFamily: 'inherit',
      }}>
        {icon && <Icon name={icon} size={14} color="#9499BA" />}
        {value} <Icon name="arrow" size={11} style={{ transform: 'rotate(90deg)' }} />
      </button>
      {open && (
        <div onMouseLeave={() => setOpen(false)} style={{
          position: 'absolute', top: '110%', left: 0, zIndex: 50,
          background: '#fff', border: '1px solid #EDEFF8', borderRadius: 12,
          boxShadow: '0 16px 40px rgba(108,92,231,0.18)', padding: 4, minWidth: 180,
        }}>
          {options.map(o => (
            <div key={o} onClick={() => { onChange(o); setOpen(false); }} style={{
              padding: '8px 12px', fontSize: 13, cursor: 'pointer', borderRadius: 8,
              background: value === o ? '#F3F1FE' : 'transparent',
              color: value === o ? '#5649CC' : '#4B5263', fontWeight: value === o ? 700 : 500,
            }}>{o}</div>
          ))}
        </div>
      )}
    </div>
  );
};

const BigChart = () => (
  <svg viewBox="0 0 800 240" preserveAspectRatio="none" style={{ width: '100%', height: 240 }}>
    <defs>
      <linearGradient id="bcGrad1" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0%" stopColor="#6C5CE7" stopOpacity="0.30" />
        <stop offset="100%" stopColor="#6C5CE7" stopOpacity="0" />
      </linearGradient>
    </defs>
    {[40, 80, 120, 160, 200].map(y => (
      <line key={y} x1="0" x2="800" y1={y} y2={y} stroke="#F0F2FF" strokeWidth="1" />
    ))}
    {/* Revenue purple */}
    <path d="M0,180 C40,170 80,160 120,150 C160,140 200,155 240,135 C280,120 320,130 360,110 C400,95 440,105 480,80 C520,65 560,70 600,50 C640,35 680,45 720,30 C760,18 780,25 800,15 L800,240 L0,240 Z"
      fill="url(#bcGrad1)" />
    <path d="M0,180 C40,170 80,160 120,150 C160,140 200,155 240,135 C280,120 320,130 360,110 C400,95 440,105 480,80 C520,65 560,70 600,50 C640,35 680,45 720,30 C760,18 780,25 800,15"
      fill="none" stroke="#6C5CE7" strokeWidth="2.5" />
    {/* Visitors green dashed */}
    <path d="M0,200 C40,195 80,185 120,182 C160,180 200,170 240,168 C280,165 320,150 360,148 C400,145 440,138 480,130 C520,122 560,118 600,110 C640,100 680,95 720,85 C760,75 780,72 800,65"
      fill="none" stroke="#00C04B" strokeWidth="2" strokeDasharray="3 5" />
  </svg>
);

const SmallArea = ({ color }) => (
  <svg viewBox="0 0 200 50" preserveAspectRatio="none" style={{ width: '100%', height: 50 }}>
    <defs>
      <linearGradient id={`sa-${color}`} x1="0" x2="0" y1="0" y2="1">
        <stop offset="0%" stopColor={color} stopOpacity="0.30" />
        <stop offset="100%" stopColor={color} stopOpacity="0" />
      </linearGradient>
    </defs>
    <path d="M0,38 C20,32 40,30 60,28 C80,26 100,18 120,16 C140,14 160,10 180,6 C190,4 200,2 200,2 L200,50 L0,50 Z"
      fill={`url(#sa-${color})`} />
    <path d="M0,38 C20,32 40,30 60,28 C80,26 100,18 120,16 C140,14 160,10 180,6 C190,4 200,2 200,2"
      fill="none" stroke={color} strokeWidth="2" />
  </svg>
);

const BarChart = ({ data }) => {
  const max = Math.max(...data.map(d => d.v));
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, height: 130, marginBottom: 12 }}>
      {data.map(d => (
        <div key={d.l} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#0D0F1A' }}>{d.v}%</div>
          <div style={{
            width: '100%', height: `${(d.v / max) * 86}%`,
            background: d.c, borderRadius: '6px 6px 2px 2px',
            minHeight: 6,
          }} />
          <div style={{ fontSize: 10.5, color: '#6B7280', fontWeight: 600, textAlign: 'center' }}>{d.l}</div>
        </div>
      ))}
    </div>
  );
};

const MiniSpark = ({ up }) => (
  <svg width="60" height="22" viewBox="0 0 60 22">
    <path d={up
      ? 'M0,18 L12,14 L24,16 L36,8 L48,10 L60,2'
      : 'M0,4 L12,8 L24,6 L36,14 L48,12 L60,18'}
      fill="none" stroke={up ? '#00C04B' : '#EF4444'} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

Object.assign(window, { AnalyticsPage });
