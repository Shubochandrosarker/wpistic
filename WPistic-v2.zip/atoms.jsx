// atoms.jsx — Shared atoms + icon system for WPistic
// All components attached to window at the bottom.

// ─────────────────────────────────────────────────────────────
// Icon — minimal line set, 1.75 stroke, Plus Jakarta sans feel
// ─────────────────────────────────────────────────────────────
const ICONS = {
  dashboard: 'M3 13h7V3H3v10zm0 8h7v-6H3v6zm11 0h7V11h-7v10zm0-18v6h7V3h-7z',
  cube: 'M21 7.5l-9-5-9 5m18 0l-9 5m9-5v9l-9 5m0-9L3 7.5m9 5v9m0-9V21M3 7.5v9l9 5',
  key: 'M15 7a4 4 0 11-3.9 4.95L8 14H6v2H4v2H2v-2l5.05-5.05A4 4 0 1115 7zm.5-1.5h.01',
  download: 'M12 4v12m0 0l-4-4m4 4l4-4M4 18h16v3H4z',
  globe: 'M21 12c0 5-4 9-9 9s-9-4-9-9 4-9 9-9 9 4 9 9zM3 12h18M12 3a14 14 0 010 18m0-18a14 14 0 000 18',
  bot: 'M12 2v3M6 7h12a3 3 0 013 3v9a3 3 0 01-3 3H6a3 3 0 01-3-3v-9a3 3 0 013-3zM9 13h.01M15 13h.01M9 17h6',
  zap: 'M13 2L3 14h7l-1 8L19 10h-7l1-8z',
  users: 'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zm14 10v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75',
  inbox: 'M22 12h-6l-2 3h-4l-2-3H2M5.45 5.11L2 12v6a2 2 0 002 2h16a2 2 0 002-2v-6l-3.45-6.89A2 2 0 0016.76 4H7.24a2 2 0 00-1.79 1.11z',
  chart: 'M3 3v18h18M7 14l4-4 4 4 5-5',
  card: 'M3 7a2 2 0 012-2h14a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V7zm0 4h18',
  help: 'M9 9a3 3 0 116 0c0 2-3 2-3 4M12 17h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
  code: 'M16 18l6-6-6-6M8 6l-6 6 6 6',
  cog: 'M12 15.5A3.5 3.5 0 1112 8.5a3.5 3.5 0 010 7zm7.4-3.5a7.4 7.4 0 00-.1-1.3l2-1.5-2-3.4-2.3.9a7.5 7.5 0 00-2.2-1.3L14.4 2h-4l-.4 2.4a7.5 7.5 0 00-2.2 1.3l-2.3-.9-2 3.4 2 1.5a7.4 7.4 0 000 2.6l-2 1.5 2 3.4 2.3-.9a7.5 7.5 0 002.2 1.3l.4 2.4h4l.4-2.4a7.5 7.5 0 002.2-1.3l2.3.9 2-3.4-2-1.5c.07-.43.1-.86.1-1.3z',
  search: 'M21 21l-4.35-4.35M11 17a6 6 0 100-12 6 6 0 000 12z',
  bell: 'M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0',
  plus: 'M12 5v14m-7-7h14',
  arrow: 'M5 12h14M13 5l7 7-7 7',
  check: 'M5 12l5 5L20 7',
  warn: 'M10.3 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0zM12 9v4m0 4h.01',
  copy: 'M20 9h-9a2 2 0 00-2 2v9a2 2 0 002 2h9a2 2 0 002-2v-9a2 2 0 00-2-2zM5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1',
  dots: 'M12 13a1 1 0 100-2 1 1 0 000 2zm0-7a1 1 0 100-2 1 1 0 000 2zm0 14a1 1 0 100-2 1 1 0 000 2z',
  filter: 'M22 3H2l8 9.46V19l4 2v-8.54L22 3z',
  refresh: 'M21 12a9 9 0 11-3.3-6.95M21 3v6h-6',
  external: 'M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3',
  spark: 'M12 3l1.9 5.6L19 10l-5.1 1.4L12 17l-1.9-5.6L5 10l5.1-1.4L12 3z',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  wp: 'M12 2a10 10 0 100 20 10 10 0 000-20zm-8 10a8 8 0 011-3.9l4.4 12a8 8 0 01-5.4-8.1zm8 8c-.8 0-1.6-.1-2.3-.3l2.4-7 2.5 6.8a7.9 7.9 0 01-2.6.5zm1.1-11.7c.5 0 .9 0 .9-.1.4 0 .4-.7 0-.7-1.4.1-3.4 0-3.4 0-.4 0-.5.7 0 .7 0 0 .4 0 .8.1l1.2 3.3-1.7 5.1L7.1 6.2l.9-.1c.4 0 .4-.7 0-.7 0 0-1.6.1-2.5.1A8 8 0 0112 4a8 8 0 016.8 3.7l-.2 0c-.7 0-1.2.6-1.2 1.3 0 .6.3 1.1.7 1.7.3.5.6 1.1.6 2 0 .6-.2 1.4-.6 2.4l-.7 2.4-2.6-7.7zm4 1c.4.7.6 1.4.6 2.2A8 8 0 0114 19.5l2.4-7c.5-1.1.6-2.1.6-2.9 0-.3 0-.6-.1-.8z',
};
const Icon = ({ name, size = 18, color, style, strokeWidth = 1.75 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color || 'currentColor'} strokeWidth={strokeWidth}
    strokeLinecap="round" strokeLinejoin="round" style={style}>
    <path d={ICONS[name]} />
  </svg>
);

// ─────────────────────────────────────────────────────────────
// Btn — pill-shaped, all variants
// ─────────────────────────────────────────────────────────────
const Btn = ({ children, variant = 'primary', size = 'md', onClick, style = {}, type = 'button', leftIcon, rightIcon }) => {
  const [hov, setHov] = React.useState(false);
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7,
    fontFamily: 'inherit', fontWeight: 600, border: 'none',
    borderRadius: 9999, cursor: 'pointer',
    transition: 'all 0.18s ease', whiteSpace: 'nowrap',
    letterSpacing: '-0.01em', lineHeight: 1,
    ...(size === 'xs' ? { padding: '6px 12px', fontSize: 12 } : {}),
    ...(size === 'sm' ? { padding: '8px 16px', fontSize: 13 } : {}),
    ...(size === 'md' ? { padding: '10px 20px', fontSize: 14 } : {}),
    ...(size === 'lg' ? { padding: '13px 28px', fontSize: 15 } : {}),
    ...(size === 'xl' ? { padding: '16px 36px', fontSize: 16, fontWeight: 700 } : {}),
  };
  const variants = {
    primary: { background: hov ? '#0A1A2E' : '#122843', color: '#fff',
      boxShadow: hov ? '0 6px 24px rgba(18,40,67,0.45)' : '0 2px 10px rgba(18,40,67,0.30)' },
    secondary: { background: hov ? '#1A1E2E' : '#0D0F1A', color: '#fff' },
    outline: { background: hov ? '#F3F1FE' : 'transparent', color: '#6C5CE7', border: '1.5px solid #6C5CE7' },
    ghost: { background: hov ? '#F3F1FE' : 'transparent', color: '#6C5CE7' },
    'ghost-gray': { background: hov ? '#F0F2FF' : 'transparent', color: '#4B5263' },
    soft: { background: hov ? '#E9E6FD' : '#F3F1FE', color: '#5649CC' },
    white: { background: '#fff', color: '#6C5CE7', boxShadow: '0 2px 12px rgba(0,0,0,0.10)' },
    green: { background: hov ? '#009E3D' : '#00C04B', color: '#fff',
      boxShadow: hov ? '0 6px 24px rgba(0,192,75,0.40)' : '0 2px 10px rgba(0,192,75,0.25)' },
    'dark-outline': { background: hov ? 'rgba(255,255,255,0.05)' : 'transparent',
      color: 'rgba(255,255,255,0.92)', border: '1.5px solid rgba(255,255,255,0.22)' },
    'border-card': { background: hov ? '#F8F9FF' : '#fff', color: '#0D0F1A',
      border: '1px solid #E8EAFF' },
    danger: { background: hov ? '#DC2626' : '#EF4444', color: '#fff' },
  };
  return (
    <button type={type} style={{ ...base, ...variants[variant], ...style }}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      onClick={onClick}>
      {leftIcon && <Icon name={leftIcon} size={size === 'xl' ? 18 : 15} />}
      {children}
      {rightIcon && <Icon name={rightIcon} size={size === 'xl' ? 18 : 15} />}
    </button>
  );
};

// ─────────────────────────────────────────────────────────────
// Badge — status pills
// ─────────────────────────────────────────────────────────────
const BADGE_THEMES = {
  purple: { bg: '#E9E6FD', fg: '#5649CC', dot: '#6C5CE7' },
  green:  { bg: '#E8FAF0', fg: '#007C2F', dot: '#00C04B' },
  amber:  { bg: '#FEF3C7', fg: '#92400E', dot: '#F59E0B' },
  red:    { bg: '#FEE2E2', fg: '#991B1B', dot: '#EF4444' },
  gray:   { bg: '#F0F2FF', fg: '#4B5263', dot: '#9499BA' },
  blue:   { bg: '#DBEAFE', fg: '#1E40AF', dot: '#3B82F6' },
  dark:   { bg: '#0D0F1A', fg: '#fff',    dot: '#fff' },
};
const Badge = ({ children, tone = 'purple', dot = false, style = {} }) => {
  const t = BADGE_THEMES[tone];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: dot ? 6 : 0,
      fontSize: 11, fontWeight: 700, letterSpacing: '0.06em',
      textTransform: 'uppercase', color: t.fg, background: t.bg,
      borderRadius: 9999, padding: '4px 10px', whiteSpace: 'nowrap',
      ...style,
    }}>
      {dot && <span style={{ width: 6, height: 6, background: t.dot, borderRadius: 9999 }} />}
      {children}
    </span>
  );
};

// ─────────────────────────────────────────────────────────────
// Card — base surface
// ─────────────────────────────────────────────────────────────
const Card = ({ children, style = {}, padding = 24, dark = false, hoverable = false }) => {
  const [hov, setHov] = React.useState(false);
  return (
    <div onMouseEnter={() => hoverable && setHov(true)} onMouseLeave={() => hoverable && setHov(false)}
      style={{
        background: dark ? '#13161F' : '#fff',
        borderRadius: 20,
        border: dark ? '1px solid #1E2130' : '1px solid #EDEFF8',
        boxShadow: hoverable && hov
          ? '0 16px 44px rgba(108,92,231,0.16)'
          : '0 2px 12px rgba(108,92,231,0.05)',
        transition: 'all 0.22s cubic-bezier(0.34, 1.56, 0.64, 1)',
        transform: hoverable && hov ? 'translateY(-3px)' : 'translateY(0)',
        padding,
        ...style,
      }}>
      {children}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// Section heading + label
// ─────────────────────────────────────────────────────────────
const SectionLabel = ({ children, light, color, style = {} }) => (
  <div style={{
    fontSize: 11, fontWeight: 700, letterSpacing: '0.12em',
    textTransform: 'uppercase',
    color: color || (light ? '#9499BA' : '#6C5CE7'),
    marginBottom: 14, ...style,
  }}>{children}</div>
);

// ─────────────────────────────────────────────────────────────
// Logo lockup
// ─────────────────────────────────────────────────────────────
const Logo = ({ variant = 'purple', size = 28, showText = true, dark = false }) => (
  <div style={{ display: 'inline-flex', alignItems: 'center', gap: 9 }}>
    <img src={`assets/logo-${variant}.png`} alt="WPistic"
      style={{ width: size, height: size, objectFit: 'contain' }} />
    {showText && (
      <span style={{
        fontSize: size * 0.6 + 1, fontWeight: 800,
        color: dark ? '#fff' : '#0D0F1A', letterSpacing: '-0.03em',
      }}>WPistic</span>
    )}
  </div>
);

// ─────────────────────────────────────────────────────────────
// Input
// ─────────────────────────────────────────────────────────────
const TextInput = ({ value, onChange, placeholder, icon, style = {}, size = 'md' }) => {
  const [focused, setFocused] = React.useState(false);
  const h = size === 'sm' ? 34 : 40;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 9,
      height: h, padding: '0 14px',
      borderRadius: 9999,
      background: '#fff',
      border: focused ? '1.5px solid #6C5CE7' : '1.5px solid #E8EAFF',
      transition: 'border-color 0.15s, box-shadow 0.15s',
      boxShadow: focused ? '0 0 0 4px rgba(108,92,231,0.10)' : 'none',
      ...style,
    }}>
      {icon && <Icon name={icon} size={15} color="#9499BA" />}
      <input value={value || ''}
        onChange={e => onChange && onChange(e.target.value)}
        onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
        placeholder={placeholder}
        style={{
          flex: 1, border: 'none', outline: 'none', background: 'transparent',
          fontSize: 13.5, color: '#0D0F1A', fontFamily: 'inherit',
        }} />
    </div>
  );
};

// Helpers
const fmt = (n) => n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

Object.assign(window, { Icon, Btn, Badge, Card, SectionLabel, Logo, TextInput, fmt });
