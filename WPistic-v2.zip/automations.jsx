// automations.jsx — Visual automation builder + runs

const AUTOMATIONS = [
  { name: 'Cart recovery → WhatsApp', trigger: 'cart', triggerLabel: 'Cart abandoned 15 min',
    action: 'chat', actionLabel: 'WhatsApp recovery message',
    site: 'shopglow.com', status: 'Active', runs: 612, lastRun: '8 min ago', success: 87 },
  { name: 'New order → SMS confirm', trigger: 'cube', triggerLabel: 'WooCommerce order created',
    action: 'chat', actionLabel: 'Send SMS confirmation',
    site: 'shopglow.com', status: 'Active', runs: 287, lastRun: '11 min ago', success: 99 },
  { name: 'Booking → confirmation email', trigger: 'calendar', triggerLabel: 'New booking',
    action: 'inbox', actionLabel: 'Send confirmation + reminder',
    site: 'wanderly.travel', status: 'Active', runs: 142, lastRun: '34 min ago', success: 98 },
  { name: 'License expiring → renewal email', trigger: 'key', triggerLabel: 'License expires in 14 days',
    action: 'inbox', actionLabel: 'Send renewal email + Slack DM',
    site: 'WPistic core', status: 'Active', runs: 8, lastRun: '2 hr ago', success: 100 },
  { name: 'New ticket → assign agent', trigger: 'help', triggerLabel: 'Support ticket created',
    action: 'users', actionLabel: 'Auto-assign by product',
    site: 'WPistic core', status: 'Active', runs: 41, lastRun: '5 hr ago', success: 100 },
  { name: 'Member churn risk → win-back', trigger: 'members', triggerLabel: 'Member at churn risk',
    action: 'chat', actionLabel: 'AI win-back conversation',
    site: 'theclub.co', status: 'Paused', runs: 19, lastRun: '2 days ago', success: 72 },
  { name: 'Review request after delivery', trigger: 'cube', triggerLabel: 'Order delivered + 3 days',
    action: 'chat', actionLabel: 'WhatsApp review prompt',
    site: 'shopglow.com', status: 'Draft', runs: 0, lastRun: '—', success: 0 },
];

const TRIGGER_ICONS = { cart: 'card', cube: 'cube', calendar: 'cube', key: 'key', help: 'help', members: 'users' };
const ACTION_ICONS = { chat: 'inbox', inbox: 'inbox', users: 'users' };

const RUNS = [
  { time: '11:42', flow: 'Cart recovery → WhatsApp', result: 'Success', detail: 'Sent message to +1 845 322 1199 · cart $128', tone: 'green' },
  { time: '11:34', flow: 'New order → SMS confirm', result: 'Success', detail: 'Order #4218 · $158.00 · ShopGlow', tone: 'green' },
  { time: '11:20', flow: 'Booking → confirmation email', result: 'Success', detail: 'Tour: Highlands 4-day · Sarah Lin', tone: 'green' },
  { time: '11:02', flow: 'Cart recovery → WhatsApp', result: 'Success', detail: 'Recovered: $84.20 cart', tone: 'green' },
  { time: '10:48', flow: 'Member churn risk → win-back', result: 'Skipped', detail: 'Quiet hours · queued for 09:00', tone: 'gray' },
  { time: '10:32', flow: 'License expiring → renewal email', result: 'Success', detail: 'Sent to wanderly.travel owner', tone: 'green' },
  { time: '10:18', flow: 'New ticket → assign agent', result: 'Failed', detail: 'No agent available for Bookingistic · retried 3x', tone: 'red' },
  { time: '10:04', flow: 'New order → SMS confirm', result: 'Success', detail: 'Order #4217 · $42.00', tone: 'green' },
];

const AutomationsPage = () => {
  const [tab, setTab] = React.useState('Flows');
  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      <PageHeader
        eyebrow="Automations"
        title="Automation builder"
        subtitle="When-this-then-that flows across WooCommerce, bookings, members, CRM, and support."
        actions={
          <>
            <Btn variant="border-card" size="md" leftIcon="code">Templates</Btn>
            <Btn variant="primary" size="md" leftIcon="plus">Create automation</Btn>
          </>
        } />

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14, marginBottom: 22 }}>
        <MiniStat label="Active flows" value="5" icon="zap" iconBg="#F3F1FE" iconColor="#6C5CE7" />
        <MiniStat label="Runs this month" value="2,847" icon="refresh" iconBg="#E8FAF0" iconColor="#00C04B" />
        <MiniStat label="Success rate" value="96.4%" icon="check" iconBg="#E8FAF0" iconColor="#00C04B" />
        <MiniStat label="Revenue attributed" value="$8,420" icon="card" iconBg="#F3F1FE" iconColor="#6C5CE7" />
      </div>

      {/* Sub tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, borderBottom: '1px solid #EDEFF8' }}>
        {['Flows', 'Run log', 'Templates'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            fontFamily: 'inherit', fontSize: 13.5, fontWeight: 600,
            padding: '10px 14px', background: 'transparent', border: 'none',
            color: tab===t ? '#0D0F1A' : '#6B7280', cursor: 'pointer',
            borderBottom: tab===t ? '2px solid #6C5CE7' : '2px solid transparent',
            marginBottom: -1,
          }}>{t}</button>
        ))}
      </div>

      {tab === 'Flows' && <FlowsTable />}
      {tab === 'Run log' && <RunLog />}
      {tab === 'Templates' && <TemplateGrid />}
    </div>
  );
};

const FlowsTable = () => (
  <Card padding={0}>
    <table className="wpt">
      <thead>
        <tr>
          <th style={{ paddingLeft: 22 }}>Automation</th>
          <th>Trigger → Action</th>
          <th>Site</th>
          <th>Runs</th>
          <th>Success</th>
          <th>Last run</th>
          <th>Status</th>
          <th style={{ paddingRight: 22 }}></th>
        </tr>
      </thead>
      <tbody>
        {AUTOMATIONS.map((a, i) => (
          <tr key={i}>
            <td style={{ paddingLeft: 22 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                <div style={{
                  width: 32, height: 32, borderRadius: 9, background: '#F3F1FE',
                  color: '#6C5CE7', display: 'grid', placeItems: 'center',
                }}>
                  <Icon name="zap" size={15} />
                </div>
                <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{a.name}</div>
              </div>
            </td>
            <td>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12 }}>
                <FlowNode icon={TRIGGER_ICONS[a.trigger]} label={a.triggerLabel} color="#6C5CE7" bg="#F3F1FE" />
                <Icon name="arrow" size={12} color="#9499BA" />
                <FlowNode icon={ACTION_ICONS[a.action]} label={a.actionLabel} color="#00C04B" bg="#E8FAF0" />
              </div>
            </td>
            <td style={{ fontSize: 12.5, color: '#6B7280' }}>{a.site}</td>
            <td style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>{fmt(a.runs)}</td>
            <td>
              {a.runs > 0 ? (
                <div style={{ minWidth: 80 }}>
                  <div style={{ fontSize: 12, color: '#0D0F1A', fontWeight: 600, marginBottom: 3 }}>{a.success}%</div>
                  <div style={{ height: 4, background: '#F0F2FF', borderRadius: 9999, overflow: 'hidden' }}>
                    <div style={{
                      width: a.success + '%', height: '100%',
                      background: a.success > 90 ? '#00C04B' : a.success > 70 ? '#F59E0B' : '#EF4444',
                    }} />
                  </div>
                </div>
              ) : <span style={{ color: '#9499BA', fontSize: 12 }}>—</span>}
            </td>
            <td style={{ fontSize: 12, color: '#9499BA' }}>{a.lastRun}</td>
            <td>
              <Badge tone={a.status==='Active'?'green':a.status==='Paused'?'amber':'gray'} dot>{a.status}</Badge>
            </td>
            <td style={{ paddingRight: 22, textAlign: 'right' }}>
              <ToggleSwitch on={a.status === 'Active'} />
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </Card>
);

const FlowNode = ({ icon, label, color, bg }) => (
  <div style={{
    display: 'inline-flex', alignItems: 'center', gap: 6,
    padding: '4px 9px 4px 5px',
    background: bg, color, borderRadius: 9999,
    fontSize: 11.5, fontWeight: 600,
    border: '1px solid ' + bg,
  }}>
    <div style={{ width: 18, height: 18, borderRadius: 5, background: '#fff', display: 'grid', placeItems: 'center' }}>
      <Icon name={icon} size={11} />
    </div>
    {label}
  </div>
);

const ToggleSwitch = ({ on }) => (
  <div style={{
    width: 36, height: 20, borderRadius: 9999,
    background: on ? '#00C04B' : '#E5E7F2',
    position: 'relative', cursor: 'pointer', transition: 'background 0.2s',
    boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.06)',
  }}>
    <div style={{
      position: 'absolute', top: 2, left: on ? 18 : 2,
      width: 16, height: 16, borderRadius: 9999,
      background: '#fff', transition: 'left 0.2s',
      boxShadow: '0 2px 4px rgba(0,0,0,0.18)',
    }} />
  </div>
);

const RunLog = () => (
  <Card padding={0}>
    <div style={{ padding: '16px 22px', borderBottom: '1px solid #F0F2FF', display: 'flex', justifyContent: 'space-between' }}>
      <div style={{ fontSize: 14, fontWeight: 700, color: '#0D0F1A' }}>Latest runs · today</div>
      <div style={{ display: 'flex', gap: 6 }}>
        <Btn variant="ghost-gray" size="xs" leftIcon="filter">Filter</Btn>
        <Btn variant="ghost-gray" size="xs" leftIcon="refresh">Refresh</Btn>
      </div>
    </div>
    {RUNS.map((r, i) => (
      <div key={i} style={{
        display: 'flex', alignItems: 'center', gap: 14,
        padding: '14px 22px', borderBottom: i < RUNS.length - 1 ? '1px solid #F0F2FF' : 'none',
      }}>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 11.5, color: '#9499BA', width: 50,
        }}>{r.time}</div>
        <div style={{
          width: 8, height: 8, borderRadius: 9999,
          background: r.tone === 'green' ? '#00C04B' : r.tone === 'red' ? '#EF4444' : '#9499BA',
        }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#0D0F1A' }}>{r.flow}</div>
          <div style={{ fontSize: 12, color: '#6B7280', marginTop: 1 }}>{r.detail}</div>
        </div>
        <Badge tone={r.tone === 'green' ? 'green' : r.tone === 'red' ? 'red' : 'gray'} dot>{r.result}</Badge>
        <Btn variant="ghost-gray" size="xs">View</Btn>
      </div>
    ))}
  </Card>
);

const TEMPLATES = [
  { name: 'Cart recovery', icon: 'card', desc: 'Abandoned cart → WhatsApp follow-up with discount', tone: 'green' },
  { name: 'Order confirmation', icon: 'cube', desc: 'New WooCommerce order → multi-channel confirm', tone: 'purple' },
  { name: 'Booking reminder', icon: 'calendar', desc: 'Booking → 24h before reminder + 1h ping', tone: 'green' },
  { name: 'Lead routing', icon: 'users', desc: 'Form submit → assign + Slack DM to sales rep', tone: 'purple' },
  { name: 'Win-back flow', icon: 'members', desc: 'Inactive 30d → personalized re-engage offer', tone: 'green' },
  { name: 'Review request', icon: 'spark', desc: 'Delivered + 3d → ask for review (multi-channel)', tone: 'purple' },
  { name: 'License renewal', icon: 'key', desc: 'License expires in 14d → email + in-app banner', tone: 'green' },
  { name: 'Ticket triage', icon: 'help', desc: 'Ticket created → AI classify + assign owner', tone: 'purple' },
];

const TemplateGrid = () => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
    {TEMPLATES.map((t, i) => {
      const c = t.tone === 'purple' ? { bg: '#F3F1FE', fg: '#6C5CE7' } : { bg: '#E8FAF0', fg: '#00C04B' };
      return (
        <Card key={i} hoverable padding={22}>
          <div style={{
            width: 40, height: 40, borderRadius: 11,
            background: c.bg, color: c.fg,
            display: 'grid', placeItems: 'center', marginBottom: 14,
          }}>
            <Icon name={TRIGGER_ICONS[t.icon] || t.icon} size={18} />
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A' }}>{t.name}</div>
          <p style={{ fontSize: 12.5, color: '#4B5263', lineHeight: 1.55, margin: '6px 0 16px', minHeight: 44 }}>{t.desc}</p>
          <Btn variant="ghost" size="xs" rightIcon="arrow">Use template</Btn>
        </Card>
      );
    })}
  </div>
);

Object.assign(window, { AutomationsPage });
