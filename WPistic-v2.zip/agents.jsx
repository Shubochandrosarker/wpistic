// agents.jsx — AI Agents marketplace + active agents

const AGENT_CATEGORIES = ['All', 'Sales', 'Support', 'SEO', 'Booking', 'WooCommerce', 'Operations'];

const AGENTS = [
  { id: 'sales-pro', name: 'Sales Agent Pro', cat: 'Sales', tone: 'green',
    desc: 'Closes WhatsApp + chat leads with WooCommerce product knowledge.',
    product: 'chatbotistic', site: 'shopglow.com', conv: 1248, status: 'Live', accuracy: 94, popular: true },
  { id: 'support-l1', name: 'Support Tier 1', cat: 'Support', tone: 'purple',
    desc: 'Resolves repeat questions instantly, escalates with full context.',
    product: 'chatbotistic', site: 'theclub.co', conv: 412, status: 'Live', accuracy: 91 },
  { id: 'booking-asst', name: 'Booking Assistant', cat: 'Booking', tone: 'green',
    desc: 'Books appointments, reschedules, and sends reminders across channels.',
    product: 'bookingistic', site: 'wanderly.travel', conv: 287, status: 'Live', accuracy: 96 },
  { id: 'seo-research', name: 'SEO Research', cat: 'SEO', tone: 'purple',
    desc: 'Audits pages, finds keyword gaps, drafts on-brand meta titles.',
    product: 'insightistic', site: '—', conv: 0, status: 'Setup', accuracy: 0 },
  { id: 'cart-recover', name: 'Cart Recovery', cat: 'WooCommerce', tone: 'green',
    desc: 'Re-engages abandoned carts via WhatsApp with personalized offers.',
    product: 'chatbotistic', site: 'shopglow.com', conv: 184, status: 'Live', accuracy: 88 },
  { id: 'review-gather', name: 'Review Gatherer', cat: 'Operations', tone: 'purple',
    desc: 'Asks happy customers for reviews on Google, Trustpilot, and your site.',
    product: 'crmistic', site: 'shopglow.com', conv: 96, status: 'Live', accuracy: 92 },
  { id: 'lead-qualify', name: 'Lead Qualifier', cat: 'Sales', tone: 'purple',
    desc: 'Scores inbound leads and routes hot prospects to your sales team.',
    product: 'crmistic', site: 'theclub.co', conv: 142, status: 'Live', accuracy: 89 },
  { id: 'ticket-trial', name: 'Ticket Triage', cat: 'Support', tone: 'green',
    desc: 'Tags, prioritizes, and assigns support tickets the moment they arrive.',
    product: 'chatbotistic', site: '—', conv: 0, status: 'Try', accuracy: 0 },
  { id: 'reorder-bot', name: 'Reorder Nudge', cat: 'WooCommerce', tone: 'green',
    desc: 'Predicts when consumables run out and prompts repeat purchase.',
    product: 'chatbotistic', site: '—', conv: 0, status: 'Try', accuracy: 0 },
];

const AgentsPage = () => {
  const [cat, setCat] = React.useState('All');
  const filtered = cat === 'All' ? AGENTS : AGENTS.filter(a => a.cat === cat);
  const liveAgents = AGENTS.filter(a => a.status === 'Live');

  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      <PageHeader
        eyebrow="WPAgentistic · Beta"
        title="AI Agents"
        subtitle="Drop-in agents for sales, support, SEO, bookings, and operations — connected to your sites."
        actions={
          <>
            <Btn variant="border-card" size="md" leftIcon="bot">Agent docs</Btn>
            <Btn variant="primary" size="md" leftIcon="plus">Create custom agent</Btn>
          </>
        } />

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14, marginBottom: 22 }}>
        <MiniStat label="Active agents" value={liveAgents.length} icon="bot" iconBg="#E9E6FD" iconColor="#6C5CE7" />
        <MiniStat label="Conversations (mo)" value="2,369" icon="chat" iconBg="#E8FAF0" iconColor="#00C04B" />
        <MiniStat label="Avg accuracy" value="92%" icon="check" iconBg="#E8FAF0" iconColor="#00C04B" />
        <MiniStat label="Hours saved" value="412 h" icon="zap" iconBg="#F3F1FE" iconColor="#6C5CE7" />
      </div>

      {/* Active agents row */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>Your active agents</div>
          <Btn variant="ghost-gray" size="sm" rightIcon="arrow">Manage all</Btn>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {liveAgents.slice(0, 3).map(a => <ActiveAgentCard key={a.id} agent={a} />)}
        </div>
      </div>

      {/* Marketplace */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end',
        marginBottom: 16, gap: 16, flexWrap: 'wrap',
      }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em' }}>Agent marketplace</div>
          <div style={{ fontSize: 13, color: '#6B7280', marginTop: 4 }}>Pick a template — ready in seconds.</div>
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {AGENT_CATEGORIES.map(c => (
            <button key={c} onClick={() => setCat(c)} style={{
              fontFamily: 'inherit', fontSize: 12.5, fontWeight: 600,
              padding: '7px 13px', borderRadius: 9999,
              background: cat===c ? '#6C5CE7' : '#fff',
              color: cat===c ? '#fff' : '#4B5263',
              border: cat===c ? '1px solid #6C5CE7' : '1px solid #EDEFF8',
              cursor: 'pointer',
            }}>{c}</button>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {filtered.map(a => <AgentMarketCard key={a.id} agent={a} />)}
        <CustomAgentCard />
      </div>
    </div>
  );
};

const ActiveAgentCard = ({ agent: a }) => {
  const p = PRODUCTS.find(p => p.id === a.product);
  return (
    <Card padding={22} hoverable>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <AgentAvatar tone={a.tone} />
        <Badge tone="green" dot>Live</Badge>
      </div>
      <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.01em' }}>{a.name}</div>
      <div style={{ fontSize: 11.5, color: '#6C5CE7', fontWeight: 600, marginTop: 2, marginBottom: 12 }}>{a.cat} · on {a.site}</div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
        <MiniStatInline label="Conversations" value={fmt(a.conv)} />
        <MiniStatInline label="Accuracy" value={a.accuracy + '%'} />
      </div>

      {/* progress bar (accuracy) */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ height: 5, background: '#F0F2FF', borderRadius: 9999, overflow: 'hidden' }}>
          <div style={{
            width: a.accuracy + '%', height: '100%',
            background: 'linear-gradient(90deg, #6C5CE7, #00C04B)',
            borderRadius: 9999,
          }} />
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8 }}>
        <Btn variant="primary" size="sm" style={{ flex: 1, justifyContent: 'center' }} rightIcon="arrow">Open</Btn>
        <Btn variant="border-card" size="sm" leftIcon="cog">Tune</Btn>
      </div>
    </Card>
  );
};

const AgentMarketCard = ({ agent: a }) => {
  const p = PRODUCTS.find(p => p.id === a.product);
  return (
    <Card padding={22} hoverable>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <AgentAvatar tone={a.tone} />
        {a.popular && <Badge tone="green" dot>Popular</Badge>}
        {a.status === 'Setup' && <Badge tone="amber" dot>Setup needed</Badge>}
        {a.status === 'Try' && <Badge tone="gray" dot>Available</Badge>}
        {a.status === 'Live' && <Badge tone="green" dot>Live</Badge>}
      </div>
      <div style={{ fontSize: 15, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.01em' }}>{a.name}</div>
      <div style={{ fontSize: 11.5, color: '#6C5CE7', fontWeight: 600, marginTop: 2, marginBottom: 10 }}>{a.cat}</div>
      <p style={{ fontSize: 13, color: '#4B5263', lineHeight: 1.55, margin: 0, minHeight: 56 }}>{a.desc}</p>

      <div style={{
        marginTop: 16, paddingTop: 14, borderTop: '1px solid #F0F2FF',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: '#6B7280', fontWeight: 600 }}>
          <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={18} radius={5} />
          {p.name}
        </div>
        <Btn variant={a.status === 'Live' ? 'border-card' : 'primary'} size="xs" rightIcon="arrow">
          {a.status === 'Live' ? 'Configure' : a.status === 'Setup' ? 'Set up' : 'Try agent'}
        </Btn>
      </div>
    </Card>
  );
};

const AgentAvatar = ({ tone }) => {
  const c = tone === 'green'
    ? { bg: 'linear-gradient(135deg, #E8FAF0, #C9F3DA)', fg: '#007C2F' }
    : { bg: 'linear-gradient(135deg, #F3F1FE, #DDD5FA)', fg: '#5649CC' };
  return (
    <div style={{
      width: 42, height: 42, borderRadius: 12,
      background: c.bg, color: c.fg,
      display: 'grid', placeItems: 'center',
      boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.5)',
    }}>
      <Icon name="bot" size={20} />
    </div>
  );
};

const MiniStatInline = ({ label, value }) => (
  <div>
    <div style={{ fontSize: 10, fontWeight: 700, color: '#9499BA', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{label}</div>
    <div style={{ fontSize: 17, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.02em', marginTop: 2 }}>{value}</div>
  </div>
);

const CustomAgentCard = () => (
  <div style={{
    background: 'linear-gradient(160deg, #1A1659, #0D0F1A)',
    borderRadius: 20, padding: 22,
    color: '#fff', position: 'relative', overflow: 'hidden',
    minHeight: 220, display: 'flex', flexDirection: 'column',
  }}>
    <div style={{
      position: 'absolute', top: -50, right: -50, width: 200, height: 200,
      background: 'radial-gradient(circle, rgba(0,192,75,0.30), transparent 65%)',
    }} />
    <div style={{ position: 'relative', flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div style={{
        width: 42, height: 42, borderRadius: 12,
        background: 'rgba(255,255,255,0.10)', color: '#4ED48A',
        display: 'grid', placeItems: 'center', marginBottom: 14,
      }}>
        <Icon name="spark" size={20} />
      </div>
      <div style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.01em' }}>Build a custom agent</div>
      <p style={{ fontSize: 13, color: '#9499BA', lineHeight: 1.55, margin: '8px 0 0', flex: 1 }}>
        Train an agent on your docs, knowledge base, products, and brand voice.
        No-code studio with prompts, tools, and channel routing.
      </p>
      <Btn variant="green" size="sm" style={{ marginTop: 14, justifyContent: 'center' }} rightIcon="arrow">
        Open studio
      </Btn>
    </div>
  </div>
);

Object.assign(window, { AgentsPage });
