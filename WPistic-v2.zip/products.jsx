// products.jsx — Product / Ecosystem marketplace page

const CATEGORIES = ['All', 'AI & Automation', 'WordPress Plugins', 'Business Tools', 'Analytics', 'Coming Soon'];

const ProductsPage = () => {
  const [cat, setCat] = React.useState('All');
  const [view, setView] = React.useState('grid'); // grid | list

  const filtered = PRODUCTS.filter(p => {
    if (cat === 'All') return true;
    if (cat === 'Coming Soon') return p.status === 'Coming Soon';
    return p.category === cat;
  });

  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      {/* Header */}
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        alignItems: 'flex-end', marginBottom: 24, gap: 24, flexWrap: 'wrap',
      }}>
        <div>
          <SectionLabel style={{ marginBottom: 8 }}>Ecosystem</SectionLabel>
          <h1 style={{
            fontSize: 30, fontWeight: 800, letterSpacing: '-0.025em',
            color: '#0D0F1A', lineHeight: 1.15, margin: 0,
          }}>
            Products
          </h1>
          <p style={{ fontSize: 14.5, color: '#6B7280', margin: '6px 0 0', lineHeight: 1.5 }}>
            Every WordPressistic product. Install, license, and manage from one place.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <TextInput placeholder="Search products…" icon="search" size="sm" style={{ width: 240 }} />
          <Btn variant="border-card" size="md" leftIcon="filter">Filters</Btn>
        </div>
      </div>

      {/* Highlight banner */}
      <div style={{
        marginBottom: 24,
        background: 'linear-gradient(120deg, #0D0F1A 0%, #1A1659 100%)',
        borderRadius: 20, padding: 28,
        position: 'relative', overflow: 'hidden',
        display: 'grid', gridTemplateColumns: '1fr auto', alignItems: 'center', gap: 32,
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(ellipse 400px 200px at 80% 50%, rgba(108,92,231,0.30), transparent 70%)',
        }} />
        <div style={{ position: 'relative' }}>
          <Badge tone="green" dot>New beta · WPAgentistic</Badge>
          <div style={{ fontSize: 22, fontWeight: 700, color: '#fff', marginTop: 12, letterSpacing: '-0.02em' }}>
            The AI Agent Marketplace is now in open beta
          </div>
          <p style={{ fontSize: 13.5, color: '#9499BA', lineHeight: 1.6, margin: '6px 0 0', maxWidth: 580 }}>
            18 ready-made AI agents for sales, support, bookings, SEO, and operations —
            plug into any WPistic-connected site in seconds.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 10, position: 'relative' }}>
          <Btn variant="white" size="md" rightIcon="arrow">Browse agents</Btn>
        </div>
      </div>

      {/* Category tabs + view toggle */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: 18, gap: 16, flexWrap: 'wrap',
      }}>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {CATEGORIES.map(c => {
            const count = c === 'All' ? PRODUCTS.length :
              c === 'Coming Soon' ? PRODUCTS.filter(p => p.status === 'Coming Soon').length :
              PRODUCTS.filter(p => p.category === c).length;
            const active = cat === c;
            return (
              <button key={c} onClick={() => setCat(c)} style={{
                fontFamily: 'inherit',
                padding: '8px 14px', borderRadius: 9999,
                fontSize: 13, fontWeight: 600,
                background: active ? '#0D0F1A' : '#fff',
                color: active ? '#fff' : '#4B5263',
                border: active ? '1px solid #0D0F1A' : '1px solid #EDEFF8',
                cursor: 'pointer', transition: 'all 0.15s',
                display: 'inline-flex', alignItems: 'center', gap: 7,
              }}>
                {c}
                <span style={{
                  fontSize: 10.5, fontWeight: 700,
                  background: active ? 'rgba(255,255,255,0.15)' : '#F0F2FF',
                  color: active ? '#fff' : '#6B7280',
                  padding: '1px 7px', borderRadius: 9999,
                }}>{count}</span>
              </button>
            );
          })}
        </div>
        <div style={{
          display: 'inline-flex', background: '#fff', border: '1px solid #EDEFF8',
          borderRadius: 9999, padding: 3,
        }}>
          {['grid', 'list'].map(v => (
            <button key={v} onClick={() => setView(v)} style={{
              fontFamily: 'inherit', fontSize: 12, fontWeight: 600,
              padding: '6px 14px', borderRadius: 9999,
              background: view === v ? '#F3F1FE' : 'transparent',
              color: view === v ? '#6C5CE7' : '#6B7280',
              border: 'none', cursor: 'pointer', textTransform: 'capitalize',
            }}>{v}</button>
          ))}
        </div>
      </div>

      {/* Grid */}
      {view === 'grid' ? (
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16,
        }}>
          {filtered.map(p => <ProductGridCard key={p.id} product={p} />)}
        </div>
      ) : (
        <Card padding={0}>
          <table className="wpt">
            <thead>
              <tr>
                <th style={{ paddingLeft: 22 }}>Product</th>
                <th>Category</th>
                <th>Status</th>
                <th>Your access</th>
                <th>Active sites</th>
                <th style={{ paddingRight: 22 }}></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p.id}>
                  <td style={{ paddingLeft: 22 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={36} radius={10} />
                      <div>
                        <div style={{ fontSize: 13.5, fontWeight: 700, color: '#0D0F1A' }}>{p.name}</div>
                        <div style={{ fontSize: 12, color: '#6B7280', marginTop: 2 }}>{p.tagline}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ fontSize: 12.5, color: '#6B7280' }}>{p.category}</td>
                  <td><Badge tone={STATUS_TONE[p.status]} dot>{p.status}</Badge></td>
                  <td><Badge tone={STATUS_TONE[p.access]}>{p.access}</Badge></td>
                  <td style={{ fontSize: 13, fontWeight: 600, color: '#0D0F1A' }}>{p.sites}</td>
                  <td style={{ paddingRight: 22, textAlign: 'right' }}>
                    <Btn variant="ghost" size="xs" rightIcon="arrow">
                      {p.status === 'Coming Soon' ? 'Notify me' : p.status === 'Beta' ? 'Join beta' : 'Manage'}
                    </Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {/* Empty hint when filtered has zero — not actually possible here */}
      {filtered.length === 0 && (
        <Card padding={48} style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#0D0F1A' }}>No products match this filter.</div>
        </Card>
      )}
    </div>
  );
};

const ProductGridCard = ({ product: p }) => (
  <Card hoverable padding={26} style={{ display: 'flex', flexDirection: 'column' }}>
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 18 }}>
      <ProductGlyph name={p.glyph} color={p.color} bg={p.bg} size={52} radius={15} />
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
        <Badge tone={STATUS_TONE[p.status]} dot>{p.status}</Badge>
        {p.flagship && <Badge tone="dark">Flagship</Badge>}
      </div>
    </div>

    <div style={{ fontSize: 18, fontWeight: 700, color: '#0D0F1A', letterSpacing: '-0.02em' }}>
      {p.name}
    </div>
    <div style={{ fontSize: 12.5, fontWeight: 600, color: '#6C5CE7', marginTop: 3, marginBottom: 10 }}>
      {p.tagline}
    </div>
    <p style={{ fontSize: 13.5, color: '#4B5263', lineHeight: 1.6, margin: 0, flex: 1 }}>
      {p.desc}
    </p>

    {/* Stats / metadata */}
    <div style={{
      marginTop: 18, paddingTop: 14,
      borderTop: '1px solid #F0F2FF',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div>
          <div style={{ fontSize: 10.5, fontWeight: 700, color: '#9499BA', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Category</div>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: '#0D0F1A', marginTop: 2 }}>{p.category}</div>
        </div>
        <div style={{ width: 1, height: 26, background: '#F0F2FF' }} />
        <div>
          <div style={{ fontSize: 10.5, fontWeight: 700, color: '#9499BA', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Sites</div>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: '#0D0F1A', marginTop: 2 }}>{p.sites}</div>
        </div>
      </div>
      <Badge tone={STATUS_TONE[p.access]}>{p.access}</Badge>
    </div>

    <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
      {p.status === 'Coming Soon' ? (
        <Btn variant="border-card" size="sm" style={{ flex: 1, justifyContent: 'center' }} leftIcon="bell">Notify me</Btn>
      ) : p.status === 'Beta' ? (
        <>
          <Btn variant="primary" size="sm" style={{ flex: 1, justifyContent: 'center' }}>Join beta</Btn>
          <Btn variant="border-card" size="sm">Learn more</Btn>
        </>
      ) : p.access === 'Active' ? (
        <>
          <Btn variant="primary" size="sm" style={{ flex: 1, justifyContent: 'center' }} rightIcon="arrow">Manage</Btn>
          <Btn variant="border-card" size="sm" leftIcon="download" />
        </>
      ) : (
        <Btn variant="primary" size="sm" style={{ flex: 1, justifyContent: 'center' }}>Get started</Btn>
      )}
    </div>
  </Card>
);

Object.assign(window, { ProductsPage });
