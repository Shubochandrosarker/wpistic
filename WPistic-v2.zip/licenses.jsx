// licenses.jsx — License Manager page

const LICENSE_STATS = [
  { label: 'Total licenses', value: '12', icon: 'key', bg: '#F3F1FE', fg: '#6C5CE7' },
  { label: 'Active', value: '10', icon: 'check', bg: '#E8FAF0', fg: '#00C04B' },
  { label: 'Expiring (30d)', value: '1', icon: 'warn', bg: '#FEF3C7', fg: '#92400E' },
  { label: 'Expired / suspended', value: '2', icon: 'warn', bg: '#FEE2E2', fg: '#991B1B' },
];

const LicensesPage = () => {
  const [tab, setTab] = React.useState('All');
  const [selected, setSelected] = React.useState(null);
  const [search, setSearch] = React.useState('');

  const tabs = ['All', 'Active', 'Expiring Soon', 'Expired', 'Free', 'Trial'];
  const counts = {
    'All': LICENSES.length,
    'Active': LICENSES.filter(l => l.status === 'Active').length,
    'Expiring Soon': LICENSES.filter(l => l.status === 'Expiring Soon').length,
    'Expired': LICENSES.filter(l => l.status === 'Expired' || l.status === 'Suspended').length,
    'Free': LICENSES.filter(l => l.status === 'Free').length,
    'Trial': LICENSES.filter(l => l.status === 'Trial').length,
  };

  let filtered = LICENSES;
  if (tab === 'Expired') filtered = LICENSES.filter(l => l.status === 'Expired' || l.status === 'Suspended');
  else if (tab !== 'All') filtered = LICENSES.filter(l => l.status === tab);
  if (search) {
    const s = search.toLowerCase();
    filtered = filtered.filter(l => {
      const product = PRODUCTS.find(p => p.id === l.product);
      return (product?.name.toLowerCase() || '').includes(s) ||
             l.key.toLowerCase().includes(s) ||
             l.domain.toLowerCase().includes(s);
    });
  }

  return (
    <div style={{ padding: '28px 32px 64px', maxWidth: 1380, margin: '0 auto' }}>
      {/* Header */}
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        alignItems: 'flex-end', marginBottom: 22, gap: 24, flexWrap: 'wrap',
      }}>
        <div>
          <SectionLabel style={{ marginBottom: 8 }}>License Manager</SectionLabel>
          <h1 style={{
            fontSize: 30, fontWeight: 800, letterSpacing: '-0.025em',
            color: '#0D0F1A', lineHeight: 1.15, margin: 0,
          }}>
            Licenses
          </h1>
          <p style={{ fontSize: 14.5, color: '#6B7280', margin: '6px 0 0', lineHeight: 1.5 }}>
            Manage activation, domains, and renewals across every WPistic product.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="border-card" size="md" leftIcon="download">Export CSV</Btn>
          <Btn variant="border-card" size="md" leftIcon="refresh">Sync</Btn>
          <Btn variant="primary" size="md" leftIcon="plus">Add license</Btn>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 22 }}>
        {LICENSE_STATS.map(s => (
          <Card key={s.label} padding={20}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ fontSize: 11.5, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#6B7280' }}>
                  {s.label}
                </div>
                <div style={{ fontSize: 28, fontWeight: 800, color: '#0D0F1A', letterSpacing: '-0.025em', marginTop: 6 }}>
                  {s.value}
                </div>
              </div>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: s.bg, color: s.fg,
                display: 'grid', placeItems: 'center',
              }}>
                <Icon name={s.icon} size={17} />
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Alert banner */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 14,
        padding: '14px 18px', borderRadius: 14,
        background: 'linear-gradient(90deg, #FEF3C7, #FEFAE0)',
        border: '1px solid #FCD34D', marginBottom: 22,
      }}>
        <div style={{
          width: 38, height: 38, borderRadius: 11,
          background: '#FCD34D', color: '#78350F',
          display: 'grid', placeItems: 'center', flexShrink: 0,
        }}>
          <Icon name="warn" size={18} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#78350F' }}>
            1 license expiring soon
          </div>
          <div style={{ fontSize: 12.5, color: '#92400E', marginTop: 2 }}>
            <strong>Bookingistic Pro</strong> on wanderly.travel expires in 14 days. Renew now to keep your bookings live.
          </div>
        </div>
        <Btn variant="primary" size="sm" rightIcon="arrow">Renew now</Btn>
        <Btn variant="ghost-gray" size="sm">Dismiss</Btn>
      </div>

      {/* Tabs + search */}
      <Card padding={0}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '16px 20px', borderBottom: '1px solid #F0F2FF', gap: 16, flexWrap: 'wrap',
        }}>
          <div style={{ display: 'flex', gap: 4 }}>
            {tabs.map(t => {
              const active = tab === t;
              return (
                <button key={t} onClick={() => setTab(t)} style={{
                  fontFamily: 'inherit', fontSize: 13, fontWeight: 600,
                  padding: '7px 12px', borderRadius: 9,
                  background: active ? '#F3F1FE' : 'transparent',
                  color: active ? '#5649CC' : '#6B7280',
                  border: 'none', cursor: 'pointer',
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                }}>
                  {t}
                  <span style={{
                    fontSize: 10.5, fontWeight: 700,
                    background: active ? 'rgba(108,92,231,0.18)' : '#F0F2FF',
                    color: active ? '#5649CC' : '#6B7280',
                    padding: '1px 7px', borderRadius: 9999,
                  }}>{counts[t]}</span>
                </button>
              );
            })}
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <TextInput placeholder="Search by product, key, or domain…" icon="search" size="sm" value={search} onChange={setSearch} style={{ width: 280 }} />
            <Btn variant="border-card" size="sm" leftIcon="filter">Filter</Btn>
          </div>
        </div>

        {/* Table */}
        <table className="wpt">
          <thead>
            <tr>
              <th style={{ paddingLeft: 22, width: 36 }}>
                <input type="checkbox" style={{ accentColor: '#6C5CE7' }} />
              </th>
              <th>Product / Plan</th>
              <th>License Key</th>
              <th>Status</th>
              <th>Domain</th>
              <th>Activations</th>
              <th>Expiry</th>
              <th>Version</th>
              <th style={{ paddingRight: 22, width: 60 }}></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((l, i) => {
              const product = PRODUCTS.find(p => p.id === l.product);
              return (
                <tr key={i}
                  onClick={() => setSelected(l)}
                  style={{ cursor: 'pointer' }}>
                  <td style={{ paddingLeft: 22 }} onClick={e => e.stopPropagation()}>
                    <input type="checkbox" style={{ accentColor: '#6C5CE7' }} />
                  </td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                      <ProductGlyph name={product.glyph} color={product.color} bg={product.bg} size={32} radius={9} />
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>{product.name}</div>
                        <div style={{ fontSize: 11.5, color: '#6B7280' }}>{l.plan}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <code style={{
                      fontFamily: 'JetBrains Mono, monospace', fontSize: 11.5,
                      background: '#F0F2FF', color: '#4B5263',
                      padding: '4px 9px', borderRadius: 6,
                      letterSpacing: '0.02em',
                    }}>{l.key.slice(0, 9)}…{l.key.slice(-4)}</code>
                  </td>
                  <td><Badge tone={STATUS_TONE[l.status]} dot>{l.status}</Badge></td>
                  <td style={{ fontSize: 12.5, color: '#0D0F1A', fontWeight: 500 }}>{l.domain}</td>
                  <td>
                    <ActivationsBar text={l.activations} />
                  </td>
                  <td style={{ fontSize: 12.5, color: '#4B5263' }}>{l.expiry}</td>
                  <td>
                    <code style={{
                      fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
                      color: '#6B7280',
                    }}>v{l.version}</code>
                  </td>
                  <td style={{ paddingRight: 22, textAlign: 'right' }} onClick={e => e.stopPropagation()}>
                    <button style={{
                      background: 'transparent', border: 'none', cursor: 'pointer',
                      width: 28, height: 28, borderRadius: 7,
                      display: 'grid', placeItems: 'center', color: '#6B7280',
                    }}
                      onMouseEnter={e => e.currentTarget.style.background = '#F0F2FF'}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                      <Icon name="dots" size={15} />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* Footer */}
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '14px 22px', fontSize: 12.5, color: '#6B7280',
          borderTop: '1px solid #F0F2FF',
        }}>
          <span>Showing {filtered.length} of {LICENSES.length} licenses</span>
          <div style={{ display: 'flex', gap: 4 }}>
            <button style={paginatorBtnStyle(false)}>←</button>
            <button style={paginatorBtnStyle(true)}>1</button>
            <button style={paginatorBtnStyle(false)}>2</button>
            <button style={paginatorBtnStyle(false)}>→</button>
          </div>
        </div>
      </Card>

      {selected && <LicenseDrawer license={selected} onClose={() => setSelected(null)} />}
    </div>
  );
};

const paginatorBtnStyle = (active) => ({
  fontFamily: 'inherit', fontSize: 12, fontWeight: 600,
  minWidth: 28, height: 28, padding: '0 8px', borderRadius: 7,
  background: active ? '#0D0F1A' : 'transparent',
  color: active ? '#fff' : '#6B7280',
  border: active ? '1px solid #0D0F1A' : '1px solid #EDEFF8',
  cursor: 'pointer',
});

// Activations bar (mini "2 / 3" with progress)
const ActivationsBar = ({ text }) => {
  const m = text.match(/(\d+)\s*\/\s*(\d+|Unlimited)/);
  let pct = 0;
  if (m) {
    const used = parseInt(m[1]);
    if (m[2] === 'Unlimited') pct = Math.min(used * 5, 100);
    else pct = (used / parseInt(m[2])) * 100;
  }
  return (
    <div style={{ minWidth: 100 }}>
      <div style={{ fontSize: 12, color: '#0D0F1A', fontWeight: 600, marginBottom: 4 }}>{text}</div>
      <div style={{ height: 4, background: '#F0F2FF', borderRadius: 9999, overflow: 'hidden' }}>
        <div style={{
          width: pct + '%', height: '100%',
          background: pct > 80 ? '#F59E0B' : '#6C5CE7',
          borderRadius: 9999,
        }} />
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// License Detail Drawer
// ─────────────────────────────────────────────────────────────
const LicenseDrawer = ({ license: l, onClose }) => {
  const product = PRODUCTS.find(p => p.id === l.product);
  const [copied, setCopied] = React.useState(false);

  const copy = () => {
    navigator.clipboard?.writeText(l.key);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, background: 'rgba(13,15,26,0.45)',
      backdropFilter: 'blur(3px)', zIndex: 500, animation: 'fade-up 0.2s',
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        position: 'absolute', top: 0, right: 0, bottom: 0,
        width: 520, background: '#fff',
        boxShadow: '-30px 0 80px rgba(13,15,26,0.20)',
        display: 'flex', flexDirection: 'column',
        animation: 'fade-up 0.25s',
      }}>
        {/* Drawer header */}
        <div style={{
          padding: '22px 28px 18px',
          borderBottom: '1px solid #F0F2FF',
          display: 'flex', alignItems: 'flex-start', gap: 14,
        }}>
          <ProductGlyph name={product.glyph} color={product.color} bg={product.bg} size={48} radius={14} />
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
              <h2 style={{ fontSize: 20, fontWeight: 800, color: '#0D0F1A', margin: 0, letterSpacing: '-0.02em' }}>
                {product.name}
              </h2>
              <Badge tone={STATUS_TONE[l.status]} dot>{l.status}</Badge>
            </div>
            <div style={{ fontSize: 13, color: '#6B7280' }}>{l.plan} plan · v{l.version}</div>
          </div>
          <button onClick={onClose} style={{
            background: '#F0F2FF', border: 'none', borderRadius: 9,
            width: 32, height: 32, display: 'grid', placeItems: 'center',
            cursor: 'pointer', color: '#4B5263', fontSize: 16,
          }}>×</button>
        </div>

        {/* Body */}
        <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '20px 28px' }}>
          {/* License key */}
          <div style={{ marginBottom: 22 }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#6B7280', marginBottom: 8 }}>
              License key
            </div>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 10,
              background: '#0D0F1A', borderRadius: 12, padding: '12px 14px',
            }}>
              <code style={{
                fontFamily: 'JetBrains Mono, monospace', fontSize: 13,
                color: '#4ED48A', letterSpacing: '0.04em', flex: 1,
              }}>{l.key}</code>
              <button onClick={copy} style={{
                background: 'rgba(255,255,255,0.10)', border: 'none', borderRadius: 8,
                padding: '6px 10px', color: copied ? '#4ED48A' : '#fff', cursor: 'pointer',
                fontSize: 11.5, fontWeight: 600, fontFamily: 'inherit',
                display: 'inline-flex', alignItems: 'center', gap: 6,
              }}>
                <Icon name={copied ? 'check' : 'copy'} size={13} />
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>

          {/* Meta grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 22 }}>
            <MetaCell label="Plan" value={l.plan} />
            <MetaCell label="Activations" value={l.activations} />
            <MetaCell label="Active domain" value={l.domain} />
            <MetaCell label="Expires" value={l.expiry} />
            <MetaCell label="Version" value={`v${l.version}`} mono />
            <MetaCell label="Auto-renew" value="Enabled" tone="green" />
          </div>

          {/* Domains list */}
          <div style={{ marginBottom: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A' }}>Active domains</div>
              <Btn variant="ghost" size="xs" leftIcon="plus">Add domain</Btn>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {(l.domain.includes(' sites') ? ['shopglow.com', 'theclub.co', 'localcafe.com'] : [l.domain]).map(d => (
                <div key={d} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '10px 12px', background: '#F8F9FF',
                  border: '1px solid #EDEFF8', borderRadius: 10,
                }}>
                  <Icon name="globe" size={14} color="#6C5CE7" />
                  <span style={{ flex: 1, fontSize: 12.5, color: '#0D0F1A', fontWeight: 600 }}>{d}</span>
                  <Badge tone="green" dot>Active</Badge>
                  <button style={{
                    background: 'transparent', border: 'none', cursor: 'pointer',
                    fontSize: 11, color: '#9499BA', fontWeight: 600, fontFamily: 'inherit',
                  }}>Deactivate</button>
                </div>
              ))}
            </div>
          </div>

          {/* Activation history */}
          <div style={{ marginBottom: 22 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A', marginBottom: 10 }}>Activation history</div>
            <div style={{ position: 'relative', paddingLeft: 18 }}>
              <div style={{ position: 'absolute', left: 5, top: 5, bottom: 5, width: 1.5, background: '#E9E6FD' }} />
              {[
                { t: 'Activated on shopglow.com', d: 'May 20, 2026 · 11:42 AM', tone: '#00C04B' },
                { t: 'License key generated', d: 'May 20, 2026 · 11:40 AM', tone: '#6C5CE7' },
                { t: 'Plan upgraded to Business', d: 'May 20, 2026 · 11:38 AM', tone: '#6C5CE7' },
              ].map((e, i) => (
                <div key={i} style={{ position: 'relative', paddingBottom: 14 }}>
                  <div style={{
                    position: 'absolute', left: -18, top: 4, width: 11, height: 11,
                    borderRadius: 9999, background: e.tone, border: '3px solid #fff',
                    boxShadow: '0 0 0 1px ' + e.tone,
                  }} />
                  <div style={{ fontSize: 13, color: '#0D0F1A', fontWeight: 600 }}>{e.t}</div>
                  <div style={{ fontSize: 11.5, color: '#9499BA', marginTop: 1 }}>{e.d}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Changelog */}
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#0D0F1A', marginBottom: 10 }}>
              What's new in v{l.version}
            </div>
            <div style={{
              padding: 14, background: '#F8F9FF', border: '1px solid #EDEFF8',
              borderRadius: 12, fontSize: 12.5, color: '#4B5263', lineHeight: 1.65,
            }}>
              <div>• AI inbox now supports image attachments</div>
              <div>• Faster license activation on multi-site networks</div>
              <div>• Fixed: WooCommerce 8.9 compatibility for order webhooks</div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div style={{
          padding: '16px 28px', borderTop: '1px solid #F0F2FF', background: '#F8F9FF',
          display: 'flex', gap: 8,
        }}>
          <Btn variant="primary" size="md" style={{ flex: 1, justifyContent: 'center' }} leftIcon="download">Download v{l.version}</Btn>
          <Btn variant="border-card" size="md">Upgrade plan</Btn>
          <Btn variant="ghost-gray" size="md">Revoke</Btn>
        </div>
      </div>
    </div>
  );
};

const MetaCell = ({ label, value, mono, tone }) => (
  <div>
    <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#9499BA', marginBottom: 4 }}>
      {label}
    </div>
    <div style={{
      fontSize: 13.5, fontWeight: 600,
      color: tone === 'green' ? '#007C2F' : '#0D0F1A',
      fontFamily: mono ? 'JetBrains Mono, monospace' : 'inherit',
    }}>
      {value}
    </div>
  </div>
);

Object.assign(window, { LicensesPage });
